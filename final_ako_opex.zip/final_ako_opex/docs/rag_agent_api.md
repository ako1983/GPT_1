# RAG Agent API Documentation

This document provides detailed API documentation for the RAG (Retrieval-Augmented Generation) Agent in the OPEX_BOT system.

## Table of Contents

1. [Introduction](#introduction)
2. [Core Methods](#core-methods)
3. [Event-Based Communication](#event-based-communication)
4. [Object Models](#object-models)
5. [Error Handling](#error-handling)
6. [Usage Examples](#usage-examples)

## Introduction

The RAG Agent provides an API for retrieving relevant context, augmenting queries, and managing documents. The API is available through both direct method calls and event-based communication.

## Core Methods

### Initialize

```python
async def initialize(self, config: Dict[str, Any]) -> bool
```

Initializes the agent with configuration parameters.

**Parameters:**
- `config`: Configuration dictionary (see [Configuration Guide](rag_agent_configuration.md))

**Returns:**
- `bool`: `True` if initialization was successful, `False` otherwise

---

### Process

```python
async def process(self, message: Message) -> Message
```

Processes an incoming message and produces a response.

**Parameters:**
- `message`: The incoming message to process

**Returns:**
- `Message`: A response message

---

### Retrieve Context

```python
async def retrieve_context(
    self,
    query: str,
    query_id: Optional[str] = None,
    retriever_type: str = "hybrid",
    options: Dict[str, Any] = None
) -> Dict[str, Any]
```

Retrieves relevant context for a query.

**Parameters:**
- `query`: The query to retrieve context for
- `query_id`: Optional query ID for state tracking
- `retriever_type`: Type of retriever to use (`"vector"`, `"keyword"`, `"hybrid"`)
- `options`: Additional retrieval options

**Options Dictionary:**
- `top_k`: Maximum number of results to return
- `filter`: Filter dictionary for results
- `collections`: List of collections to search
- Any other retriever-specific options

**Returns:**
- Dictionary with the following keys:
  - `query`: The original query
  - `context`: List of retrieved documents
  - `retriever`: Type of retriever used
  - `reranked`: Whether results were reranked

---

### Augment Query

```python
async def augment_query(
    self,
    query: str,
    query_id: Optional[str] = None,
    context: Optional[List[Dict[str, Any]]] = None
) -> Dict[str, Any]
```

Augments a query with additional context.

**Parameters:**
- `query`: The query to augment
- `query_id`: Optional query ID for state tracking
- `context`: Optional context to use for augmentation

**Returns:**
- Dictionary with the following keys:
  - `original_query`: The original query
  - `augmented_query`: The augmented query
  - `augmented_info`: Dictionary of extracted information

---

### Add Document

```python
async def add_document(
    self,
    document: Dict[str, Any],
    collection_name: str
) -> Dict[str, Any]
```

Adds a document to the vector store.

**Parameters:**
- `document`: The document to add, with the following keys:
  - `text`: The document text
  - `metadata`: Optional metadata dictionary
- `collection_name`: The collection to add the document to

**Returns:**
- Dictionary with the following keys:
  - `status`: `"success"` or `"error"`
  - `document_id`: ID of the added document (if successful)
  - `collection`: Name of the collection
  - `error`: Error message (if applicable)

---

### Shutdown

```python
async def shutdown(self) -> bool
```

Performs cleanup when shutting down the agent.

**Returns:**
- `bool`: `True` if shutdown was successful, `False` otherwise

## Event-Based Communication

The RAG Agent communicates with other agents through events. The following events are supported:

### Input Events

#### Retrieve Event

**Event Type:** `"retrieve"`

**Content:**
```json
{
  "query": "What was the total OPEX budget for Q1 2023?",
  "query_id": "query-123",
  "retriever": "hybrid",
  "top_k": 5,
  "filter": {"category": "financial"}
}
```

**Response Event Type:** `"retrieve_result"`

---

#### Augment Event

**Event Type:** `"augment"`

**Content:**
```json
{
  "query": "What was the total OPEX budget for Q1 2023?",
  "query_id": "query-123",
  "context": []
}
```

**Response Event Type:** `"augment_result"`

---

#### Add Document Event

**Event Type:** `"add_document"`

**Content:**
```json
{
  "document": {
    "text": "The Q1 2023 OPEX budget was $10.5M.",
    "metadata": {
      "source": "quarterly_report.pdf",
      "category": "financial"
    }
  },
  "collection": "financial_docs"
}
```

**Response Event Type:** `"add_document_result"`

### Output Events

#### Retrieve Result Event

**Event Type:** `"retrieve_result"`

**Content:**
```json
{
  "query": "What was the total OPEX budget for Q1 2023?",
  "context": [
    {
      "content": "The Q1 2023 OPEX budget was $10.5M.",
      "metadata": {
        "source": "quarterly_report.pdf",
        "category": "financial"
      },
      "relevance_score": 0.95,
      "collection": "financial_docs"
    }
  ],
  "retriever": "hybrid",
  "reranked": true
}
```

---

#### Augment Result Event

**Event Type:** `"augment_result"`

**Content:**
```json
{
  "original_query": "What was the total OPEX budget for Q1 2023?",
  "augmented_query": "Original question: What was the total OPEX budget for Q1 2023?\n\nRelevant tables:\n- pypl_opex_bau: Contains OPEX budget, forecast, and actual data\n\nRelevant columns:\n- pypl_opex_bau.budget_amt (FLOAT64): Budget amount in USD\n- pypl_opex_bau.fiscal_quarter (STRING): Fiscal quarter (e.g., 'Q1_2023')\n\nTable relationships:\n- pypl_opex_bau.cost_center_id -> cost_center.id (one-to-many)",
  "augmented_info": {
    "tables": {
      "pypl_opex_bau": {
        "description": "Contains OPEX budget, forecast, and actual data",
        "source": "bigquery"
      }
    },
    "columns": {
      "pypl_opex_bau": {
        "budget_amt": {
          "description": "Budget amount in USD",
          "data_type": "FLOAT64",
          "business_terms": ["budget"]
        },
        "fiscal_quarter": {
          "description": "Fiscal quarter (e.g., 'Q1_2023')",
          "data_type": "STRING",
          "business_terms": ["quarter"]
        }
      }
    },
    "relationships": [
      {
        "source_table": "pypl_opex_bau",
        "source_column": "cost_center_id",
        "target_table": "cost_center",
        "target_column": "id",
        "relationship_type": "one-to-many"
      }
    ],
    "examples": []
  }
}
```

---

#### Add Document Result Event

**Event Type:** `"add_document_result"`

**Content:**
```json
{
  "status": "success",
  "document_id": "doc-123",
  "collection": "financial_docs"
}
```

## Object Models

### Document Object

```json
{
  "text": "The document content...",
  "metadata": {
    "source": "document_source.pdf",
    "filename": "document_source.pdf",
    "type": "document",
    "category": "financial",
    "custom_field": "custom_value"
  }
}
```

### Context Document Object

```json
{
  "content": "The document content...",
  "metadata": {
    "source": "document_source.pdf",
    "filename": "document_source.pdf",
    "type": "document",
    "category": "financial",
    "custom_field": "custom_value"
  },
  "relevance_score": 0.95,
  "collection": "financial_docs",
  "source": "vector_store"
}
```

### Augmented Info Object

```json
{
  "tables": {
    "table_name": {
      "description": "Table description",
      "source": "source_system"
    }
  },
  "columns": {
    "table_name": {
      "column_name": {
        "description": "Column description",
        "data_type": "DATA_TYPE",
        "business_terms": ["term1", "term2"]
      }
    }
  },
  "relationships": [
    {
      "source_table": "source_table",
      "source_column": "source_column",
      "target_table": "target_table",
      "target_column": "target_column",
      "relationship_type": "relationship_type"
    }
  ],
  "examples": [
    {
      "question": "Example question",
      "content": "Example content"
    }
  ]
}
```

## Error Handling

The RAG Agent uses a consistent error handling approach:

1. **Method Return Values**: All methods return a dictionary with a status indicator
   - Success: Dictionary with the expected data
   - Failure: Dictionary with an `"error"` key containing the error message

2. **Event Responses**: Error responses are returned as regular event responses
   - Success: Event with the expected content
   - Failure: Event with a dictionary containing an `"error"` key

3. **Logging**: All errors are logged with appropriate severity levels

## Usage Examples

### Direct Method Usage

```python
from final_ako_opex.agents.rag import RAGAgent

# Initialize the agent
rag_agent = RAGAgent(agent_id="rag_agent_1", config={})
await rag_agent.initialize({
    "vector_store_type": "memory",
    "chunk_size": 512,
    "chunk_overlap": 100
})

# Retrieve context
context_result = await rag_agent.retrieve_context(
    query="What was the total OPEX budget for Q1 2023?",
    retriever_type="hybrid"
)

# Augment query
augment_result = await rag_agent.augment_query(
    query="What was the total OPEX budget for Q1 2023?",
    context=context_result.get("context", [])
)

# Add a document
document = {
    "text": "The Q1 2023 OPEX budget was $10.5M.",
    "metadata": {"source": "quarterly_report.pdf"}
}
add_result = await rag_agent.add_document(document, "financial_docs")

# Shutdown the agent
await rag_agent.shutdown()
```

### Event-Based Usage

```python
from final_ako_opex.core.interfaces.agent_interface import Message, AgentType
from final_ako_opex.core.communication.event_bus import get_event_bus

# Get the event bus
event_bus = get_event_bus()

# Send a retrieve event
retrieve_message = Message(
    sender=AgentType.QUERY_ENHANCER,
    receiver=AgentType.RAG,
    content={
        "query": "What was the total OPEX budget for Q1 2023?",
        "query_id": "query-123",
        "retriever": "hybrid"
    },
    message_type="retrieve",
    trace_id="trace-123"
)

# Publish the message (assuming the RAG agent is already subscribed)
await event_bus.publish(retrieve_message)

# Or register a callback for the response
async def on_retrieve_result(message: Message):
    result = message.content
    print(f"Retrieved {len(result.get('context', []))} documents")

event_bus.subscribe("retrieve_result", on_retrieve_result)
```

### Combining with Other Agents

```python
from final_ako_opex.agents.rag import RAGAgent
from final_ako_opex.agents.sql import SQLAgent

# Initialize the agents
rag_agent = RAGAgent(agent_id="rag_agent_1", config={})
sql_agent = SQLAgent(agent_id="sql_agent_1", config={})

await rag_agent.initialize({})
await sql_agent.initialize({})

# Process a query
query = "What was the total OPEX budget for Q1 2023?"
query_id = "query-123"

# Step 1: Retrieve and augment context
context_result = await rag_agent.retrieve_context(query, query_id)
augment_result = await rag_agent.augment_query(query, query_id, context_result.get("context", []))

# Step 2: Generate SQL using the augmented query
sql_result = await sql_agent.generate_sql(
    query=query,
    augmented_query=augment_result.get("augmented_query"),
    context=context_result.get("context", []),
    query_id=query_id
)

print(f"Generated SQL: {sql_result.get('sql')}")
```