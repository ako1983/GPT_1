# RAG Agent Configuration Guide

This document provides a comprehensive reference for configuring the RAG (Retrieval-Augmented Generation) Agent in the OPEX_BOT system.

## Overview

The RAG Agent is responsible for retrieving and augmenting relevant context for SQL generation. It uses a combination of vector search, keyword matching, and reranking to find the most pertinent information for a given query.

## Configuration Parameters

The RAG Agent is configured using a JSON configuration file. Below is a detailed explanation of all available configuration options.

### Basic Configuration

| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `agent_id` | string | Yes | - | Unique identifier for the agent |
| `agent_type` | string | Yes | `"RAG"` | Type identifier for the agent |
| `description` | string | No | - | Human-readable description of the agent |

### Vector Store Configuration

| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `vector_store_type` | string | No | `"memory"` | Type of vector store to use (`"memory"`, `"faiss"`, `"milvus"`) |
| `vector_store_path` | string | No | - | Path to save/load the vector store |
| `embedding_function` | object | No | `null` | Function to compute embeddings (implementation dependent) |

### Document Processing Configuration

| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `chunk_size` | integer | No | `512` | Maximum size of document chunks |
| `chunk_overlap` | integer | No | `100` | Overlap between adjacent chunks |

### Collections Configuration

| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `collections.metadata_collection` | string | No | `"financial_metadata"` | Collection name for metadata |
| `collections.examples_collection` | string | No | `"sql_examples"` | Collection name for SQL examples |
| `collections.documentation_collection` | string | No | `"financial_docs"` | Collection name for documentation |

### Retrieval Configuration

| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `retrieval.top_k` | integer | No | `5` | Maximum number of results to return |
| `retrieval.score_threshold` | float | No | `0.6` | Minimum score threshold for inclusion |
| `retrieval.retriever_weights` | array | No | `[0.7, 0.3]` | Weights for hybrid retrieval (vector, keyword) |
| `retrieval.reranker_type` | string | No | - | Type of reranker to use (`"cross_encoder"`, `"llm"`) |
| `retrieval.reranker_top_k` | integer | No | `3` | Maximum number of results after reranking |
| `retrieval.reranker_score_threshold` | float | No | `0.7` | Minimum score after reranking |
| `retrieval.cross_encoder_model` | string | No | - | Model name for cross-encoder reranker |

### Document Sources Configuration

Document sources are specified as an array of objects, each with the following parameters:

| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `type` | string | Yes | - | Type of source (`"file"`, `"directory"`, `"examples"`) |
| `path` | string | Yes | - | Path to the source |
| `collection` | string | No | Depends on type | Collection to store documents in |
| `extensions` | array | No | `[".md", ".txt", ".json"]` | File extensions to include (for `"directory"` type) |
| `metadata` | object | No | `{}` | Additional metadata to add to documents |
| `strategy` | string | No | `"text"` | Chunking strategy (`"text"`, `"paragraph"`, `"semantic"`) |
| `encoding` | string | No | `"utf-8"` | File encoding |

### Startup Options

| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `load_documents_on_startup` | boolean | No | `false` | Whether to load documents on startup |
| `analyze_on_startup` | boolean | No | `false` | Whether to analyze metadata on startup |

### Event Configuration

| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `events.subscriptions` | array | No | `["retrieve", "augment", "add_document"]` | Events to subscribe to |
| `events.publications` | array | No | `["retrieve_result", "augment_result", "add_document_result"]` | Events to publish |

### Logging Configuration

| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `logging.level` | string | No | `"INFO"` | Logging level |
| `logging.file` | string | No | `"logs/rag_agent.log"` | Log file path |
| `logging.format` | string | No | `"%(asctime)s - %(name)s - %(levelname)s - %(message)s"` | Log format |

### Performance Configuration

| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `performance.cache_enabled` | boolean | No | `true` | Whether to enable caching |
| `performance.cache_size` | integer | No | `100` | Maximum number of cached items |
| `performance.cache_ttl` | integer | No | `3600` | Cache time-to-live in seconds |
| `performance.batch_size` | integer | No | `10` | Batch size for operations |

## Example Configuration

```json
{
  "agent_id": "rag_agent_1",
  "agent_type": "RAG",
  "description": "RAG Agent for financial data context retrieval and query augmentation",
  
  "vector_store_type": "memory",
  "vector_store_path": "data/vector_store/financial_data",
  "embedding_function": null,
  
  "chunk_size": 512,
  "chunk_overlap": 100,
  
  "collections": {
    "metadata_collection": "financial_metadata",
    "examples_collection": "sql_examples",
    "documentation_collection": "financial_docs"
  },
  
  "retrieval": {
    "top_k": 5,
    "score_threshold": 0.6,
    "retriever_weights": [0.7, 0.3],
    "reranker_type": "cross_encoder",
    "reranker_top_k": 3,
    "reranker_score_threshold": 0.7,
    "cross_encoder_model": "cross-encoder/ms-marco-MiniLM-L-6-v2"
  },
  
  "document_sources": [
    {
      "type": "file",
      "path": "data/documentation/financial_glossary.md",
      "collection": "financial_docs",
      "metadata": {
        "category": "glossary",
        "importance": "high"
      }
    },
    {
      "type": "directory",
      "path": "data/documentation/schemas",
      "collection": "financial_docs",
      "extensions": [".md", ".txt", ".json"],
      "metadata": {
        "category": "schema_docs"
      }
    },
    {
      "type": "examples",
      "path": "data/examples/sql_examples.json",
      "collection": "sql_examples"
    }
  ],
  
  "load_documents_on_startup": true,
  "analyze_on_startup": false,
  
  "events": {
    "subscriptions": ["retrieve", "augment", "add_document"],
    "publications": ["retrieve_result", "augment_result", "add_document_result"]
  },
  
  "logging": {
    "level": "INFO",
    "file": "logs/rag_agent.log",
    "format": "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
  },
  
  "performance": {
    "cache_enabled": true,
    "cache_size": 100,
    "cache_ttl": 3600,
    "batch_size": 10
  }
}
```

## API Reference

The RAG Agent exposes the following API endpoints through the event system:

### Retrieve Context

- Event: `retrieve`
- Parameters:
  - `query`: The query to retrieve context for
  - `query_id`: Optional query ID for state tracking
  - `retriever`: Type of retriever to use (vector, keyword, hybrid)
  - Other retrieval options (see configuration)
- Response:
  - Event: `retrieve_result`
  - Content: Retrieved context documents

### Augment Query

- Event: `augment`
- Parameters:
  - `query`: The query to augment
  - `query_id`: Optional query ID for state tracking
  - `context`: Optional context to use for augmentation
- Response:
  - Event: `augment_result`
  - Content: Augmented query and information

### Add Document

- Event: `add_document`
- Parameters:
  - `document`: The document to add
  - `collection`: Collection to add the document to
- Response:
  - Event: `add_document_result`
  - Content: Status and document ID

## Best Practices

1. **Collection Organization**: Organize your collections logically. For example, use separate collections for metadata, examples, and documentation.

2. **Chunking Strategy**: Choose the appropriate chunking strategy based on your documents:
   - `text`: Best for general text with no specific structure
   - `paragraph`: Good for documents with clear paragraph boundaries
   - `semantic`: Best for preserving logical sections and subsections

3. **Retrieval Balance**: Adjust the `retriever_weights` to balance between semantic similarity (vector retrieval) and exact matching (keyword retrieval).

4. **Reranking**: Use reranking for improved quality, especially with larger document collections.

5. **Caching**: Enable caching for frequently used queries to improve performance.

6. **Regular Updates**: Periodically update your vector store with new or modified documents to ensure the most current information is available.

## Troubleshooting

Common issues and their solutions:

1. **Poor Retrieval Quality**:
   - Try different embedding models
   - Adjust chunk size and overlap
   - Use a different reranking strategy

2. **Slow Performance**:
   - Enable caching
   - Reduce the number of documents
   - Optimize chunking parameters

3. **Missing Information**:
   - Check that all necessary documents are loaded
   - Verify collection names match between loading and retrieval
   - Ensure embeddings are computed correctly

4. **Vector Store Errors**:
   - Check that the vector store path is correct and accessible
   - Verify the embedding function is compatible with the vector store type

## Integration with Other Agents

The RAG Agent works closely with the following agents:

1. **Metadata Agent**: Provides schema and business term information for retrieval
2. **Query Enhancer Agent**: Uses the augmented query from the RAG Agent
3. **SQL Agent**: Consumes the context provided by the RAG Agent

For optimal integration, ensure that:
- Collection names match between the Metadata Agent and RAG Agent
- The Query Enhancer Agent is configured to use the augmented query
- The SQL Agent is configured to use the retrieved context