"""
Event Bus Module

This module implements an event-driven communication system for inter-agent messaging.
It provides a central bus that agents can use to publish and subscribe to messages.
"""

import asyncio
import uuid
from typing import Dict, Any, Callable, Awaitable, List, Set, Optional, Union
import logging
from ..interfaces.agent_interface import Message, AgentType


class EventBus:
    """
    Event bus for asynchronous message passing between agents.
    
    The EventBus implements a publish-subscribe pattern where agents can:
    1. Publish messages to specific topics
    2. Subscribe to receive messages from specific topics
    3. Request-reply pattern for synchronous-like communication
    """
    
    def __init__(self):
        """Initialize a new event bus."""
        self._subscribers: Dict[Union[str, AgentType], Set[Callable[[Message], Awaitable[None]]]] = {}
        self._direct_handlers: Dict[AgentType, Callable[[Message], Awaitable[Optional[Message]]]] = {}
        self._reply_futures: Dict[str, asyncio.Future] = {}
        self._logger = logging.getLogger(__name__)
    
    async def publish(self, topic: str, message: Message) -> None:
        """
        Publish a message to a topic.
        
        Args:
            topic: The topic to publish the message to
            message: The message to publish
        """
        self._logger.debug(f"Publishing message to topic '{topic}': {message.to_dict()}")
        
        if topic not in self._subscribers:
            self._logger.warning(f"No subscribers for topic '{topic}'")
            return
        
        for subscriber in self._subscribers[topic]:
            try:
                await subscriber(message)
            except Exception as e:
                self._logger.error(f"Error delivering message to subscriber: {e}")
    
    def subscribe(self, topic: str, callback: Callable[[Message], Awaitable[None]]) -> Callable[[], None]:
        """
        Subscribe to a topic.
        
        Args:
            topic: The topic to subscribe to
            callback: The callback function to call when a message is published to the topic
            
        Returns:
            A function that can be called to unsubscribe
        """
        if topic not in self._subscribers:
            self._subscribers[topic] = set()
        
        self._subscribers[topic].add(callback)
        self._logger.debug(f"Subscribed to topic '{topic}'")
        
        def unsubscribe():
            if topic in self._subscribers and callback in self._subscribers[topic]:
                self._subscribers[topic].remove(callback)
                self._logger.debug(f"Unsubscribed from topic '{topic}'")
                if not self._subscribers[topic]:
                    del self._subscribers[topic]
        
        return unsubscribe
    
    def register_agent(self, agent_type: AgentType, handler: Callable[[Message], Awaitable[Optional[Message]]]) -> None:
        """
        Register an agent to receive direct messages.
        
        Args:
            agent_type: The type of agent
            handler: The handler function to call when a message is sent to this agent
        """
        self._direct_handlers[agent_type] = handler
        self._logger.debug(f"Registered agent handler for type '{agent_type}'")
        
        # Also subscribe to the agent type as a topic
        async def agent_topic_handler(message: Message) -> None:
            await handler(message)
            
        self.subscribe(agent_type.value, agent_topic_handler)
    
    def unregister_agent(self, agent_type: AgentType) -> None:
        """
        Unregister an agent.
        
        Args:
            agent_type: The type of agent to unregister
        """
        if agent_type in self._direct_handlers:
            del self._direct_handlers[agent_type]
            self._logger.debug(f"Unregistered agent handler for type '{agent_type}'")
    
    async def send(self, message: Message) -> None:
        """
        Send a message directly to an agent.
        
        Args:
            message: The message to send
        """
        if message.receiver not in self._direct_handlers:
            self._logger.warning(f"No handler registered for agent type '{message.receiver}'")
            return
        
        try:
            await self._direct_handlers[message.receiver](message)
        except Exception as e:
            self._logger.error(f"Error delivering message to agent '{message.receiver}': {e}")
    
    async def request(self, message: Message, timeout: float = 30.0) -> Optional[Message]:
        """
        Send a request and wait for a response.
        
        Args:
            message: The request message to send
            timeout: The maximum time to wait for a response in seconds
            
        Returns:
            The response message, or None if no response was received
        """
        # Generate a unique ID for this request if not provided
        if not message.trace_id:
            message.trace_id = str(uuid.uuid4())
        
        # Create a future to hold the response
        future = asyncio.Future()
        self._reply_futures[message.trace_id] = future
        
        # Send the message
        await self.send(message)
        
        try:
            # Wait for the response
            return await asyncio.wait_for(future, timeout)
        except asyncio.TimeoutError:
            self._logger.warning(f"Request timed out after {timeout} seconds: {message.trace_id}")
            return None
        finally:
            # Clean up the future
            if message.trace_id in self._reply_futures:
                del self._reply_futures[message.trace_id]
    
    async def reply(self, request_message: Message, response_content: Dict[str, Any]) -> None:
        """
        Reply to a request.
        
        Args:
            request_message: The original request message
            response_content: The content of the response
        """
        # Create a response message
        response = Message(
            sender=request_message.receiver,
            receiver=request_message.sender,
            content=response_content,
            message_type="response",
            trace_id=request_message.trace_id
        )
        
        # If this is a reply to a request, resolve the future
        if request_message.trace_id in self._reply_futures:
            self._reply_futures[request_message.trace_id].set_result(response)
        
        # Otherwise, just send the message back
        else:
            await self.send(response)
    
    def get_all_topics(self) -> List[str]:
        """
        Get a list of all registered topics.
        
        Returns:
            A list of topic names
        """
        return list(self._subscribers.keys())
    
    def get_subscriber_count(self, topic: str) -> int:
        """
        Get the number of subscribers for a topic.
        
        Args:
            topic: The topic to check
            
        Returns:
            The number of subscribers
        """
        if topic not in self._subscribers:
            return 0
        return len(self._subscribers[topic])


# Singleton instance of the event bus
_event_bus_instance = None


def get_event_bus() -> EventBus:
    """
    Get the singleton instance of the event bus.
    
    Returns:
        The event bus instance
    """
    global _event_bus_instance
    if _event_bus_instance is None:
        _event_bus_instance = EventBus()
    return _event_bus_instance