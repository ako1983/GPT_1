"""
State Manager Module

This module implements the state management system for tracking query progress
and maintaining the state of the conversation and processing pipeline.
"""

import uuid
import time
import json
from typing import Dict, Any, Optional, List, Set, TypedDict, Union
from enum import Enum
import logging
from ..interfaces.agent_interface import ExecutionStatus, AgentType


class QueryState(str, Enum):
    """Enumeration of possible query processing states."""
    INITIATED = "initiated"
    METADATA_PROCESSING = "metadata_processing"
    QUERY_ENHANCEMENT = "query_enhancement"
    WAITING_FOR_CLARIFICATION = "waiting_for_clarification"
    RAG_PROCESSING = "rag_processing"
    SQL_GENERATION = "sql_generation"
    SQL_VALIDATION = "sql_validation"
    SQL_REFINEMENT = "sql_refinement"
    RESPONSE_GENERATION = "response_generation"
    COMPLETED = "completed"
    FAILED = "failed"


class AgentStateUpdate(TypedDict):
    """Type definition for agent state updates."""
    agent_type: AgentType
    status: ExecutionStatus
    details: Dict[str, Any]
    timestamp: float


class QueryContext(TypedDict, total=False):
    """Type definition for query context information."""
    query_id: str
    session_id: str
    raw_query: str
    enhanced_query: Optional[str]
    clarification_questions: List[str]
    clarification_responses: List[str]
    metadata: Dict[str, Any]
    tables: List[str]
    columns: List[str]
    relationships: List[Dict[str, Any]]
    rag_context: List[Dict[str, Any]]
    generated_sql: Optional[str]
    validated_sql: Optional[str]
    refinement_attempts: int
    execution_result: Optional[Dict[str, Any]]
    final_response: Optional[str]
    error_messages: List[str]
    state_history: List[Dict[str, Any]]
    agent_states: Dict[AgentType, AgentStateUpdate]
    start_time: float
    end_time: Optional[float]
    total_processing_time: Optional[float]


class StateManager:
    """
    Manages the state of queries as they progress through the system.
    
    The StateManager tracks:
    1. Current state of each query
    2. History of state transitions
    3. Context information for each query
    4. Agent-specific state information
    """
    
    def __init__(self):
        """Initialize a new state manager."""
        self._queries: Dict[str, QueryContext] = {}
        self._sessions: Dict[str, Set[str]] = {}
        self._logger = logging.getLogger(__name__)
    
    def create_query(self, raw_query: str, session_id: Optional[str] = None) -> str:
        """
        Create a new query and initialize its state.
        
        Args:
            raw_query: The original query text from the user
            session_id: Optional session identifier for grouping related queries
            
        Returns:
            The newly created query ID
        """
        query_id = str(uuid.uuid4())
        
        # Create a new session if none provided
        if session_id is None:
            session_id = str(uuid.uuid4())
        
        # Initialize the session set if needed
        if session_id not in self._sessions:
            self._sessions[session_id] = set()
        
        # Add the query to the session
        self._sessions[session_id].add(query_id)
        
        # Initialize the query context
        self._queries[query_id] = QueryContext(
            query_id=query_id,
            session_id=session_id,
            raw_query=raw_query,
            enhanced_query=None,
            clarification_questions=[],
            clarification_responses=[],
            metadata={},
            tables=[],
            columns=[],
            relationships=[],
            rag_context=[],
            generated_sql=None,
            validated_sql=None,
            refinement_attempts=0,
            execution_result=None,
            final_response=None,
            error_messages=[],
            state_history=[],
            agent_states={},
            start_time=time.time(),
            end_time=None,
            total_processing_time=None
        )
        
        # Set the initial state
        self.update_query_state(query_id, QueryState.INITIATED, {
            "message": "Query processing initiated"
        })
        
        self._logger.info(f"Created new query with ID {query_id} in session {session_id}")
        return query_id
    
    def update_query_state(self, query_id: str, state: QueryState, details: Dict[str, Any]) -> bool:
        """
        Update the state of a query.
        
        Args:
            query_id: The ID of the query to update
            state: The new state
            details: Additional details about the state change
            
        Returns:
            True if the update was successful, False otherwise
        """
        if query_id not in self._queries:
            self._logger.warning(f"Attempted to update non-existent query {query_id}")
            return False
        
        # Record the state transition in history
        state_update = {
            "state": state,
            "details": details,
            "timestamp": time.time()
        }
        
        self._queries[query_id]["state_history"].append(state_update)
        
        # If the query is completed or failed, set the end time
        if state in [QueryState.COMPLETED, QueryState.FAILED]:
            self._queries[query_id]["end_time"] = time.time()
            self._queries[query_id]["total_processing_time"] = (
                self._queries[query_id]["end_time"] - self._queries[query_id]["start_time"]
            )
        
        self._logger.info(f"Updated query {query_id} state to {state}")
        return True
    
    def update_agent_state(self, query_id: str, agent_type: AgentType, status: ExecutionStatus, details: Dict[str, Any]) -> bool:
        """
        Update the state of an agent for a specific query.
        
        Args:
            query_id: The ID of the query
            agent_type: The type of agent
            status: The execution status of the agent
            details: Additional details about the agent's state
            
        Returns:
            True if the update was successful, False otherwise
        """
        if query_id not in self._queries:
            self._logger.warning(f"Attempted to update agent state for non-existent query {query_id}")
            return False
        
        agent_update = AgentStateUpdate(
            agent_type=agent_type,
            status=status,
            details=details,
            timestamp=time.time()
        )
        
        self._queries[query_id]["agent_states"][agent_type] = agent_update
        
        self._logger.info(f"Updated agent {agent_type} state for query {query_id} to {status}")
        return True
    
    def get_query_state(self, query_id: str) -> Optional[Dict[str, Any]]:
        """
        Get the current state and context of a query.
        
        Args:
            query_id: The ID of the query
            
        Returns:
            The query context, or None if the query doesn't exist
        """
        if query_id not in self._queries:
            self._logger.warning(f"Attempted to get state for non-existent query {query_id}")
            return None
        
        return self._queries[query_id]
    
    def get_current_state(self, query_id: str) -> Optional[QueryState]:
        """
        Get the current state of a query.
        
        Args:
            query_id: The ID of the query
            
        Returns:
            The current state, or None if the query doesn't exist
        """
        if query_id not in self._queries:
            self._logger.warning(f"Attempted to get state for non-existent query {query_id}")
            return None
        
        # Get the most recent state from history
        history = self._queries[query_id]["state_history"]
        if not history:
            return None
        
        return QueryState(history[-1]["state"])
    
    def get_session_queries(self, session_id: str) -> List[str]:
        """
        Get all query IDs associated with a session.
        
        Args:
            session_id: The ID of the session
            
        Returns:
            A list of query IDs, or an empty list if the session doesn't exist
        """
        if session_id not in self._sessions:
            return []
        
        return list(self._sessions[session_id])
    
    def update_query_context(self, query_id: str, updates: Dict[str, Any]) -> bool:
        """
        Update specific fields in the query context.
        
        Args:
            query_id: The ID of the query
            updates: A dictionary of fields to update
            
        Returns:
            True if the update was successful, False otherwise
        """
        if query_id not in self._queries:
            self._logger.warning(f"Attempted to update context for non-existent query {query_id}")
            return False
        
        # Update the fields
        for key, value in updates.items():
            if key in self._queries[query_id]:
                self._queries[query_id][key] = value
        
        self._logger.debug(f"Updated context for query {query_id} with fields: {list(updates.keys())}")
        return True
    
    def add_clarification_question(self, query_id: str, question: str) -> bool:
        """
        Add a clarification question for a query.
        
        Args:
            query_id: The ID of the query
            question: The clarification question
            
        Returns:
            True if successful, False otherwise
        """
        if query_id not in self._queries:
            self._logger.warning(f"Attempted to add clarification for non-existent query {query_id}")
            return False
        
        self._queries[query_id]["clarification_questions"].append(question)
        
        # Update the query state
        self.update_query_state(query_id, QueryState.WAITING_FOR_CLARIFICATION, {
            "question": question,
            "question_index": len(self._queries[query_id]["clarification_questions"]) - 1
        })
        
        self._logger.info(f"Added clarification question for query {query_id}: {question}")
        return True
    
    def add_clarification_response(self, query_id: str, response: str) -> bool:
        """
        Add a user's response to a clarification question.
        
        Args:
            query_id: The ID of the query
            response: The user's response
            
        Returns:
            True if successful, False otherwise
        """
        if query_id not in self._queries:
            self._logger.warning(f"Attempted to add response for non-existent query {query_id}")
            return False
        
        self._queries[query_id]["clarification_responses"].append(response)
        
        self._logger.info(f"Added clarification response for query {query_id}")
        return True
    
    def export_query_state(self, query_id: str) -> Optional[str]:
        """
        Export the complete state of a query as a JSON string.
        
        Args:
            query_id: The ID of the query
            
        Returns:
            JSON string of the query state, or None if the query doesn't exist
        """
        if query_id not in self._queries:
            self._logger.warning(f"Attempted to export non-existent query {query_id}")
            return None
        
        try:
            # Convert non-serializable types
            query_copy = self._queries[query_id].copy()
            
            # Convert Enum values to strings
            if "agent_states" in query_copy:
                for agent_type, state in query_copy["agent_states"].items():
                    if isinstance(state["agent_type"], AgentType):
                        state["agent_type"] = state["agent_type"].value
                    if isinstance(state["status"], ExecutionStatus):
                        state["status"] = state["status"].value
            
            # Convert history states to strings
            if "state_history" in query_copy:
                for state_entry in query_copy["state_history"]:
                    if isinstance(state_entry["state"], QueryState):
                        state_entry["state"] = state_entry["state"].value
            
            return json.dumps(query_copy, indent=2)
        except Exception as e:
            self._logger.error(f"Error exporting query {query_id}: {e}")
            return None
    
    def delete_query(self, query_id: str) -> bool:
        """
        Delete a query and its associated state.
        
        Args:
            query_id: The ID of the query to delete
            
        Returns:
            True if successful, False otherwise
        """
        if query_id not in self._queries:
            return False
        
        # Remove from session
        session_id = self._queries[query_id]["session_id"]
        if session_id in self._sessions and query_id in self._sessions[session_id]:
            self._sessions[session_id].remove(query_id)
            
            # Clean up empty sessions
            if not self._sessions[session_id]:
                del self._sessions[session_id]
        
        # Delete the query
        del self._queries[query_id]
        
        self._logger.info(f"Deleted query {query_id}")
        return True
    
    def get_active_queries(self) -> List[str]:
        """
        Get all active query IDs (those not in a terminal state).
        
        Returns:
            A list of active query IDs
        """
        active_queries = []
        terminal_states = [QueryState.COMPLETED, QueryState.FAILED]
        
        for query_id in self._queries:
            current_state = self.get_current_state(query_id)
            if current_state not in terminal_states:
                active_queries.append(query_id)
        
        return active_queries


# Singleton instance of the state manager
_state_manager_instance = None


def get_state_manager() -> StateManager:
    """
    Get the singleton instance of the state manager.
    
    Returns:
        The state manager instance
    """
    global _state_manager_instance
    if _state_manager_instance is None:
        _state_manager_instance = StateManager()
    return _state_manager_instance