"""
Conversation Store Module

This module implements the conversation history store for maintaining
the context of user interactions and supporting follow-up queries.
"""

import time
import uuid
import json
from typing import Dict, Any, List, Optional, TypedDict, Union
from enum import Enum
import logging


class MessageRole(str, Enum):
    """Enumeration of possible message roles in a conversation."""
    SYSTEM = "system"
    USER = "user"
    ASSISTANT = "assistant"
    FUNCTION = "function"


class ConversationMessage(TypedDict):
    """Type definition for conversation messages."""
    message_id: str
    role: MessageRole
    content: str
    metadata: Dict[str, Any]
    timestamp: float


class ConversationSummary(TypedDict):
    """Type definition for conversation summaries."""
    key_points: List[str]
    entities: Dict[str, List[str]]
    queries: List[str]
    intents: List[str]
    timestamp: float


class ConversationSession(TypedDict, total=False):
    """Type definition for conversation sessions."""
    session_id: str
    messages: List[ConversationMessage]
    summaries: List[ConversationSummary]
    user_id: Optional[str]
    metadata: Dict[str, Any]
    created_at: float
    updated_at: float
    query_ids: List[str]


class ConversationStore:
    """
    Stores and manages conversation history.
    
    The ConversationStore:
    1. Maintains the history of messages in each conversation
    2. Provides conversation context for query processing
    3. Generates and stores summaries of conversations
    4. Links conversations to queries
    """
    
    def __init__(self, max_sessions: int = 1000):
        """
        Initialize a new conversation store.
        
        Args:
            max_sessions: Maximum number of sessions to keep in memory
        """
        self._sessions: Dict[str, ConversationSession] = {}
        self._max_sessions = max_sessions
        self._logger = logging.getLogger(__name__)
    
    def create_session(self, user_id: Optional[str] = None, metadata: Optional[Dict[str, Any]] = None) -> str:
        """
        Create a new conversation session.
        
        Args:
            user_id: Optional identifier for the user
            metadata: Optional metadata for the session
            
        Returns:
            The ID of the new session
        """
        # Clean up if we've reached the maximum number of sessions
        if len(self._sessions) >= self._max_sessions:
            self._cleanup_old_sessions()
        
        session_id = str(uuid.uuid4())
        now = time.time()
        
        self._sessions[session_id] = ConversationSession(
            session_id=session_id,
            messages=[],
            summaries=[],
            user_id=user_id,
            metadata=metadata or {},
            created_at=now,
            updated_at=now,
            query_ids=[]
        )
        
        self._logger.info(f"Created new conversation session with ID {session_id}")
        return session_id
    
    def add_message(self, session_id: str, role: MessageRole, content: str, metadata: Optional[Dict[str, Any]] = None) -> Optional[str]:
        """
        Add a message to a conversation session.
        
        Args:
            session_id: The ID of the session
            role: The role of the message sender
            content: The content of the message
            metadata: Optional metadata for the message
            
        Returns:
            The ID of the new message, or None if the session doesn't exist
        """
        if session_id not in self._sessions:
            self._logger.warning(f"Attempted to add message to non-existent session {session_id}")
            return None
        
        message_id = str(uuid.uuid4())
        now = time.time()
        
        message = ConversationMessage(
            message_id=message_id,
            role=role,
            content=content,
            metadata=metadata or {},
            timestamp=now
        )
        
        self._sessions[session_id]["messages"].append(message)
        self._sessions[session_id]["updated_at"] = now
        
        self._logger.debug(f"Added {role} message to session {session_id}")
        return message_id
    
    def get_messages(self, session_id: str, limit: Optional[int] = None) -> List[Dict[str, Any]]:
        """
        Get messages from a conversation session.
        
        Args:
            session_id: The ID of the session
            limit: Optional maximum number of messages to return (most recent first)
            
        Returns:
            A list of messages, or an empty list if the session doesn't exist
        """
        if session_id not in self._sessions:
            self._logger.warning(f"Attempted to get messages from non-existent session {session_id}")
            return []
        
        messages = self._sessions[session_id]["messages"]
        
        # If limit is specified, return the most recent messages
        if limit is not None:
            messages = messages[-limit:]
        
        # Convert Enum values to strings for external use
        serializable_messages = []
        for msg in messages:
            msg_copy = msg.copy()
            if isinstance(msg_copy["role"], MessageRole):
                msg_copy["role"] = msg_copy["role"].value
            serializable_messages.append(msg_copy)
        
        return serializable_messages
    
    def get_session(self, session_id: str) -> Optional[Dict[str, Any]]:
        """
        Get a conversation session.
        
        Args:
            session_id: The ID of the session
            
        Returns:
            The session, or None if it doesn't exist
        """
        if session_id not in self._sessions:
            return None
        
        # Make a copy to avoid external modifications
        session = self._sessions[session_id].copy()
        
        # Convert Enum values to strings
        for i, msg in enumerate(session["messages"]):
            if isinstance(msg["role"], MessageRole):
                session["messages"][i] = msg.copy()
                session["messages"][i]["role"] = msg["role"].value
        
        return session
    
    def add_summary(self, session_id: str, key_points: List[str], entities: Dict[str, List[str]], 
                   queries: List[str], intents: List[str]) -> bool:
        """
        Add a summary of the conversation.
        
        Args:
            session_id: The ID of the session
            key_points: List of key points from the conversation
            entities: Dictionary of entity types to entity values
            queries: List of user queries
            intents: List of detected user intents
            
        Returns:
            True if successful, False otherwise
        """
        if session_id not in self._sessions:
            self._logger.warning(f"Attempted to add summary to non-existent session {session_id}")
            return False
        
        summary = ConversationSummary(
            key_points=key_points,
            entities=entities,
            queries=queries,
            intents=intents,
            timestamp=time.time()
        )
        
        self._sessions[session_id]["summaries"].append(summary)
        self._sessions[session_id]["updated_at"] = time.time()
        
        self._logger.info(f"Added summary to session {session_id}")
        return True
    
    def get_latest_summary(self, session_id: str) -> Optional[Dict[str, Any]]:
        """
        Get the most recent summary for a session.
        
        Args:
            session_id: The ID of the session
            
        Returns:
            The most recent summary, or None if there are no summaries
        """
        if session_id not in self._sessions or not self._sessions[session_id]["summaries"]:
            return None
        
        return self._sessions[session_id]["summaries"][-1]
    
    def link_query(self, session_id: str, query_id: str) -> bool:
        """
        Link a query to a conversation session.
        
        Args:
            session_id: The ID of the session
            query_id: The ID of the query
            
        Returns:
            True if successful, False otherwise
        """
        if session_id not in self._sessions:
            self._logger.warning(f"Attempted to link query to non-existent session {session_id}")
            return False
        
        if query_id not in self._sessions[session_id]["query_ids"]:
            self._sessions[session_id]["query_ids"].append(query_id)
            self._sessions[session_id]["updated_at"] = time.time()
        
        self._logger.debug(f"Linked query {query_id} to session {session_id}")
        return True
    
    def get_linked_queries(self, session_id: str) -> List[str]:
        """
        Get all queries linked to a session.
        
        Args:
            session_id: The ID of the session
            
        Returns:
            A list of query IDs, or an empty list if the session doesn't exist
        """
        if session_id not in self._sessions:
            return []
        
        return self._sessions[session_id]["query_ids"]
    
    def update_session_metadata(self, session_id: str, metadata: Dict[str, Any]) -> bool:
        """
        Update the metadata for a session.
        
        Args:
            session_id: The ID of the session
            metadata: The new metadata
            
        Returns:
            True if successful, False otherwise
        """
        if session_id not in self._sessions:
            self._logger.warning(f"Attempted to update metadata for non-existent session {session_id}")
            return False
        
        self._sessions[session_id]["metadata"].update(metadata)
        self._sessions[session_id]["updated_at"] = time.time()
        
        self._logger.debug(f"Updated metadata for session {session_id}")
        return True
    
    def delete_session(self, session_id: str) -> bool:
        """
        Delete a conversation session.
        
        Args:
            session_id: The ID of the session
            
        Returns:
            True if successful, False otherwise
        """
        if session_id not in self._sessions:
            return False
        
        del self._sessions[session_id]
        
        self._logger.info(f"Deleted session {session_id}")
        return True
    
    def get_session_count(self) -> int:
        """
        Get the number of sessions in the store.
        
        Returns:
            The number of sessions
        """
        return len(self._sessions)
    
    def get_all_sessions(self) -> List[str]:
        """
        Get a list of all session IDs.
        
        Returns:
            A list of session IDs
        """
        return list(self._sessions.keys())
    
    def export_session(self, session_id: str) -> Optional[str]:
        """
        Export a session as a JSON string.
        
        Args:
            session_id: The ID of the session
            
        Returns:
            JSON string of the session, or None if the session doesn't exist
        """
        session = self.get_session(session_id)
        if session is None:
            return None
        
        try:
            return json.dumps(session, indent=2)
        except Exception as e:
            self._logger.error(f"Error exporting session {session_id}: {e}")
            return None
    
    def _cleanup_old_sessions(self) -> None:
        """Clean up old sessions when we've reached the maximum."""
        if len(self._sessions) <= self._max_sessions:
            return
        
        # Sort sessions by updated_at time
        sorted_sessions = sorted(
            self._sessions.items(),
            key=lambda x: x[1]["updated_at"]
        )
        
        # Remove the oldest sessions
        num_to_remove = len(self._sessions) - self._max_sessions + 10  # Remove extra to avoid frequent cleanups
        for i in range(num_to_remove):
            if i < len(sorted_sessions):
                session_id = sorted_sessions[i][0]
                del self._sessions[session_id]
                self._logger.info(f"Cleaned up old session {session_id}")


# Singleton instance of the conversation store
_conversation_store_instance = None


def get_conversation_store() -> ConversationStore:
    """
    Get the singleton instance of the conversation store.
    
    Returns:
        The conversation store instance
    """
    global _conversation_store_instance
    if _conversation_store_instance is None:
        _conversation_store_instance = ConversationStore()
    return _conversation_store_instance