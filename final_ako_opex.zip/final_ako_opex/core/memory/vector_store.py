"""
Vector Store Module

This module implements the vector database interface for storing and retrieving
embeddings used in the RAG system.
"""

import os
import uuid
import json
import logging
from typing import Dict, List, Any, Optional, Union, Tuple, Callable, TypedDict
import numpy as np


class Document(TypedDict):
    """Type definition for documents stored in the vector store."""
    id: str
    text: str
    metadata: Dict[str, Any]
    embedding: Optional[List[float]]


class VectorStore:
    """
    Base class for vector storage implementations.
    
    This is an abstract base class that defines the interface that all
    vector store implementations must follow.
    """
    
    def __init__(self):
        """Initialize a new vector store."""
        self._logger = logging.getLogger(__name__)
    
    def add_documents(self, documents: List[Document], collection_name: str = "default") -> List[str]:
        """
        Add documents to the vector store.
        
        Args:
            documents: List of documents to add
            collection_name: Name of the collection to add to
            
        Returns:
            List of document IDs
        """
        raise NotImplementedError("Subclasses must implement add_documents")
    
    def add_texts(self, texts: List[str], metadatas: Optional[List[Dict[str, Any]]] = None, 
                 embeddings: Optional[List[List[float]]] = None, collection_name: str = "default") -> List[str]:
        """
        Add texts to the vector store.
        
        Args:
            texts: List of text strings to add
            metadatas: Optional list of metadata dictionaries
            embeddings: Optional list of pre-computed embeddings
            collection_name: Name of the collection to add to
            
        Returns:
            List of document IDs
        """
        raise NotImplementedError("Subclasses must implement add_texts")
    
    def similarity_search(self, query: str, k: int = 4, collection_name: str = "default", 
                         filter: Optional[Dict[str, Any]] = None) -> List[Document]:
        """
        Search for documents similar to the query.
        
        Args:
            query: Query string
            k: Number of documents to return
            collection_name: Name of the collection to search
            filter: Optional filter to apply to the search
            
        Returns:
            List of similar documents
        """
        raise NotImplementedError("Subclasses must implement similarity_search")
    
    def similarity_search_by_vector(self, embedding: List[float], k: int = 4, 
                                  collection_name: str = "default", 
                                  filter: Optional[Dict[str, Any]] = None) -> List[Document]:
        """
        Search for documents similar to the embedding vector.
        
        Args:
            embedding: Query embedding vector
            k: Number of documents to return
            collection_name: Name of the collection to search
            filter: Optional filter to apply to the search
            
        Returns:
            List of similar documents
        """
        raise NotImplementedError("Subclasses must implement similarity_search_by_vector")
    
    def delete(self, document_id: str, collection_name: str = "default") -> bool:
        """
        Delete a document from the vector store.
        
        Args:
            document_id: ID of the document to delete
            collection_name: Name of the collection to delete from
            
        Returns:
            True if successful, False otherwise
        """
        raise NotImplementedError("Subclasses must implement delete")
    
    def get(self, document_id: str, collection_name: str = "default") -> Optional[Document]:
        """
        Get a document by ID.
        
        Args:
            document_id: ID of the document to get
            collection_name: Name of the collection to get from
            
        Returns:
            The document, or None if it doesn't exist
        """
        raise NotImplementedError("Subclasses must implement get")
    
    def list_collections(self) -> List[str]:
        """
        List all collections in the vector store.
        
        Returns:
            List of collection names
        """
        raise NotImplementedError("Subclasses must implement list_collections")
    
    def count_documents(self, collection_name: str = "default") -> int:
        """
        Count the number of documents in a collection.
        
        Args:
            collection_name: Name of the collection
            
        Returns:
            Number of documents
        """
        raise NotImplementedError("Subclasses must implement count_documents")


class InMemoryVectorStore(VectorStore):
    """
    Simple in-memory implementation of a vector store.
    
    This is primarily for development and testing. Production systems
    should use a persistent vector store implementation.
    """
    
    def __init__(self, embedding_fn: Optional[Callable[[str], List[float]]] = None):
        """
        Initialize a new in-memory vector store.
        
        Args:
            embedding_fn: Function to compute embeddings for texts
        """
        super().__init__()
        self._collections: Dict[str, Dict[str, Document]] = {}
        self._embedding_fn = embedding_fn
        self._logger.info("Initialized in-memory vector store")
    
    def add_documents(self, documents: List[Document], collection_name: str = "default") -> List[str]:
        """
        Add documents to the vector store.
        
        Args:
            documents: List of documents to add
            collection_name: Name of the collection to add to
            
        Returns:
            List of document IDs
        """
        # Initialize the collection if it doesn't exist
        if collection_name not in self._collections:
            self._collections[collection_name] = {}
        
        document_ids = []
        
        for doc in documents:
            # Generate an ID if not provided
            doc_id = doc.get("id", str(uuid.uuid4()))
            document_ids.append(doc_id)
            
            # Compute embedding if not provided and we have an embedding function
            if doc.get("embedding") is None and self._embedding_fn is not None:
                doc["embedding"] = self._embedding_fn(doc["text"])
            
            # Store the document
            self._collections[collection_name][doc_id] = doc
        
        self._logger.info(f"Added {len(documents)} documents to collection '{collection_name}'")
        return document_ids
    
    def add_texts(self, texts: List[str], metadatas: Optional[List[Dict[str, Any]]] = None, 
                 embeddings: Optional[List[List[float]]] = None, collection_name: str = "default") -> List[str]:
        """
        Add texts to the vector store.
        
        Args:
            texts: List of text strings to add
            metadatas: Optional list of metadata dictionaries
            embeddings: Optional list of pre-computed embeddings
            collection_name: Name of the collection to add to
            
        Returns:
            List of document IDs
        """
        # Initialize the collection if it doesn't exist
        if collection_name not in self._collections:
            self._collections[collection_name] = {}
        
        # Initialize metadatas if not provided
        if metadatas is None:
            metadatas = [{} for _ in texts]
        
        # Create documents
        documents = []
        for i, text in enumerate(texts):
            metadata = metadatas[i] if i < len(metadatas) else {}
            embedding = embeddings[i] if embeddings is not None and i < len(embeddings) else None
            
            # Compute embedding if not provided and we have an embedding function
            if embedding is None and self._embedding_fn is not None:
                embedding = self._embedding_fn(text)
            
            documents.append({
                "id": str(uuid.uuid4()),
                "text": text,
                "metadata": metadata,
                "embedding": embedding
            })
        
        # Add the documents
        return self.add_documents(documents, collection_name)
    
    def similarity_search(self, query: str, k: int = 4, collection_name: str = "default", 
                         filter: Optional[Dict[str, Any]] = None) -> List[Document]:
        """
        Search for documents similar to the query.
        
        Args:
            query: Query string
            k: Number of documents to return
            collection_name: Name of the collection to search
            filter: Optional filter to apply to the search
            
        Returns:
            List of similar documents
        """
        # Check if the collection exists
        if collection_name not in self._collections:
            self._logger.warning(f"Collection '{collection_name}' does not exist")
            return []
        
        # Compute the query embedding
        if self._embedding_fn is None:
            self._logger.error("No embedding function provided for similarity search")
            return []
        
        query_embedding = self._embedding_fn(query)
        
        # Search by vector
        return self.similarity_search_by_vector(query_embedding, k, collection_name, filter)
    
    def similarity_search_by_vector(self, embedding: List[float], k: int = 4, 
                                  collection_name: str = "default", 
                                  filter: Optional[Dict[str, Any]] = None) -> List[Document]:
        """
        Search for documents similar to the embedding vector.
        
        Args:
            embedding: Query embedding vector
            k: Number of documents to return
            collection_name: Name of the collection to search
            filter: Optional filter to apply to the search
            
        Returns:
            List of similar documents
        """
        # Check if the collection exists
        if collection_name not in self._collections:
            self._logger.warning(f"Collection '{collection_name}' does not exist")
            return []
        
        # Convert the query embedding to a numpy array
        query_embedding = np.array(embedding)
        
        # Compute similarities for all documents in the collection
        similarities = []
        for doc_id, doc in self._collections[collection_name].items():
            # Skip documents without embeddings
            if doc.get("embedding") is None:
                continue
            
            # Skip documents that don't match the filter
            if filter is not None and not self._matches_filter(doc, filter):
                continue
            
            # Compute cosine similarity
            doc_embedding = np.array(doc["embedding"])
            similarity = self._cosine_similarity(query_embedding, doc_embedding)
            similarities.append((doc_id, similarity))
        
        # Sort by similarity (highest first) and take the top k
        similarities.sort(key=lambda x: x[1], reverse=True)
        top_k = similarities[:k]
        
        # Return the documents
        return [self._collections[collection_name][doc_id] for doc_id, _ in top_k]
    
    def delete(self, document_id: str, collection_name: str = "default") -> bool:
        """
        Delete a document from the vector store.
        
        Args:
            document_id: ID of the document to delete
            collection_name: Name of the collection to delete from
            
        Returns:
            True if successful, False otherwise
        """
        # Check if the collection exists
        if collection_name not in self._collections:
            return False
        
        # Check if the document exists
        if document_id not in self._collections[collection_name]:
            return False
        
        # Delete the document
        del self._collections[collection_name][document_id]
        
        self._logger.info(f"Deleted document {document_id} from collection '{collection_name}'")
        return True
    
    def get(self, document_id: str, collection_name: str = "default") -> Optional[Document]:
        """
        Get a document by ID.
        
        Args:
            document_id: ID of the document to get
            collection_name: Name of the collection to get from
            
        Returns:
            The document, or None if it doesn't exist
        """
        # Check if the collection exists
        if collection_name not in self._collections:
            return None
        
        # Check if the document exists
        if document_id not in self._collections[collection_name]:
            return None
        
        # Return the document
        return self._collections[collection_name][document_id]
    
    def list_collections(self) -> List[str]:
        """
        List all collections in the vector store.
        
        Returns:
            List of collection names
        """
        return list(self._collections.keys())
    
    def count_documents(self, collection_name: str = "default") -> int:
        """
        Count the number of documents in a collection.
        
        Args:
            collection_name: Name of the collection
            
        Returns:
            Number of documents
        """
        # Check if the collection exists
        if collection_name not in self._collections:
            return 0
        
        # Return the number of documents
        return len(self._collections[collection_name])
    
    def _cosine_similarity(self, a: np.ndarray, b: np.ndarray) -> float:
        """
        Compute the cosine similarity between two vectors.
        
        Args:
            a: First vector
            b: Second vector
            
        Returns:
            Cosine similarity (between -1 and 1)
        """
        return np.dot(a, b) / (np.linalg.norm(a) * np.linalg.norm(b))
    
    def _matches_filter(self, doc: Document, filter: Dict[str, Any]) -> bool:
        """
        Check if a document matches a filter.
        
        Args:
            doc: Document to check
            filter: Filter to apply
            
        Returns:
            True if the document matches the filter, False otherwise
        """
        # Simple exact match filter implementation
        for key, value in filter.items():
            # Check if the key exists in the metadata
            if key not in doc["metadata"]:
                return False
            
            # Check if the value matches
            if doc["metadata"][key] != value:
                return False
        
        return True
    
    def save(self, filepath: str) -> bool:
        """
        Save the vector store to a file.
        
        Args:
            filepath: Path to save to
            
        Returns:
            True if successful, False otherwise
        """
        try:
            # Create a serializable representation of the collections
            serializable = {}
            for collection_name, collection in self._collections.items():
                serializable[collection_name] = {}
                for doc_id, doc in collection.items():
                    serializable[collection_name][doc_id] = {
                        "id": doc["id"],
                        "text": doc["text"],
                        "metadata": doc["metadata"],
                        "embedding": doc.get("embedding", []).tolist() if isinstance(doc.get("embedding"), np.ndarray) else doc.get("embedding")
                    }
            
            # Create the directory if it doesn't exist
            os.makedirs(os.path.dirname(filepath), exist_ok=True)
            
            # Save to file
            with open(filepath, "w") as f:
                json.dump(serializable, f, indent=2)
            
            self._logger.info(f"Saved vector store to {filepath}")
            return True
        except Exception as e:
            self._logger.error(f"Error saving vector store: {e}")
            return False
    
    @classmethod
    def load(cls, filepath: str, embedding_fn: Optional[Callable[[str], List[float]]] = None) -> 'InMemoryVectorStore':
        """
        Load a vector store from a file.
        
        Args:
            filepath: Path to load from
            embedding_fn: Function to compute embeddings for texts
            
        Returns:
            Loaded vector store
        """
        instance = cls(embedding_fn)
        
        try:
            # Load from file
            with open(filepath, "r") as f:
                serialized = json.load(f)
            
            # Populate the collections
            for collection_name, collection in serialized.items():
                instance._collections[collection_name] = {}
                for doc_id, doc in collection.items():
                    instance._collections[collection_name][doc_id] = doc
            
            instance._logger.info(f"Loaded vector store from {filepath}")
            return instance
        except Exception as e:
            instance._logger.error(f"Error loading vector store: {e}")
            return instance


# Factory function to create vector stores
def create_vector_store(store_type: str, **kwargs) -> VectorStore:
    """
    Create a vector store of the specified type.
    
    Args:
        store_type: Type of vector store to create
        **kwargs: Additional arguments to pass to the constructor
        
    Returns:
        A vector store instance
        
    Raises:
        ValueError: If the store type is not recognized
    """
    if store_type == "memory":
        return InMemoryVectorStore(**kwargs)
    
    # More implementations can be added here
    
    raise ValueError(f"Unknown vector store type: {store_type}")