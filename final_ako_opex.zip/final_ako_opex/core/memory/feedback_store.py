"""
Feedback Store Module

This module implements the feedback collection and storage system for
learning from user interactions to improve the system over time.
"""

import os
import json
import time
import uuid
import logging
from typing import Dict, List, Any, Optional, TypedDict, Union
from enum import Enum


class FeedbackType(str, Enum):
    """Enumeration of possible feedback types."""
    POSITIVE = "positive"
    NEGATIVE = "negative"
    CORRECTION = "correction"
    CLARIFICATION = "clarification"
    SUGGESTION = "suggestion"


class FeedbackCategory(str, Enum):
    """Enumeration of feedback categories."""
    QUERY_UNDERSTANDING = "query_understanding"
    SQL_GENERATION = "sql_generation"
    SQL_VALIDATION = "sql_validation"
    RESULT_PRESENTATION = "result_presentation"
    CLARIFICATION_QUESTION = "clarification_question"
    GENERAL = "general"


class FeedbackEntry(TypedDict, total=False):
    """Type definition for feedback entries."""
    feedback_id: str
    query_id: str
    session_id: str
    feedback_type: FeedbackType
    feedback_category: FeedbackCategory
    original_content: Optional[str]
    corrected_content: Optional[str]
    user_comment: Optional[str]
    metadata: Dict[str, Any]
    timestamp: float
    processed: bool
    processing_notes: Optional[str]


class FeedbackStore:
    """
    Stores and manages user feedback for learning and improvement.
    
    The FeedbackStore:
    1. Collects and organizes user feedback on system performance
    2. Stores corrections for training and fine-tuning
    3. Tracks feedback processing status
    4. Provides analytics on feedback trends
    """
    
    def __init__(self, storage_dir: str):
        """
        Initialize a new feedback store.
        
        Args:
            storage_dir: Directory to store feedback data
        """
        self.storage_dir = storage_dir
        self.feedback_file = os.path.join(storage_dir, "feedback.jsonl")
        
        # Create the storage directory if it doesn't exist
        os.makedirs(storage_dir, exist_ok=True)
        
        self._logger = logging.getLogger(__name__)
        self._logger.info(f"Initialized feedback store in {storage_dir}")
    
    def add_feedback(self, query_id: str, feedback_type: FeedbackType, 
                    feedback_category: FeedbackCategory, 
                    original_content: Optional[str] = None,
                    corrected_content: Optional[str] = None,
                    user_comment: Optional[str] = None,
                    session_id: Optional[str] = None,
                    metadata: Optional[Dict[str, Any]] = None) -> str:
        """
        Add a new feedback entry.
        
        Args:
            query_id: ID of the query that the feedback is for
            feedback_type: Type of feedback
            feedback_category: Category of the feedback
            original_content: Optional original content that the feedback is about
            corrected_content: Optional corrected content provided by the user
            user_comment: Optional comment from the user
            session_id: Optional session ID
            metadata: Optional additional metadata
            
        Returns:
            ID of the new feedback entry
        """
        feedback_id = str(uuid.uuid4())
        
        # Create the feedback entry
        entry = FeedbackEntry(
            feedback_id=feedback_id,
            query_id=query_id,
            session_id=session_id,
            feedback_type=feedback_type,
            feedback_category=feedback_category,
            original_content=original_content,
            corrected_content=corrected_content,
            user_comment=user_comment,
            metadata=metadata or {},
            timestamp=time.time(),
            processed=False,
            processing_notes=None
        )
        
        # Convert Enum values to strings for JSON serialization
        serializable_entry = self._make_serializable(entry)
        
        # Append to the feedback file
        with open(self.feedback_file, "a") as f:
            f.write(json.dumps(serializable_entry) + "\n")
        
        self._logger.info(f"Added {feedback_type} feedback for query {query_id}")
        return feedback_id
    
    def get_feedback(self, feedback_id: str) -> Optional[FeedbackEntry]:
        """
        Get a specific feedback entry.
        
        Args:
            feedback_id: ID of the feedback entry
            
        Returns:
            The feedback entry, or None if it doesn't exist
        """
        # Read all feedback entries
        entries = self._read_feedback_entries()
        
        # Find the entry with the matching ID
        for entry in entries:
            if entry.get("feedback_id") == feedback_id:
                return entry
        
        return None
    
    def get_feedback_for_query(self, query_id: str) -> List[FeedbackEntry]:
        """
        Get all feedback entries for a specific query.
        
        Args:
            query_id: ID of the query
            
        Returns:
            List of feedback entries
        """
        # Read all feedback entries
        entries = self._read_feedback_entries()
        
        # Filter entries for the specified query
        return [entry for entry in entries if entry.get("query_id") == query_id]
    
    def get_feedback_by_type(self, feedback_type: FeedbackType) -> List[FeedbackEntry]:
        """
        Get all feedback entries of a specific type.
        
        Args:
            feedback_type: Type of feedback
            
        Returns:
            List of feedback entries
        """
        # Read all feedback entries
        entries = self._read_feedback_entries()
        
        # Filter entries by type
        return [entry for entry in entries if entry.get("feedback_type") == feedback_type]
    
    def get_feedback_by_category(self, feedback_category: FeedbackCategory) -> List[FeedbackEntry]:
        """
        Get all feedback entries in a specific category.
        
        Args:
            feedback_category: Category of feedback
            
        Returns:
            List of feedback entries
        """
        # Read all feedback entries
        entries = self._read_feedback_entries()
        
        # Filter entries by category
        return [entry for entry in entries if entry.get("feedback_category") == feedback_category]
    
    def get_unprocessed_feedback(self) -> List[FeedbackEntry]:
        """
        Get all unprocessed feedback entries.
        
        Returns:
            List of unprocessed feedback entries
        """
        # Read all feedback entries
        entries = self._read_feedback_entries()
        
        # Filter entries that haven't been processed
        return [entry for entry in entries if not entry.get("processed", False)]
    
    def mark_as_processed(self, feedback_id: str, notes: Optional[str] = None) -> bool:
        """
        Mark a feedback entry as processed.
        
        Args:
            feedback_id: ID of the feedback entry
            notes: Optional processing notes
            
        Returns:
            True if successful, False otherwise
        """
        # Read all feedback entries
        entries = self._read_feedback_entries()
        
        # Find the entry with the matching ID
        for i, entry in enumerate(entries):
            if entry.get("feedback_id") == feedback_id:
                # Mark as processed
                entries[i]["processed"] = True
                
                # Add processing notes if provided
                if notes:
                    entries[i]["processing_notes"] = notes
                
                # Write all entries back to the file
                self._write_feedback_entries(entries)
                
                self._logger.info(f"Marked feedback {feedback_id} as processed")
                return True
        
        self._logger.warning(f"Feedback {feedback_id} not found")
        return False
    
    def get_feedback_stats(self) -> Dict[str, Any]:
        """
        Get statistics about the feedback entries.
        
        Returns:
            Dictionary of statistics
        """
        # Read all feedback entries
        entries = self._read_feedback_entries()
        
        # Calculate statistics
        stats = {
            "total": len(entries),
            "processed": sum(1 for e in entries if e.get("processed", False)),
            "unprocessed": sum(1 for e in entries if not e.get("processed", False)),
            "by_type": {},
            "by_category": {}
        }
        
        # Count by type
        for entry in entries:
            feedback_type = entry.get("feedback_type")
            if feedback_type:
                if feedback_type not in stats["by_type"]:
                    stats["by_type"][feedback_type] = 0
                stats["by_type"][feedback_type] += 1
        
        # Count by category
        for entry in entries:
            feedback_category = entry.get("feedback_category")
            if feedback_category:
                if feedback_category not in stats["by_category"]:
                    stats["by_category"][feedback_category] = 0
                stats["by_category"][feedback_category] += 1
        
        return stats
    
    def export_training_data(self, output_file: str) -> bool:
        """
        Export feedback data in a format suitable for training.
        
        Args:
            output_file: Path to write the training data to
            
        Returns:
            True if successful, False otherwise
        """
        try:
            # Read all feedback entries
            entries = self._read_feedback_entries()
            
            # Filter for correction feedback with both original and corrected content
            training_data = []
            for entry in entries:
                if (entry.get("feedback_type") == FeedbackType.CORRECTION and
                    entry.get("original_content") and
                    entry.get("corrected_content")):
                    
                    training_data.append({
                        "input": entry["original_content"],
                        "output": entry["corrected_content"],
                        "category": entry.get("feedback_category"),
                        "metadata": entry.get("metadata", {})
                    })
            
            # Write to the output file
            with open(output_file, "w") as f:
                json.dump(training_data, f, indent=2)
            
            self._logger.info(f"Exported {len(training_data)} training examples to {output_file}")
            return True
        except Exception as e:
            self._logger.error(f"Error exporting training data: {e}")
            return False
    
    def _read_feedback_entries(self) -> List[FeedbackEntry]:
        """
        Read all feedback entries from the file.
        
        Returns:
            List of feedback entries
        """
        entries = []
        
        try:
            # Check if the file exists
            if not os.path.exists(self.feedback_file):
                return []
            
            # Read each line and parse as JSON
            with open(self.feedback_file, "r") as f:
                for line in f:
                    try:
                        entry = json.loads(line)
                        entries.append(entry)
                    except json.JSONDecodeError:
                        self._logger.warning(f"Invalid JSON in feedback file: {line}")
        except Exception as e:
            self._logger.error(f"Error reading feedback entries: {e}")
        
        return entries
    
    def _write_feedback_entries(self, entries: List[FeedbackEntry]) -> None:
        """
        Write feedback entries to the file.
        
        Args:
            entries: List of feedback entries
        """
        try:
            # Convert Enum values to strings for JSON serialization
            serializable_entries = [self._make_serializable(entry) for entry in entries]
            
            # Write to the file
            with open(self.feedback_file, "w") as f:
                for entry in serializable_entries:
                    f.write(json.dumps(entry) + "\n")
        except Exception as e:
            self._logger.error(f"Error writing feedback entries: {e}")
    
    def _make_serializable(self, entry: FeedbackEntry) -> Dict[str, Any]:
        """
        Convert Enum values to strings for JSON serialization.
        
        Args:
            entry: Feedback entry
            
        Returns:
            Serializable dictionary
        """
        serializable = dict(entry)
        
        # Convert Enum values to strings
        if "feedback_type" in serializable and isinstance(serializable["feedback_type"], Enum):
            serializable["feedback_type"] = serializable["feedback_type"].value
        
        if "feedback_category" in serializable and isinstance(serializable["feedback_category"], Enum):
            serializable["feedback_category"] = serializable["feedback_category"].value
        
        return serializable


# Singleton instance of the feedback store
_feedback_store_instance = None


def get_feedback_store(storage_dir: Optional[str] = None) -> FeedbackStore:
    """
    Get the singleton instance of the feedback store.
    
    Args:
        storage_dir: Optional directory to store feedback data
        
    Returns:
        The feedback store instance
    """
    global _feedback_store_instance
    if _feedback_store_instance is None:
        if storage_dir is None:
            storage_dir = os.path.join(os.getcwd(), "data", "feedback")
        _feedback_store_instance = FeedbackStore(storage_dir)
    return _feedback_store_instance