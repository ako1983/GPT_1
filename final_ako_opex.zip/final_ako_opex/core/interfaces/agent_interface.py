"""
Agent Interface Module

This module defines the core interfaces that all agents in the system must implement.
It establishes a standard contract for agent communication and behavior.
"""

from abc import ABC, abstractmethod
from typing import Dict, Any, Optional, List, Tuple
from enum import Enum


class AgentType(str, Enum):
    """Enumeration of available agent types in the system."""
    METADATA = "metadata"
    QUERY_ENHANCER = "query_enhancer"
    RAG = "rag"
    SQL = "sql"
    SQL_HELPER = "sql_helper"
    RESPONSE = "response"


class ExecutionStatus(str, Enum):
    """Enumeration of possible execution statuses."""
    PENDING = "pending"
    IN_PROGRESS = "in_progress"
    COMPLETED = "completed"
    FAILED = "failed"
    NEEDS_CLARIFICATION = "needs_clarification"


class Message:
    """Standard message format for inter-agent communication."""
    
    def __init__(
        self,
        sender: AgentType,
        receiver: AgentType,
        content: Dict[str, Any],
        message_type: str,
        trace_id: str,
        timestamp: Optional[float] = None
    ):
        """
        Initialize a new message.
        
        Args:
            sender: The agent that sent the message
            receiver: The intended recipient agent
            content: The payload of the message
            message_type: The type of message (e.g., "request", "response", "error")
            trace_id: Unique identifier for tracing this message through the system
            timestamp: Optional timestamp for when the message was created
        """
        import time
        
        self.sender = sender
        self.receiver = receiver
        self.content = content
        self.message_type = message_type
        self.trace_id = trace_id
        self.timestamp = timestamp or time.time()
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert the message to a dictionary representation."""
        return {
            "sender": self.sender,
            "receiver": self.receiver,
            "content": self.content,
            "message_type": self.message_type,
            "trace_id": self.trace_id,
            "timestamp": self.timestamp
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'Message':
        """Create a message from a dictionary representation."""
        return cls(
            sender=data["sender"],
            receiver=data["receiver"],
            content=data["content"],
            message_type=data["message_type"],
            trace_id=data["trace_id"],
            timestamp=data.get("timestamp")
        )


class Agent(ABC):
    """Base abstract class that all agents must implement."""
    
    def __init__(self, agent_id: str, agent_type: AgentType):
        """
        Initialize a new agent.
        
        Args:
            agent_id: Unique identifier for this agent instance
            agent_type: The type of agent this is
        """
        self.agent_id = agent_id
        self.agent_type = agent_type
        self.status = ExecutionStatus.PENDING
    
    @abstractmethod
    async def process(self, message: Message) -> Message:
        """
        Process an incoming message and produce a response.
        
        Args:
            message: The incoming message to process
            
        Returns:
            A response message
        """
        pass
    
    @abstractmethod
    async def initialize(self, config: Dict[str, Any]) -> bool:
        """
        Initialize the agent with configuration parameters.
        
        Args:
            config: Configuration parameters for this agent
            
        Returns:
            True if initialization was successful, False otherwise
        """
        pass
    
    @abstractmethod
    def get_capabilities(self) -> List[str]:
        """
        Return a list of capabilities this agent provides.
        
        Returns:
            List of capability strings
        """
        pass
    
    @abstractmethod
    def get_status(self) -> Dict[str, Any]:
        """
        Get the current status of this agent.
        
        Returns:
            A dictionary with status information
        """
        pass
    
    @abstractmethod
    async def shutdown(self) -> bool:
        """
        Perform any necessary cleanup when shutting down the agent.
        
        Returns:
            True if shutdown was successful, False otherwise
        """
        pass


class AgentFactory:
    """Factory for creating agent instances."""
    
    @staticmethod
    def create_agent(agent_type: AgentType, agent_id: Optional[str] = None, config: Optional[Dict[str, Any]] = None) -> Agent:
        """
        Create and return an agent of the specified type.
        
        Args:
            agent_type: The type of agent to create
            agent_id: Optional unique identifier for the agent
            config: Optional configuration parameters
            
        Returns:
            An initialized agent instance
            
        Raises:
            ValueError: If the agent type is not recognized
        """
        # This will be implemented when we have concrete agent implementations
        raise NotImplementedError("Agent factory implementation will be added when concrete agents are defined")