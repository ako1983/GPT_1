"""
Logging Setup Module

This module implements a comprehensive logging system for the text-to-SQL application.
It provides different verbosity levels and formats for various components.
"""

import os
import sys
import logging
import json
from datetime import datetime
from typing import Dict, Any, Optional, List, Union
import traceback


class LoggingSetup:
    """
    Configures and manages logging for the application.
    
    Features:
    1. Multiple log levels for different components
    2. Console and file output
    3. Structured logging for machine-readable logs
    4. Query tracking for analytics
    5. Performance metrics
    """
    
    # Default log formats
    DEFAULT_FORMAT = "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
    DETAILED_FORMAT = "%(asctime)s - %(name)s - %(levelname)s - [%(filename)s:%(lineno)d] - %(message)s"
    
    # Log levels
    LOG_LEVELS = {
        "debug": logging.DEBUG,
        "info": logging.INFO,
        "warning": logging.WARNING,
        "error": logging.ERROR,
        "critical": logging.CRITICAL
    }
    
    @classmethod
    def configure_root_logger(cls, log_level: str = "info", 
                             console_output: bool = True, 
                             log_file: Optional[str] = None,
                             detailed_format: bool = False) -> None:
        """
        Configure the root logger.
        
        Args:
            log_level: Log level (debug, info, warning, error, critical)
            console_output: Whether to output logs to the console
            log_file: Optional file to write logs to
            detailed_format: Whether to use the detailed log format
        """
        # Get the root logger
        root_logger = logging.getLogger()
        
        # Set the log level
        level = cls.LOG_LEVELS.get(log_level.lower(), logging.INFO)
        root_logger.setLevel(level)
        
        # Clear existing handlers
        for handler in root_logger.handlers[:]:
            root_logger.removeHandler(handler)
        
        # Create formatter
        log_format = cls.DETAILED_FORMAT if detailed_format else cls.DEFAULT_FORMAT
        formatter = logging.Formatter(log_format)
        
        # Add console handler if requested
        if console_output:
            console_handler = logging.StreamHandler(sys.stdout)
            console_handler.setFormatter(formatter)
            root_logger.addHandler(console_handler)
        
        # Add file handler if requested
        if log_file:
            # Create directory if it doesn't exist
            os.makedirs(os.path.dirname(log_file), exist_ok=True)
            
            file_handler = logging.FileHandler(log_file)
            file_handler.setFormatter(formatter)
            root_logger.addHandler(file_handler)
        
        root_logger.debug("Root logger configured")
    
    @classmethod
    def setup_logger(cls, name: str, log_level: Optional[str] = None, 
                    log_file: Optional[str] = None, 
                    detailed_format: bool = False) -> logging.Logger:
        """
        Set up a logger for a specific component.
        
        Args:
            name: Name of the logger
            log_level: Optional log level for this logger
            log_file: Optional file to write logs to
            detailed_format: Whether to use the detailed log format
            
        Returns:
            Configured logger
        """
        # Get the logger
        logger = logging.getLogger(name)
        
        # Set the log level if provided
        if log_level:
            level = cls.LOG_LEVELS.get(log_level.lower(), logging.INFO)
            logger.setLevel(level)
        
        # Add file handler if requested
        if log_file:
            # Create directory if it doesn't exist
            os.makedirs(os.path.dirname(log_file), exist_ok=True)
            
            # Create formatter
            log_format = cls.DETAILED_FORMAT if detailed_format else cls.DEFAULT_FORMAT
            formatter = logging.Formatter(log_format)
            
            file_handler = logging.FileHandler(log_file)
            file_handler.setFormatter(formatter)
            logger.addHandler(file_handler)
        
        return logger


class StructuredLogger:
    """
    Logger that outputs structured logs in JSON format.
    
    This is useful for machine-readable logs that can be ingested by
    log aggregation systems like ELK or parsed for analytics.
    """
    
    def __init__(self, component: str, log_file: Optional[str] = None, 
                console_output: bool = True):
        """
        Initialize a new structured logger.
        
        Args:
            component: Name of the component this logger is for
            log_file: Optional file to write logs to
            console_output: Whether to output logs to the console
        """
        self.component = component
        self.log_file = log_file
        self.console_output = console_output
        
        # Create the file handler if a log file is specified
        if log_file:
            os.makedirs(os.path.dirname(log_file), exist_ok=True)
        
        # Get a standard logger for internal use
        self._logger = logging.getLogger(f"structured.{component}")
    
    def log(self, level: str, message: str, **kwargs) -> None:
        """
        Log a message with additional structured data.
        
        Args:
            level: Log level (debug, info, warning, error, critical)
            message: Log message
            **kwargs: Additional structured data to include in the log
        """
        log_data = {
            "timestamp": datetime.utcnow().isoformat(),
            "component": self.component,
            "level": level,
            "message": message
        }
        
        # Add additional data
        log_data.update(kwargs)
        
        # Serialize to JSON
        log_json = json.dumps(log_data)
        
        # Output to console if requested
        if self.console_output:
            print(log_json)
        
        # Write to file if specified
        if self.log_file:
            with open(self.log_file, "a") as f:
                f.write(log_json + "\n")
        
        # Also log to the standard logger
        log_method = getattr(self._logger, level.lower(), self._logger.info)
        log_method(message)
    
    def debug(self, message: str, **kwargs) -> None:
        """Log a debug message."""
        self.log("debug", message, **kwargs)
    
    def info(self, message: str, **kwargs) -> None:
        """Log an info message."""
        self.log("info", message, **kwargs)
    
    def warning(self, message: str, **kwargs) -> None:
        """Log a warning message."""
        self.log("warning", message, **kwargs)
    
    def error(self, message: str, **kwargs) -> None:
        """Log an error message."""
        self.log("error", message, **kwargs)
    
    def critical(self, message: str, **kwargs) -> None:
        """Log a critical message."""
        self.log("critical", message, **kwargs)
    
    def exception(self, message: str, exc_info: Optional[Exception] = None, **kwargs) -> None:
        """
        Log an exception.
        
        Args:
            message: Log message
            exc_info: Exception info
            **kwargs: Additional structured data
        """
        # Get exception info if not provided
        if exc_info is None:
            exc_info = sys.exc_info()[1]
        
        # Add exception details to kwargs
        kwargs["exception"] = {
            "type": exc_info.__class__.__name__ if exc_info else None,
            "message": str(exc_info) if exc_info else None,
            "traceback": traceback.format_exc()
        }
        
        self.error(message, **kwargs)


class QueryLogger:
    """
    Specialized logger for tracking queries and their processing.
    
    This logger is used to record information about user queries,
    their processing pipeline, and results for later analysis.
    """
    
    def __init__(self, log_dir: str):
        """
        Initialize a new query logger.
        
        Args:
            log_dir: Directory to write query logs to
        """
        self.log_dir = log_dir
        os.makedirs(log_dir, exist_ok=True)
        
        # Create a standard logger for internal use
        self._logger = logging.getLogger("query_logger")
        
        # Path to the query log file
        self.query_log_file = os.path.join(log_dir, "query_log.jsonl")
    
    def log_query(self, query_id: str, query_data: Dict[str, Any]) -> None:
        """
        Log information about a query.
        
        Args:
            query_id: ID of the query
            query_data: Data about the query
        """
        # Add timestamp
        query_data["timestamp"] = datetime.utcnow().isoformat()
        query_data["query_id"] = query_id
        
        # Serialize to JSON
        log_json = json.dumps(query_data)
        
        # Write to the query log file
        with open(self.query_log_file, "a") as f:
            f.write(log_json + "\n")
        
        self._logger.info(f"Logged query {query_id}")
    
    def log_query_step(self, query_id: str, step: str, step_data: Dict[str, Any]) -> None:
        """
        Log information about a step in query processing.
        
        Args:
            query_id: ID of the query
            step: Name of the step
            step_data: Data about the step
        """
        # Create step log data
        log_data = {
            "query_id": query_id,
            "step": step,
            "timestamp": datetime.utcnow().isoformat()
        }
        
        # Add step data
        log_data.update(step_data)
        
        # Serialize to JSON
        log_json = json.dumps(log_data)
        
        # Path to the step log file
        step_log_file = os.path.join(self.log_dir, f"query_steps.jsonl")
        
        # Write to the step log file
        with open(step_log_file, "a") as f:
            f.write(log_json + "\n")
        
        self._logger.debug(f"Logged step {step} for query {query_id}")
    
    def log_query_result(self, query_id: str, result: Dict[str, Any]) -> None:
        """
        Log the result of a query.
        
        Args:
            query_id: ID of the query
            result: Result of the query
        """
        # Create result log data
        log_data = {
            "query_id": query_id,
            "timestamp": datetime.utcnow().isoformat(),
            "result": result
        }
        
        # Serialize to JSON
        log_json = json.dumps(log_data)
        
        # Path to the result log file
        result_log_file = os.path.join(self.log_dir, f"query_results.jsonl")
        
        # Write to the result log file
        with open(result_log_file, "a") as f:
            f.write(log_json + "\n")
        
        self._logger.info(f"Logged result for query {query_id}")
    
    def log_query_error(self, query_id: str, error: Union[str, Exception], 
                       details: Optional[Dict[str, Any]] = None) -> None:
        """
        Log an error in query processing.
        
        Args:
            query_id: ID of the query
            error: Error message or exception
            details: Additional details about the error
        """
        # Create error log data
        log_data = {
            "query_id": query_id,
            "timestamp": datetime.utcnow().isoformat(),
            "error": str(error),
            "error_type": error.__class__.__name__ if isinstance(error, Exception) else None,
            "traceback": traceback.format_exc() if isinstance(error, Exception) else None
        }
        
        # Add additional details
        if details:
            log_data.update(details)
        
        # Serialize to JSON
        log_json = json.dumps(log_data)
        
        # Path to the error log file
        error_log_file = os.path.join(self.log_dir, f"query_errors.jsonl")
        
        # Write to the error log file
        with open(error_log_file, "a") as f:
            f.write(log_json + "\n")
        
        self._logger.error(f"Logged error for query {query_id}: {error}")
    
    def get_query_logs(self, query_id: Optional[str] = None, 
                      limit: Optional[int] = None) -> List[Dict[str, Any]]:
        """
        Get logs for a specific query or all queries.
        
        Args:
            query_id: Optional ID of the query to get logs for
            limit: Optional maximum number of logs to return
            
        Returns:
            List of query logs
        """
        logs = []
        
        try:
            with open(self.query_log_file, "r") as f:
                for line in f:
                    try:
                        log_data = json.loads(line)
                        if query_id is None or log_data.get("query_id") == query_id:
                            logs.append(log_data)
                    except json.JSONDecodeError:
                        self._logger.warning(f"Invalid JSON in query log: {line}")
        except FileNotFoundError:
            self._logger.warning(f"Query log file not found: {self.query_log_file}")
        
        # Sort by timestamp (newest first)
        logs.sort(key=lambda x: x.get("timestamp", ""), reverse=True)
        
        # Apply limit if specified
        if limit is not None:
            logs = logs[:limit]
        
        return logs