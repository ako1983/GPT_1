"""
Core Package

This package contains the foundational components for the text-to-SQL system.
"""

# Set up version
__version__ = "0.1.0"

# Import core components for easy access
from .interfaces.agent_interface import Agent, AgentType, ExecutionStatus, Message, AgentFactory
from .communication.event_bus import EventBus, get_event_bus
from .state.state_manager import StateManager, QueryState, get_state_manager
from .memory.conversation_store import ConversationStore, MessageRole, get_conversation_store
from .memory.vector_store import VectorStore, Document, create_vector_store
from .memory.feedback_store import FeedbackStore, FeedbackType, FeedbackCategory, get_feedback_store
from .logging.logging_setup import LoggingSetup, StructuredLogger, QueryLogger