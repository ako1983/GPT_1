"""
Results Analyzer Module

This module analyzes query results to identify insights, patterns, and notable
information that should be highlighted in the response.
"""

import logging
import re
from typing import Dict, List, Any, Optional, Tuple, Union
import pandas as pd
import numpy as np
from datetime import datetime, timedelta


class ResultsAnalyzer:
    """
    Analyzes query results for insights and notable patterns.
    
    The ResultsAnalyzer:
    1. Identifies trends and patterns in the result data
    2. Calculates statistical measures and key metrics
    3. Detects anomalies and outliers in the data
    4. Prioritizes information for inclusion in the response
    5. Generates insights based on domain-specific rules
    """
    
    def __init__(self, config: Dict[str, Any] = None):
        """
        Initialize a new results analyzer.
        
        Args:
            config: Configuration parameters
        """
        self._logger = logging.getLogger(__name__)
        self._config = config or {}
        
        # Load analysis configuration
        self._significance_threshold = self._config.get("significance_threshold", 0.1)
        self._time_series_periods = self._config.get("time_series_periods", 3)
        self._max_insights = self._config.get("max_insights", 5)
        self._detect_outliers = self._config.get("detect_outliers", True)
        self._outlier_threshold = self._config.get("outlier_threshold", 2.0)
        self._domain_specific_rules = self._config.get("domain_specific_rules", {})
    
    def analyze_results(self, results: List[Dict[str, Any]], query_context: Dict[str, Any],
                       metadata: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """
        Analyze results to extract insights and notable information.
        
        Args:
            results: Result data to analyze
            query_context: Context information about the query
            metadata: Optional metadata about the results
            
        Returns:
            Dictionary with analysis results
        """
        if not results:
            return {
                "insights": [],
                "statistics": {},
                "trends": [],
                "anomalies": []
            }
        
        try:
            # Convert results to DataFrame for analysis
            df = pd.DataFrame(results)
            
            # Initialize analysis result
            analysis = {
                "insights": [],
                "statistics": {},
                "trends": [],
                "anomalies": []
            }
            
            # Perform different types of analysis based on query intent
            intent = query_context.get("intent", "retrieval")
            
            if intent == "aggregation" or intent == "summary":
                # Analyze aggregate results
                analysis["statistics"] = self._calculate_statistics(df)
                
            if intent == "trend" or intent == "time_series":
                # Analyze time series data
                analysis["trends"] = self._analyze_trends(df, query_context)
                
            if intent == "comparison":
                # Analyze comparison data
                analysis["comparisons"] = self._analyze_comparisons(df, query_context)
            
            # Detect anomalies if enabled
            if self._detect_outliers:
                analysis["anomalies"] = self._detect_anomalies(df)
            
            # Apply domain-specific rules
            domain_insights = self._apply_domain_rules(df, query_context, metadata)
            analysis["insights"].extend(domain_insights)
            
            # Generate general insights
            general_insights = self._generate_insights(df, analysis, query_context)
            analysis["insights"].extend(general_insights)
            
            # Limit the number of insights
            if len(analysis["insights"]) > self._max_insights:
                analysis["insights"] = analysis["insights"][:self._max_insights]
            
            return analysis
            
        except Exception as e:
            self._logger.error(f"Error analyzing results: {str(e)}")
            return {
                "error": str(e),
                "insights": [],
                "statistics": {},
                "trends": [],
                "anomalies": []
            }
    
    def _calculate_statistics(self, df: pd.DataFrame) -> Dict[str, Any]:
        """
        Calculate statistical measures for the data.
        
        Args:
            df: DataFrame with result data
            
        Returns:
            Dictionary with statistical measures
        """
        stats = {}
        
        # Get numeric columns
        numeric_cols = df.select_dtypes(include=[np.number]).columns.tolist()
        
        for col in numeric_cols:
            col_stats = {}
            
            # Basic statistics
            col_stats["mean"] = df[col].mean()
            col_stats["median"] = df[col].median()
            col_stats["min"] = df[col].min()
            col_stats["max"] = df[col].max()
            col_stats["sum"] = df[col].sum()
            col_stats["count"] = df[col].count()
            
            # Additional statistics for financial columns
            if any(kw in col.lower() for kw in ["amt", "amount", "cost", "price", "budget", "spend", "expense"]):
                col_stats["total"] = df[col].sum()
                
                # Calculate variance and standard deviation if there are enough values
                if len(df) > 1:
                    col_stats["variance"] = df[col].var()
                    col_stats["std_dev"] = df[col].std()
                
                # Calculate quarter-over-quarter or year-over-year change if time data is present
                time_cols = [c for c in df.columns if any(kw in c.lower() for kw in ["date", "year", "quarter", "month"])]
                if time_cols and len(df) > 1:
                    # Attempt to calculate change over time
                    try:
                        df_sorted = df.sort_values(by=time_cols[0])
                        if len(df_sorted) >= 2:
                            earliest = df_sorted[col].iloc[0]
                            latest = df_sorted[col].iloc[-1]
                            if earliest != 0:
                                col_stats["change_pct"] = (latest - earliest) / earliest
                            else:
                                col_stats["change_pct"] = None
                            col_stats["change_abs"] = latest - earliest
                    except Exception as e:
                        self._logger.warning(f"Could not calculate change over time: {str(e)}")
            
            stats[col] = col_stats
        
        # Add count statistics for categorical columns
        categorical_cols = df.select_dtypes(include=["object"]).columns.tolist()
        for col in categorical_cols:
            if len(df[col].unique()) <= 10:  # Only include if there are relatively few categories
                counts = df[col].value_counts().to_dict()
                stats[f"{col}_counts"] = counts
        
        return stats
    
    def _analyze_trends(self, df: pd.DataFrame, query_context: Dict[str, Any]) -> List[Dict[str, Any]]:
        """
        Analyze time series data for trends.
        
        Args:
            df: DataFrame with result data
            query_context: Context information about the query
            
        Returns:
            List of trend information
        """
        trends = []
        
        # Identify time column
        time_cols = [col for col in df.columns 
                    if any(kw in col.lower() for kw in ["date", "time", "period", "month", "quarter", "year"])]
        
        if not time_cols:
            return trends
        
        time_col = time_cols[0]
        
        # Get numeric columns to analyze for trends
        numeric_cols = df.select_dtypes(include=[np.number]).columns.tolist()
        
        # Sort by time column
        try:
            df_sorted = df.sort_values(by=time_col)
        except Exception:
            # If sorting fails, return empty trends
            return trends
        
        # Analyze each numeric column for trends
        for col in numeric_cols:
            if len(df_sorted) < 2:
                continue
                
            # Calculate simple trends
            trend_info = {}
            trend_info["column"] = col
            
            # Get the values
            values = df_sorted[col].tolist()
            
            # Calculate direction
            if values[-1] > values[0]:
                trend_info["direction"] = "increasing"
                trend_info["change_pct"] = (values[-1] - values[0]) / values[0] if values[0] != 0 else None
                trend_info["change_abs"] = values[-1] - values[0]
            elif values[-1] < values[0]:
                trend_info["direction"] = "decreasing"
                trend_info["change_pct"] = (values[-1] - values[0]) / values[0] if values[0] != 0 else None
                trend_info["change_abs"] = values[-1] - values[0]
            else:
                trend_info["direction"] = "stable"
                trend_info["change_pct"] = 0
                trend_info["change_abs"] = 0
            
            # Calculate consistency
            increases = sum(1 for i in range(1, len(values)) if values[i] > values[i-1])
            decreases = sum(1 for i in range(1, len(values)) if values[i] < values[i-1])
            same = sum(1 for i in range(1, len(values)) if values[i] == values[i-1])
            
            total_changes = len(values) - 1
            if total_changes > 0:
                trend_info["consistency"] = max(increases, decreases, same) / total_changes
            else:
                trend_info["consistency"] = 1.0
            
            # Determine if the trend is significant
            if abs(trend_info.get("change_pct", 0) or 0) > self._significance_threshold:
                trend_info["significant"] = True
            else:
                trend_info["significant"] = False
            
            # Add the trend to the list
            trends.append(trend_info)
        
        # Sort trends by significance
        trends.sort(key=lambda x: abs(x.get("change_pct", 0) or 0), reverse=True)
        
        return trends
    
    def _analyze_comparisons(self, df: pd.DataFrame, query_context: Dict[str, Any]) -> List[Dict[str, Any]]:
        """
        Analyze comparison data.
        
        Args:
            df: DataFrame with result data
            query_context: Context information about the query
            
        Returns:
            List of comparison information
        """
        comparisons = []
        
        # Identify category column
        category_cols = [col for col in df.columns 
                        if col.lower() in ["category", "name", "type", "group", "segment"]]
        
        if not category_cols:
            # No obvious category column, try to identify based on cardinality
            non_numeric_cols = df.select_dtypes(exclude=[np.number]).columns.tolist()
            if non_numeric_cols:
                # Use the column with the fewest unique values as the category
                cardinalities = [(col, df[col].nunique()) for col in non_numeric_cols]
                cardinalities.sort(key=lambda x: x[1])
                if cardinalities and cardinalities[0][1] <= 10:
                    category_cols = [cardinalities[0][0]]
        
        if not category_cols:
            return comparisons
        
        category_col = category_cols[0]
        
        # Get numeric columns to compare
        numeric_cols = df.select_dtypes(include=[np.number]).columns.tolist()
        
        # Analyze each numeric column for comparisons
        for col in numeric_cols:
            if len(df) < 2:
                continue
                
            # Calculate comparison statistics
            comparison_info = {}
            comparison_info["column"] = col
            comparison_info["categories"] = {}
            
            # Get the values for each category
            categories = df[category_col].unique()
            for category in categories:
                category_value = df[df[category_col] == category][col].iloc[0] if not df[df[category_col] == category].empty else None
                comparison_info["categories"][category] = category_value
            
            # Find the highest and lowest categories
            valid_categories = {k: v for k, v in comparison_info["categories"].items() if v is not None}
            if valid_categories:
                highest_category = max(valid_categories.items(), key=lambda x: x[1])
                lowest_category = min(valid_categories.items(), key=lambda x: x[1])
                
                comparison_info["highest"] = {
                    "category": highest_category[0],
                    "value": highest_category[1]
                }
                
                comparison_info["lowest"] = {
                    "category": lowest_category[0],
                    "value": lowest_category[1]
                }
                
                # Calculate percentage difference between highest and lowest
                if lowest_category[1] != 0:
                    comparison_info["difference_pct"] = (highest_category[1] - lowest_category[1]) / lowest_category[1]
                else:
                    comparison_info["difference_pct"] = None
                
                comparison_info["difference_abs"] = highest_category[1] - lowest_category[1]
                
                # Determine if the difference is significant
                if abs(comparison_info.get("difference_pct", 0) or 0) > self._significance_threshold:
                    comparison_info["significant"] = True
                else:
                    comparison_info["significant"] = False
            
            # Add the comparison to the list
            comparisons.append(comparison_info)
        
        # Sort comparisons by significance
        comparisons.sort(key=lambda x: abs(x.get("difference_pct", 0) or 0), reverse=True)
        
        return comparisons
    
    def _detect_anomalies(self, df: pd.DataFrame) -> List[Dict[str, Any]]:
        """
        Detect anomalies in the data.
        
        Args:
            df: DataFrame with result data
            
        Returns:
            List of anomaly information
        """
        anomalies = []
        
        # Get numeric columns to check for anomalies
        numeric_cols = df.select_dtypes(include=[np.number]).columns.tolist()
        
        for col in numeric_cols:
            # Calculate mean and standard deviation
            mean = df[col].mean()
            std = df[col].std()
            
            # Skip if there's not enough variation
            if std == 0:
                continue
            
            # Find values more than threshold standard deviations from the mean
            outliers_high = df[df[col] > mean + self._outlier_threshold * std]
            outliers_low = df[df[col] < mean - self._outlier_threshold * std]
            
            # Add high outliers
            for _, row in outliers_high.iterrows():
                anomaly = {
                    "column": col,
                    "value": row[col],
                    "direction": "high",
                    "z_score": (row[col] - mean) / std,
                    "context": {}
                }
                
                # Add context columns
                for context_col in df.columns:
                    if context_col != col:
                        anomaly["context"][context_col] = row[context_col]
                
                anomalies.append(anomaly)
            
            # Add low outliers
            for _, row in outliers_low.iterrows():
                anomaly = {
                    "column": col,
                    "value": row[col],
                    "direction": "low",
                    "z_score": (row[col] - mean) / std,
                    "context": {}
                }
                
                # Add context columns
                for context_col in df.columns:
                    if context_col != col:
                        anomaly["context"][context_col] = row[context_col]
                
                anomalies.append(anomaly)
        
        # Sort anomalies by absolute z-score
        anomalies.sort(key=lambda x: abs(x["z_score"]), reverse=True)
        
        return anomalies
    
    def _apply_domain_rules(self, df: pd.DataFrame, query_context: Dict[str, Any],
                          metadata: Optional[Dict[str, Any]] = None) -> List[Dict[str, Any]]:
        """
        Apply domain-specific rules to generate insights.
        
        Args:
            df: DataFrame with result data
            query_context: Context information about the query
            metadata: Optional metadata about the results
            
        Returns:
            List of insights based on domain rules
        """
        insights = []
        
        # Apply rules from configuration
        for rule_name, rule_config in self._domain_specific_rules.items():
            try:
                rule_type = rule_config.get("type")
                
                if rule_type == "threshold":
                    # Apply threshold rule
                    column = rule_config.get("column")
                    threshold = rule_config.get("threshold")
                    comparison = rule_config.get("comparison", "greater_than")
                    
                    if column in df.columns:
                        if comparison == "greater_than" and (df[column] > threshold).any():
                            insights.append({
                                "type": "threshold_exceeded",
                                "rule": rule_name,
                                "column": column,
                                "threshold": threshold,
                                "message": rule_config.get("message", f"{column} exceeds threshold of {threshold}")
                            })
                        elif comparison == "less_than" and (df[column] < threshold).any():
                            insights.append({
                                "type": "threshold_below",
                                "rule": rule_name,
                                "column": column,
                                "threshold": threshold,
                                "message": rule_config.get("message", f"{column} is below threshold of {threshold}")
                            })
                
                elif rule_type == "pattern":
                    # Apply pattern rule
                    pattern = rule_config.get("pattern")
                    column = rule_config.get("column")
                    
                    if column in df.columns and pattern:
                        matches = df[df[column].astype(str).str.contains(pattern, regex=True, na=False)]
                        if not matches.empty:
                            insights.append({
                                "type": "pattern_match",
                                "rule": rule_name,
                                "column": column,
                                "pattern": pattern,
                                "message": rule_config.get("message", f"{column} matches pattern {pattern}")
                            })
                
                elif rule_type == "budget_variance":
                    # Special rule for budget variance analysis
                    budget_col = rule_config.get("budget_column", "budget_amt")
                    actual_col = rule_config.get("actual_column", "actual_amt")
                    
                    if budget_col in df.columns and actual_col in df.columns:
                        # Calculate variance
                        df["variance"] = df[actual_col] - df[budget_col]
                        df["variance_pct"] = df["variance"] / df[budget_col]
                        
                        # Find significant variances
                        threshold = rule_config.get("significance_threshold", 0.1)
                        significant_variances = df[abs(df["variance_pct"]) > threshold]
                        
                        if not significant_variances.empty:
                            # Get the largest variance
                            largest_variance_idx = significant_variances["variance_pct"].abs().idxmax()
                            largest_variance = significant_variances.loc[largest_variance_idx]
                            
                            # Create insight
                            context = {}
                            for col in df.columns:
                                if col not in [budget_col, actual_col, "variance", "variance_pct"]:
                                    context[col] = largest_variance[col]
                            
                            insights.append({
                                "type": "budget_variance",
                                "rule": rule_name,
                                "budget": largest_variance[budget_col],
                                "actual": largest_variance[actual_col],
                                "variance": largest_variance["variance"],
                                "variance_pct": largest_variance["variance_pct"],
                                "context": context,
                                "message": rule_config.get("message", "Significant budget variance detected")
                            })
            
            except Exception as e:
                self._logger.warning(f"Error applying rule {rule_name}: {str(e)}")
        
        return insights
    
    def _generate_insights(self, df: pd.DataFrame, analysis: Dict[str, Any], 
                         query_context: Dict[str, Any]) -> List[Dict[str, Any]]:
        """
        Generate general insights based on the analysis.
        
        Args:
            df: DataFrame with result data
            analysis: Analysis results
            query_context: Context information about the query
            
        Returns:
            List of general insights
        """
        insights = []
        
        # Generate insights from trends
        for trend in analysis.get("trends", []):
            if trend.get("significant", False):
                column = trend.get("column", "")
                direction = trend.get("direction", "")
                change_pct = trend.get("change_pct")
                
                if change_pct is not None:
                    insights.append({
                        "type": "trend",
                        "column": column,
                        "direction": direction,
                        "change_pct": change_pct,
                        "message": f"{column} is {direction} by {abs(change_pct)*100:.1f}%"
                    })
        
        # Generate insights from comparisons
        for comparison in analysis.get("comparisons", []):
            if comparison.get("significant", False):
                column = comparison.get("column", "")
                highest = comparison.get("highest", {})
                lowest = comparison.get("lowest", {})
                
                if highest and lowest:
                    insights.append({
                        "type": "comparison",
                        "column": column,
                        "highest_category": highest.get("category"),
                        "highest_value": highest.get("value"),
                        "lowest_category": lowest.get("category"),
                        "lowest_value": lowest.get("value"),
                        "difference_pct": comparison.get("difference_pct"),
                        "message": f"{highest.get('category')} has {column} {highest.get('value')}, which is {abs(comparison.get('difference_pct', 0) or 0)*100:.1f}% higher than {lowest.get('category')}"
                    })
        
        # Generate insights from anomalies
        for anomaly in analysis.get("anomalies", [])[:3]:  # Limit to top 3 anomalies
            column = anomaly.get("column", "")
            value = anomaly.get("value")
            direction = anomaly.get("direction", "")
            z_score = anomaly.get("z_score")
            
            context_str = ""
            context = anomaly.get("context", {})
            for key, val in context.items():
                if key in ["date", "month", "quarter", "year", "category", "name", "type"]:
                    context_str = f" for {key} {val}"
                    break
            
            insights.append({
                "type": "anomaly",
                "column": column,
                "value": value,
                "direction": direction,
                "z_score": z_score,
                "message": f"{column} has an unusually {direction} value of {value}{context_str}"
            })
        
        # Generate statistics-based insights
        for col, stats in analysis.get("statistics", {}).items():
            # Skip non-numeric columns
            if isinstance(stats, dict) and "mean" in stats:
                # Check for significant changes over time
                if "change_pct" in stats and stats["change_pct"] is not None:
                    if abs(stats["change_pct"]) > self._significance_threshold:
                        direction = "increased" if stats["change_pct"] > 0 else "decreased"
                        insights.append({
                            "type": "statistic",
                            "column": col,
                            "statistic": "change_over_time",
                            "value": stats["change_pct"],
                            "message": f"{col} has {direction} by {abs(stats['change_pct'])*100:.1f}% over the period"
                        })
        
        return insights