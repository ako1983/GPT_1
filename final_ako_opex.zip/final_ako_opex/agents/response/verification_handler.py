"""
Verification Handler Module

This module performs final verification of response accuracy before sending to the user,
ensuring that the information is correct, properly sourced, and appropriately qualified.
"""

import logging
import re
import json
from typing import Dict, List, Any, Optional, Union
from datetime import datetime


class VerificationHandler:
    """
    Performs final verification of response accuracy.
    
    The VerificationHandler:
    1. Validates that responses include proper source citations
    2. Ensures response data matches the original query results
    3. Verifies confidence levels are appropriate
    4. Checks for financial calculation accuracy
    5. Ensures appropriate qualifiers for estimates or projections
    """
    
    def __init__(self, config: Dict[str, Any] = None):
        """
        Initialize a new verification handler.
        
        Args:
            config: Configuration parameters
        """
        self._logger = logging.getLogger(__name__)
        self._config = config or {}
        
        # Load verification configuration
        self._verification_checks = self._config.get("verification_checks", ["source", "data", "confidence", "calculations", "qualifiers"])
        self._min_sources_required = self._config.get("min_sources_required", 1)
        self._require_data_lineage = self._config.get("require_data_lineage", True)
        self._confidence_required = self._config.get("confidence_required", True)
        self._verify_calculations = self._config.get("verify_calculations", True)
        self._max_allowed_error = self._config.get("max_allowed_error", 0.01)  # 1% error tolerance
    
    def verify_response(self, response: Dict[str, Any], original_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Verify the accuracy and completeness of a response.
        
        Args:
            response: The formatted response to verify
            original_data: The original data used to generate the response
            
        Returns:
            Dictionary with verification results
        """
        verification_result = {
            "verified": True,
            "checks": {},
            "warnings": [],
            "errors": []
        }
        
        try:
            # Perform requested verification checks
            if "source" in self._verification_checks:
                source_result = self._verify_sources(response, original_data)
                verification_result["checks"]["source"] = source_result
                if not source_result["passed"]:
                    verification_result["verified"] = False
                    verification_result["errors"].extend(source_result["errors"])
                    verification_result["warnings"].extend(source_result["warnings"])
            
            if "data" in self._verification_checks:
                data_result = self._verify_data_accuracy(response, original_data)
                verification_result["checks"]["data"] = data_result
                if not data_result["passed"]:
                    verification_result["verified"] = False
                    verification_result["errors"].extend(data_result["errors"])
                    verification_result["warnings"].extend(data_result["warnings"])
            
            if "confidence" in self._verification_checks:
                confidence_result = self._verify_confidence(response, original_data)
                verification_result["checks"]["confidence"] = confidence_result
                if not confidence_result["passed"]:
                    verification_result["verified"] = False
                    verification_result["errors"].extend(confidence_result["errors"])
                    verification_result["warnings"].extend(confidence_result["warnings"])
            
            if "calculations" in self._verification_checks:
                calc_result = self._verify_calculations_accuracy(response, original_data)
                verification_result["checks"]["calculations"] = calc_result
                if not calc_result["passed"]:
                    verification_result["verified"] = False
                    verification_result["errors"].extend(calc_result["errors"])
                    verification_result["warnings"].extend(calc_result["warnings"])
            
            if "qualifiers" in self._verification_checks:
                qualifier_result = self._verify_qualifiers(response, original_data)
                verification_result["checks"]["qualifiers"] = qualifier_result
                if not qualifier_result["passed"]:
                    verification_result["verified"] = False
                    verification_result["errors"].extend(qualifier_result["errors"])
                    verification_result["warnings"].extend(qualifier_result["warnings"])
            
            # Add verification metadata
            verification_result["verification_timestamp"] = datetime.now().isoformat()
            verification_result["verification_version"] = "1.0"
            
            return verification_result
            
        except Exception as e:
            self._logger.error(f"Error verifying response: {str(e)}")
            return {
                "verified": False,
                "errors": [f"Verification error: {str(e)}"],
                "warnings": ["Response could not be fully verified"],
                "verification_timestamp": datetime.now().isoformat()
            }
    
    def _verify_sources(self, response: Dict[str, Any], original_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Verify that response includes proper source citations.
        
        Args:
            response: The formatted response to verify
            original_data: The original data used to generate the response
            
        Returns:
            Dictionary with source verification results
        """
        result = {
            "passed": True,
            "errors": [],
            "warnings": []
        }
        
        # Check for data source section
        if "data_source" not in response and self._require_data_lineage:
            result["passed"] = False
            result["errors"].append("Response is missing data source information")
        
        # Check if response mentions the data sources
        data_source_text = ""
        if isinstance(response.get("data_source"), str):
            data_source_text = response["data_source"]
        elif isinstance(response.get("data_source"), dict):
            data_source_text = json.dumps(response["data_source"])
        
        tables = original_data.get("metadata", {}).get("tables", [])
        
        # Check if all tables are mentioned in the data source
        mentioned_tables = 0
        for table in tables:
            if table in data_source_text:
                mentioned_tables += 1
        
        if mentioned_tables < len(tables) and len(tables) > 0:
            result["warnings"].append(f"Response mentions only {mentioned_tables} of {len(tables)} data sources")
            if mentioned_tables < self._min_sources_required:
                result["passed"] = False
                result["errors"].append(f"Response does not meet minimum source citation requirement ({self._min_sources_required})")
        
        # Check for SQL inclusion if required
        if self._config.get("include_sql", False) and "sql" in original_data:
            if "sql" not in response and "query" not in response:
                result["warnings"].append("Response does not include the SQL query used")
        
        # Check for time period information
        time_period = original_data.get("metadata", {}).get("time_period")
        if time_period and not any(period in data_source_text for period in time_period):
            result["warnings"].append("Response does not clearly specify the time period of the data")
        
        return result
    
    def _verify_data_accuracy(self, response: Dict[str, Any], original_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Verify that response data matches the original query results.
        
        Args:
            response: The formatted response to verify
            original_data: The original data used to generate the response
            
        Returns:
            Dictionary with data accuracy verification results
        """
        result = {
            "passed": True,
            "errors": [],
            "warnings": []
        }
        
        # Get the original results
        original_results = original_data.get("results", [])
        if not original_results:
            result["warnings"].append("No original results to verify against")
            return result
        
        # Get response text for checking
        response_text = ""
        if "summary" in response and isinstance(response["summary"], str):
            response_text += response["summary"] + " "
        
        if "results" in response:
            if isinstance(response["results"], str):
                response_text += response["results"] + " "
            elif isinstance(response["results"], (list, dict)):
                response_text += json.dumps(response["results"]) + " "
        
        # Check for key values from the original results
        checked_values = 0
        matched_values = 0
        
        for result_item in original_results:
            for key, value in result_item.items():
                # Focus on checking numeric values
                if isinstance(value, (int, float)) and key.lower() not in ["id", "index", "row"]:
                    checked_values += 1
                    
                    # Check if the value appears in the response
                    # Allow for different formatting of numbers
                    str_value = str(value)
                    int_value = int(value) if value == int(value) else None
                    
                    if str_value in response_text:
                        matched_values += 1
                    elif int_value is not None and str(int_value) in response_text:
                        matched_values += 1
                    else:
                        # Try with different number formatting
                        formatted_value = f"{value:,}" if value >= 1000 else None
                        if formatted_value and formatted_value in response_text:
                            matched_values += 1
        
        # Calculate match percentage
        if checked_values > 0:
            match_percentage = (matched_values / checked_values) * 100
            result["match_percentage"] = match_percentage
            
            # Add warning if match percentage is low
            if match_percentage < 50:
                result["warnings"].append(f"Response contains only {match_percentage:.1f}% of key values from the original data")
                if match_percentage < 20:
                    result["passed"] = False
                    result["errors"].append("Response data significantly differs from original results")
        else:
            result["warnings"].append("No numeric values to check in the original data")
        
        return result
    
    def _verify_confidence(self, response: Dict[str, Any], original_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Verify that confidence levels are appropriate.
        
        Args:
            response: The formatted response to verify
            original_data: The original data used to generate the response
            
        Returns:
            Dictionary with confidence verification results
        """
        result = {
            "passed": True,
            "errors": [],
            "warnings": []
        }
        
        # Check if confidence is required but missing
        if self._confidence_required and "confidence" not in response:
            result["passed"] = False
            result["errors"].append("Response is missing required confidence information")
            return result
        
        # If confidence is provided, check its appropriateness
        if "confidence" in response:
            confidence = response["confidence"]
            confidence_level = None
            
            if isinstance(confidence, dict):
                confidence_level = confidence.get("level")
            elif isinstance(confidence, str):
                confidence_level = confidence
            
            # Check if confidence level is appropriate
            if confidence_level:
                metadata = original_data.get("metadata", {})
                
                # Downgrade confidence if data is incomplete or old
                if metadata.get("partial_data", False) and confidence_level == "High":
                    result["warnings"].append("Confidence level should not be 'High' with partial data")
                    result["passed"] = False
                
                if metadata.get("data_freshness_days", 0) > 30 and confidence_level == "High":
                    result["warnings"].append("Confidence level should not be 'High' with data older than 30 days")
                    result["passed"] = False
                
                # Check confidence against calculation complexity
                if metadata.get("calculation_complexity", "simple") == "complex" and confidence_level == "High":
                    result["warnings"].append("Confidence level should not be 'High' with complex calculations")
                    result["passed"] = False
        
        return result
    
    def _verify_calculations_accuracy(self, response: Dict[str, Any], original_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Verify financial calculation accuracy.
        
        Args:
            response: The formatted response to verify
            original_data: The original data used to generate the response
            
        Returns:
            Dictionary with calculation accuracy verification results
        """
        result = {
            "passed": True,
            "errors": [],
            "warnings": []
        }
        
        if not self._verify_calculations:
            return result
        
        # Extract numbers from response text
        response_text = ""
        if "summary" in response and isinstance(response["summary"], str):
            response_text += response["summary"] + " "
        
        # Extract calculations from original data
        calculations = original_data.get("metadata", {}).get("calculations", [])
        if not calculations:
            # No explicit calculations to verify
            return result
        
        # Verify each calculation
        for calc in calculations:
            calc_type = calc.get("type")
            expected_result = calc.get("result")
            description = calc.get("description", "calculation")
            
            if not expected_result:
                continue
            
            # Look for the result in the response
            found = False
            
            # Check for exact match
            if str(expected_result) in response_text:
                found = True
            else:
                # Check with different formatting
                try:
                    if isinstance(expected_result, (int, float)):
                        # Try with different formatting
                        formatted_values = [
                            f"{expected_result:,}",
                            f"{expected_result:.1f}",
                            f"{expected_result:.2f}"
                        ]
                        
                        for value in formatted_values:
                            if value in response_text:
                                found = True
                                break
                        
                        # Allow for small rounding differences
                        if not found:
                            for match in re.finditer(r'[-+]?\d*\.\d+|\d+', response_text):
                                try:
                                    value = float(match.group())
                                    if abs(value - expected_result) / max(1, abs(expected_result)) < self._max_allowed_error:
                                        found = True
                                        break
                                except (ValueError, TypeError):
                                    pass
                except Exception as e:
                    result["warnings"].append(f"Error checking calculation: {str(e)}")
            
            if not found:
                result["warnings"].append(f"Could not verify {description} result {expected_result}")
                
                # Only fail verification if it's a critical calculation
                if calc.get("critical", False):
                    result["passed"] = False
                    result["errors"].append(f"Response is missing critical {description} result")
        
        return result
    
    def _verify_qualifiers(self, response: Dict[str, Any], original_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Verify that appropriate qualifiers are included for estimates or projections.
        
        Args:
            response: The formatted response to verify
            original_data: The original data used to generate the response
            
        Returns:
            Dictionary with qualifier verification results
        """
        result = {
            "passed": True,
            "errors": [],
            "warnings": []
        }
        
        # Get response text for checking
        response_text = ""
        if "summary" in response and isinstance(response["summary"], str):
            response_text += response["summary"] + " "
        
        if "confidence" in response:
            if isinstance(response["confidence"], str):
                response_text += response["confidence"] + " "
            elif isinstance(response["confidence"], dict):
                response_text += json.dumps(response["confidence"]) + " "
        
        # Check if data includes projections or estimates
        metadata = original_data.get("metadata", {})
        has_projections = metadata.get("has_projections", False)
        has_estimates = metadata.get("has_estimates", False)
        is_partial_data = metadata.get("partial_data", False)
        
        # Define qualifier keywords
        projection_qualifiers = ["projection", "forecast", "predicted", "estimated"]
        estimate_qualifiers = ["estimate", "estimated", "approximate", "about"]
        partial_qualifiers = ["partial", "incomplete", "limited"]
        
        # Check for projection qualifiers
        if has_projections and not any(qualifier in response_text.lower() for qualifier in projection_qualifiers):
            result["passed"] = False
            result["errors"].append("Response contains projections without appropriate qualifiers")
        
        # Check for estimate qualifiers
        if has_estimates and not any(qualifier in response_text.lower() for qualifier in estimate_qualifiers):
            result["passed"] = False
            result["errors"].append("Response contains estimates without appropriate qualifiers")
        
        # Check for partial data qualifiers
        if is_partial_data and not any(qualifier in response_text.lower() for qualifier in partial_qualifiers):
            result["warnings"].append("Response does not clearly indicate that data is partial or incomplete")
        
        return result
    
    def fix_response_issues(self, response: Dict[str, Any], verification_result: Dict[str, Any],
                          original_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Fix issues identified during verification.
        
        Args:
            response: The response to fix
            verification_result: Verification results with issues
            original_data: The original data used to generate the response
            
        Returns:
            Fixed response
        """
        fixed_response = response.copy()
        
        try:
            # Add missing source information
            if "source" in verification_result.get("checks", {}) and not verification_result["checks"]["source"]["passed"]:
                if "data_source" not in fixed_response and self._require_data_lineage:
                    tables = original_data.get("metadata", {}).get("tables", [])
                    time_period = original_data.get("metadata", {}).get("time_period")
                    
                    source_info = "Data Source: "
                    if tables:
                        source_info += ", ".join(tables)
                    else:
                        source_info += "Unknown"
                    
                    if time_period:
                        source_info += f" for the period: {', '.join(time_period)}"
                    
                    fixed_response["data_source"] = source_info
            
            # Add missing confidence information
            if "confidence" in verification_result.get("checks", {}) and not verification_result["checks"]["confidence"]["passed"]:
                if "confidence" not in fixed_response and self._confidence_required:
                    # Determine appropriate confidence level
                    metadata = original_data.get("metadata", {})
                    confidence_level = "High"
                    
                    if metadata.get("partial_data", False) or metadata.get("data_freshness_days", 0) > 30:
                        confidence_level = "Medium"
                    
                    if metadata.get("calculation_complexity", "simple") == "complex":
                        confidence_level = "Medium"
                    
                    fixed_response["confidence"] = {
                        "level": confidence_level,
                        "factors": ["Automatically added during verification"]
                    }
            
            # Add missing qualifiers
            if "qualifiers" in verification_result.get("checks", {}) and not verification_result["checks"]["qualifiers"]["passed"]:
                metadata = original_data.get("metadata", {})
                has_projections = metadata.get("has_projections", False)
                has_estimates = metadata.get("has_estimates", False)
                
                if "summary" in fixed_response and isinstance(fixed_response["summary"], str):
                    summary = fixed_response["summary"]
                    
                    # Add projection qualifier if needed
                    if has_projections and not any(qualifier in summary.lower() for qualifier in ["projection", "forecast", "predicted"]):
                        if not summary.endswith("."):
                            summary += "."
                        summary += " These figures include projections and should be treated as forecasts rather than actuals."
                    
                    # Add estimate qualifier if needed
                    if has_estimates and not any(qualifier in summary.lower() for qualifier in ["estimate", "estimated", "approximate"]):
                        if not summary.endswith("."):
                            summary += "."
                        summary += " These figures include estimates and should be treated as approximations."
                    
                    fixed_response["summary"] = summary
            
            # Add verification metadata
            fixed_response["_verification"] = {
                "verified": True,
                "fixed_issues": verification_result.get("errors", []),
                "timestamp": datetime.now().isoformat()
            }
            
            return fixed_response
            
        except Exception as e:
            self._logger.error(f"Error fixing response issues: {str(e)}")
            
            # Add error note
            if "summary" in fixed_response and isinstance(fixed_response["summary"], str):
                fixed_response["summary"] += " Note: Some verification issues could not be automatically fixed."
            
            fixed_response["_verification"] = {
                "verified": False,
                "errors": [f"Error fixing issues: {str(e)}"],
                "timestamp": datetime.now().isoformat()
            }
            
            return fixed_response