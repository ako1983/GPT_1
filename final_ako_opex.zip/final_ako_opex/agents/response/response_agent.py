"""
Response Agent Module

This module implements the Response Agent, responsible for generating final responses to
users based on query results and formatting information in a clear, accurate manner.
"""

import os
import json
import logging
import asyncio
from typing import Dict, List, Any, Optional, Tuple
import re

from ...core.interfaces.agent_interface import Agent, AgentType, ExecutionStatus, Message
from ...core.communication.event_bus import get_event_bus
from ...core.state.state_manager import get_state_manager
from .response_formatter import ResponseFormatter
from .results_analyzer import ResultsAnalyzer
from .verification_handler import VerificationHandler


class ResponseAgent(Agent):
    """
    Response Agent for generating final responses to users.
    
    The ResponseAgent:
    1. Formats query results in a user-friendly manner
    2. Analyzes results to extract insights and patterns
    3. Verifies response accuracy and completeness
    4. Provides appropriate context and qualifiers
    5. Logs detailed information for auditing and improvement
    """
    
    def __init__(self, agent_id: str, config: Dict[str, Any]):
        """
        Initialize a new Response agent.
        
        Args:
            agent_id: Unique identifier for this agent
            config: Configuration parameters for this agent
        """
        super().__init__(agent_id, AgentType.RESPONSE)
        self._logger = logging.getLogger(__name__)
        self._config = config
        self._initialized = False
        self._event_bus = get_event_bus()
        self._state_manager = get_state_manager()
        
        # Initialize components
        self._formatter = ResponseFormatter(config.get("formatter_config", {}))
        self._analyzer = ResultsAnalyzer(config.get("analyzer_config", {}))
        self._verifier = VerificationHandler(config.get("verifier_config", {}))
        
        # Settings
        self._default_template = config.get("default_template", "standard")
        self._verify_responses = config.get("verify_responses", True)
        self._auto_fix_issues = config.get("auto_fix_issues", True)
        self._log_responses = config.get("log_responses", True)
        self._log_dir = config.get("log_dir", "logs/responses")
        self._templates = config.get("templates", {})
    
    async def initialize(self, config: Dict[str, Any]) -> bool:
        """
        Initialize the agent with configuration parameters.
        
        Args:
            config: Configuration parameters
            
        Returns:
            True if initialization was successful, False otherwise
        """
        try:
            # Update configuration
            self._config.update(config)
            
            # Update settings from new config
            self._default_template = self._config.get("default_template", self._default_template)
            self._verify_responses = self._config.get("verify_responses", self._verify_responses)
            self._auto_fix_issues = self._config.get("auto_fix_issues", self._auto_fix_issues)
            self._log_responses = self._config.get("log_responses", self._log_responses)
            self._log_dir = self._config.get("log_dir", self._log_dir)
            
            # Ensure log directory exists
            if self._log_responses and not os.path.exists(self._log_dir):
                os.makedirs(self._log_dir, exist_ok=True)
            
            # Load templates from file if specified
            templates_file = self._config.get("templates_file")
            if templates_file and os.path.exists(templates_file):
                with open(templates_file, 'r') as f:
                    self._templates.update(json.load(f))
                    
                # Update formatter with templates
                self._formatter = ResponseFormatter({
                    **self._config.get("formatter_config", {}),
                    "templates": self._templates,
                    "default_template": self._default_template
                })
            
            # Register with the event bus
            self._event_bus.register_agent(AgentType.RESPONSE, self.process)
            
            self._initialized = True
            self._logger.info("Response agent initialized successfully")
            return True
            
        except Exception as e:
            self._logger.error(f"Error initializing Response agent: {str(e)}")
            return False
    
    async def process(self, message: Message) -> Message:
        """
        Process an incoming message and produce a response.
        
        Args:
            message: The incoming message to process
            
        Returns:
            A response message
        """
        self._logger.info(f"Processing message: {message.message_type}")
        
        # Extract message content
        content = message.content
        
        # Check the message type and dispatch to the appropriate handler
        if message.message_type == "generate_response":
            query = content.get("query")
            query_id = content.get("query_id")
            results = content.get("results", [])
            sql = content.get("sql")
            template = content.get("template")
            user_preferences = content.get("user_preferences")
            metadata = content.get("metadata", {})
            
            result = await self.generate_response(
                query=query,
                query_id=query_id,
                results=results,
                sql=sql,
                template=template,
                user_preferences=user_preferences,
                metadata=metadata
            )
            
            return Message(
                sender=AgentType.RESPONSE,
                receiver=message.sender,
                content=result,
                message_type="response_generated",
                trace_id=message.trace_id
            )
        
        elif message.message_type == "verify_response":
            response = content.get("response")
            original_data = content.get("original_data")
            
            if response and original_data:
                result = self.verify_response(response, original_data)
                return Message(
                    sender=AgentType.RESPONSE,
                    receiver=message.sender,
                    content=result,
                    message_type="response_verified",
                    trace_id=message.trace_id
                )
        
        # Default response for unsupported message types
        return Message(
            sender=AgentType.RESPONSE,
            receiver=message.sender,
            content={"error": "Unsupported message type"},
            message_type="error",
            trace_id=message.trace_id
        )
    
    async def generate_response(self, query: str, results: List[Dict[str, Any]],
                             query_id: Optional[str] = None, sql: Optional[str] = None,
                             template: Optional[str] = None,
                             user_preferences: Optional[Dict[str, Any]] = None,
                             metadata: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """
        Generate a response based on query results.
        
        Args:
            query: The original user query
            results: The query results
            query_id: Optional query ID for state tracking
            sql: Optional SQL query used to generate results
            template: Optional template to use for formatting
            user_preferences: Optional user preferences
            metadata: Optional metadata about the results
            
        Returns:
            Dictionary with the generated response
        """
        self._logger.info(f"Generating response for query: {query}")
        
        try:
            # Update status
            self.status = ExecutionStatus.IN_PROGRESS
            
            # Generate a query ID if not provided
            if not query_id:
                query_id = f"query_{hash(query) & 0xffffffff}"
            
            # Get query context from state if available
            query_context = {}
            query_state = self._state_manager.get_query_state(query_id)
            if query_state:
                query_context = query_state.get_context("query_context") or {}
            
            # If metadata is not provided, create a minimal metadata object
            if not metadata:
                metadata = {
                    "tables": [],
                    "query_intent": query_context.get("intent", "retrieval"),
                    "time_period": []
                }
            
            # Ensure SQL is included in the data
            data = {
                "query": query,
                "results": results,
                "sql": sql,
                "metadata": metadata
            }
            
            # Step 1: Analyze results to extract insights
            analysis = self._analyzer.analyze_results(results, query_context, metadata)
            data["analysis"] = analysis
            
            # Step 2: Format the response using the appropriate template
            formatted_response = self._formatter.format_response(
                data=data,
                template_name=template,
                user_preferences=user_preferences
            )
            
            # Step 3: Verify the response for accuracy if enabled
            if self._verify_responses:
                verification_result = self._verifier.verify_response(formatted_response, data)
                
                # Step 4: Fix issues if auto-fix is enabled
                if not verification_result["verified"] and self._auto_fix_issues:
                    formatted_response = self._verifier.fix_response_issues(
                        formatted_response, verification_result, data)
                
                formatted_response["_verification"] = verification_result
            
            # Step 5: Log the response if enabled
            if self._log_responses:
                self._log_response(query_id, query, formatted_response, data)
            
            # Step 6: Update query state with response information
            self._update_query_state(query_id, formatted_response)
            
            # Update status
            self.status = ExecutionStatus.COMPLETED
            
            # Return the formatted response
            return {
                "query_id": query_id,
                "original_query": query,
                "response": formatted_response,
                "success": True
            }
            
        except Exception as e:
            self._logger.error(f"Error generating response: {str(e)}")
            self.status = ExecutionStatus.FAILED
            
            # Create a fallback response
            fallback_response = self._create_fallback_response(query, results)
            
            return {
                "query_id": query_id,
                "original_query": query,
                "response": fallback_response,
                "error": str(e),
                "success": False
            }
    
    def verify_response(self, response: Dict[str, Any], original_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Verify a response for accuracy and completeness.
        
        Args:
            response: The response to verify
            original_data: The original data used to generate the response
            
        Returns:
            Dictionary with verification results
        """
        try:
            # Verify the response
            verification_result = self._verifier.verify_response(response, original_data)
            
            # Return the verification result
            return {
                "verification_result": verification_result,
                "response": response,
                "success": verification_result["verified"]
            }
            
        except Exception as e:
            self._logger.error(f"Error verifying response: {str(e)}")
            return {
                "error": str(e),
                "success": False
            }
    
    def _create_fallback_response(self, query: str, results: List[Dict[str, Any]]) -> Dict[str, Any]:
        """
        Create a fallback response when normal response generation fails.
        
        Args:
            query: The original user query
            results: The query results
            
        Returns:
            A minimal response with the results
        """
        fallback = {
            "summary": f"Results for query: {query}",
            "results": results[:10],  # Include only first 10 results
            "error_note": "An error occurred during response generation. Showing raw results.",
            "_fallback": True
        }
        
        return fallback
    
    def _log_response(self, query_id: str, query: str, response: Dict[str, Any], data: Dict[str, Any]) -> None:
        """
        Log the response for auditing and improvement.
        
        Args:
            query_id: The query ID
            query: The original query
            response: The formatted response
            data: The data used to generate the response
        """
        try:
            # Create a log entry
            log_entry = {
                "query_id": query_id,
                "timestamp": asyncio.get_event_loop().time(),
                "query": query,
                "response": response,
                "sql": data.get("sql"),
                "metadata": data.get("metadata", {})
            }
            
            # Write to log file
            log_file = os.path.join(self._log_dir, f"{query_id}.json")
            with open(log_file, 'w') as f:
                json.dump(log_entry, f, indent=2)
                
            self._logger.debug(f"Response logged to {log_file}")
            
        except Exception as e:
            self._logger.error(f"Error logging response: {str(e)}")
    
    def _update_query_state(self, query_id: str, response: Dict[str, Any]) -> None:
        """
        Update the query state with response information.
        
        Args:
            query_id: The query ID
            response: The formatted response
        """
        # Get the query state
        query_state = self._state_manager.get_query_state(query_id)
        
        # If no existing state, create one
        if not query_state:
            self._state_manager.create_query_state(query_id, {
                "timestamp": asyncio.get_event_loop().time()
            })
            query_state = self._state_manager.get_query_state(query_id)
        
        # Update the state with the response
        self._state_manager.update_query_state(query_id, {
            "response": response,
            "response_timestamp": asyncio.get_event_loop().time()
        })
    
    def get_capabilities(self) -> List[str]:
        """
        Return a list of capabilities this agent provides.
        
        Returns:
            List of capability strings
        """
        return [
            "response_generation",
            "response_formatting",
            "results_analysis",
            "response_verification",
            "response_logging"
        ]
    
    def get_status(self) -> Dict[str, Any]:
        """
        Get the current status of this agent.
        
        Returns:
            A dictionary with status information
        """
        return {
            "agent_id": self.agent_id,
            "agent_type": self.agent_type,
            "status": self.status,
            "initialized": self._initialized,
            "default_template": self._default_template,
            "verify_responses": self._verify_responses,
            "auto_fix_issues": self._auto_fix_issues,
            "log_responses": self._log_responses
        }
    
    async def shutdown(self) -> bool:
        """
        Perform cleanup when shutting down the agent.
        
        Returns:
            True if shutdown was successful, False otherwise
        """
        try:
            # Unregister from the event bus
            self._event_bus.unregister_agent(AgentType.RESPONSE)
            
            return True
            
        except Exception as e:
            self._logger.error(f"Error shutting down Response agent: {str(e)}")
            return False