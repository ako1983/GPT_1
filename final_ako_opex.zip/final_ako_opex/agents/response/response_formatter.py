"""
Response Formatter Module

This module formats responses according to templates and user preferences,
ensuring consistent and user-friendly presentation of results.
"""

import logging
import json
import re
from typing import Dict, List, Any, Optional, Union
from datetime import datetime
import pandas as pd
import numpy as np


class ResponseFormatter:
    """
    Formats responses according to templates and user preferences.
    
    The ResponseFormatter:
    1. Applies templates to structure responses consistently
    2. Formats financial data with appropriate precision and notation
    3. Generates charts and visualizations when appropriate
    4. Provides source attribution and confidence indicators
    5. Adapts output format based on user preferences
    """
    
    def __init__(self, config: Dict[str, Any] = None):
        """
        Initialize a new response formatter.
        
        Args:
            config: Configuration parameters
        """
        self._logger = logging.getLogger(__name__)
        self._config = config or {}
        
        # Load configuration
        self._templates = self._config.get("templates", {})
        self._default_template = self._config.get("default_template", "standard")
        self._decimal_places = self._config.get("decimal_places", 2)
        self._use_thousands_separator = self._config.get("use_thousands_separator", True)
        self._currency_symbol = self._config.get("currency_symbol", "$")
        self._date_format = self._config.get("date_format", "%Y-%m-%d")
        self._table_format = self._config.get("table_format", "markdown")
        
        # Load response templates if path is provided
        templates_path = self._config.get("templates_path")
        if templates_path:
            try:
                with open(templates_path, 'r') as f:
                    self._templates.update(json.load(f))
            except Exception as e:
                self._logger.error(f"Error loading templates from {templates_path}: {str(e)}")
    
    def format_response(self, data: Dict[str, Any], template_name: Optional[str] = None,
                       user_preferences: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """
        Format a response using the specified template.
        
        Args:
            data: Response data to format
            template_name: Optional template name to use
            user_preferences: Optional user preferences
            
        Returns:
            Formatted response data
        """
        try:
            # Get user preferences
            preferences = user_preferences or {}
            
            # Determine which template to use
            template_name = template_name or preferences.get("template", self._default_template)
            template = self._templates.get(template_name)
            
            if not template:
                self._logger.warning(f"Template '{template_name}' not found, using default")
                template = self._templates.get(self._default_template, {})
            
            # Apply the template to the data
            if not template:
                # No template available, return the data as is
                return data
            
            # Extract results data
            results = data.get("results", [])
            query = data.get("query", "")
            sql = data.get("sql", "")
            metadata = data.get("metadata", {})
            
            # Format the results based on result type
            formatted_results = self._format_results(results, template, preferences)
            
            # Apply template structure
            response = {}
            
            if "structure" in template:
                for key, value in template["structure"].items():
                    if key == "summary":
                        response[key] = self._apply_template_section(value, {
                            "query": query,
                            "results": formatted_results,
                            "metadata": metadata
                        })
                    elif key == "data_source":
                        response[key] = self._apply_template_section(value, {
                            "tables": metadata.get("tables", []),
                            "time_period": metadata.get("time_period", ""),
                            "sql": sql
                        })
                    elif key == "results":
                        response[key] = formatted_results
                    elif key == "confidence":
                        response[key] = self._calculate_confidence(data, metadata)
                    elif key == "charts":
                        response[key] = self._generate_charts(results, preferences)
                    else:
                        # Pass through other template sections
                        response[key] = value
            else:
                # Simple template, just format the results
                response = {
                    "formatted_results": formatted_results
                }
            
            # Add metadata
            response["metadata"] = {
                "template_used": template_name,
                "timestamp": datetime.now().isoformat(),
                "original_query": query
            }
            
            return response
            
        except Exception as e:
            self._logger.error(f"Error formatting response: {str(e)}")
            return {
                "error": f"Error formatting response: {str(e)}",
                "original_data": data
            }
    
    def _format_results(self, results: List[Dict[str, Any]], template: Dict[str, Any],
                      preferences: Dict[str, Any]) -> Any:
        """
        Format results based on their type and the template.
        
        Args:
            results: Results data to format
            template: Template to apply
            preferences: User preferences
            
        Returns:
            Formatted results
        """
        if not results:
            return []
        
        # Determine result type
        result_type = template.get("result_type", "table")
        
        if result_type == "table":
            return self._format_table_results(results, preferences)
        elif result_type == "single_value":
            return self._format_single_value(results, preferences)
        elif result_type == "time_series":
            return self._format_time_series(results, preferences)
        elif result_type == "comparison":
            return self._format_comparison(results, preferences)
        else:
            # Default to table format
            return self._format_table_results(results, preferences)
    
    def _format_table_results(self, results: List[Dict[str, Any]], 
                           preferences: Dict[str, Any]) -> str:
        """
        Format results as a table.
        
        Args:
            results: Results data to format
            preferences: User preferences
            
        Returns:
            Formatted table
        """
        if not results:
            return "No results found."
        
        # Convert to DataFrame for easier manipulation
        df = pd.DataFrame(results)
        
        # Format numeric columns
        for col in df.select_dtypes(include=[np.number]).columns:
            if "amt" in col.lower() or "amount" in col.lower() or "cost" in col.lower() or "price" in col.lower():
                # Format as currency
                df[col] = df[col].apply(self._format_currency)
            else:
                # Format as number
                df[col] = df[col].apply(self._format_number)
        
        # Format date columns
        for col in df.select_dtypes(include=['datetime64']).columns:
            df[col] = df[col].dt.strftime(self._date_format)
        
        # Format the table based on preferences
        table_format = preferences.get("table_format", self._table_format)
        
        if table_format == "markdown":
            return df.to_markdown(index=False)
        elif table_format == "html":
            return df.to_html(index=False)
        elif table_format == "csv":
            return df.to_csv(index=False)
        elif table_format == "json":
            return df.to_json(orient="records")
        else:
            # Default to string representation
            return df.to_string(index=False)
    
    def _format_single_value(self, results: List[Dict[str, Any]], 
                          preferences: Dict[str, Any]) -> str:
        """
        Format results as a single value.
        
        Args:
            results: Results data to format
            preferences: User preferences
            
        Returns:
            Formatted single value
        """
        if not results or not results[0]:
            return "No value found."
        
        # Get the first value from the first result
        value = list(results[0].values())[0]
        
        # Format based on value type
        if isinstance(value, (int, float)):
            if any(kw in list(results[0].keys())[0].lower() for kw in ["amt", "amount", "cost", "price"]):
                return self._format_currency(value)
            else:
                return self._format_number(value)
        elif isinstance(value, datetime):
            return value.strftime(self._date_format)
        else:
            return str(value)
    
    def _format_time_series(self, results: List[Dict[str, Any]], 
                         preferences: Dict[str, Any]) -> str:
        """
        Format results as a time series.
        
        Args:
            results: Results data to format
            preferences: User preferences
            
        Returns:
            Formatted time series
        """
        if not results:
            return "No time series data found."
        
        # Convert to DataFrame
        df = pd.DataFrame(results)
        
        # Identify time column
        time_cols = [col for col in df.columns 
                    if any(kw in col.lower() for kw in ["date", "time", "period", "month", "quarter", "year"])]
        
        if not time_cols:
            # No time column found, format as regular table
            return self._format_table_results(results, preferences)
        
        # Use the first time column as index
        time_col = time_cols[0]
        value_cols = [col for col in df.columns if col != time_col]
        
        # Format the time series
        formatted_series = []
        for _, row in df.iterrows():
            time_value = row[time_col]
            if isinstance(time_value, datetime):
                time_value = time_value.strftime(self._date_format)
            
            entry = f"{time_value}: "
            
            # Format each value in the row
            values = []
            for col in value_cols:
                value = row[col]
                if isinstance(value, (int, float)):
                    if any(kw in col.lower() for kw in ["amt", "amount", "cost", "price"]):
                        formatted_value = self._format_currency(value)
                    else:
                        formatted_value = self._format_number(value)
                else:
                    formatted_value = str(value)
                
                values.append(f"{col}: {formatted_value}")
            
            entry += ", ".join(values)
            formatted_series.append(entry)
        
        return "\n".join(formatted_series)
    
    def _format_comparison(self, results: List[Dict[str, Any]], 
                        preferences: Dict[str, Any]) -> str:
        """
        Format results as a comparison.
        
        Args:
            results: Results data to format
            preferences: User preferences
            
        Returns:
            Formatted comparison
        """
        if not results or len(results) < 2:
            return "Insufficient data for comparison."
        
        # Convert to DataFrame
        df = pd.DataFrame(results)
        
        # Identify category column
        category_cols = [col for col in df.columns 
                        if col.lower() in ["category", "name", "type", "group", "segment"]]
        
        if not category_cols:
            # No category column found, use the first column
            category_col = df.columns[0]
        else:
            category_col = category_cols[0]
        
        # Identify value columns
        value_cols = [col for col in df.columns 
                     if col != category_col and df[col].dtype in [np.int64, np.float64]]
        
        if not value_cols:
            # No value columns found, format as regular table
            return self._format_table_results(results, preferences)
        
        # Format the comparison
        formatted_comparison = []
        for _, row in df.iterrows():
            category = row[category_col]
            
            # Format each value in the row
            values = []
            for col in value_cols:
                value = row[col]
                if isinstance(value, (int, float)):
                    if any(kw in col.lower() for kw in ["amt", "amount", "cost", "price"]):
                        formatted_value = self._format_currency(value)
                    else:
                        formatted_value = self._format_number(value)
                else:
                    formatted_value = str(value)
                
                values.append(f"{col}: {formatted_value}")
            
            entry = f"{category}: {', '.join(values)}"
            formatted_comparison.append(entry)
        
        return "\n".join(formatted_comparison)
    
    def _format_currency(self, value: Union[int, float]) -> str:
        """
        Format a value as currency.
        
        Args:
            value: The value to format
            
        Returns:
            Formatted currency string
        """
        try:
            if self._use_thousands_separator:
                return f"{self._currency_symbol}{value:,.{self._decimal_places}f}"
            else:
                return f"{self._currency_symbol}{value:.{self._decimal_places}f}"
        except Exception:
            return str(value)
    
    def _format_number(self, value: Union[int, float]) -> str:
        """
        Format a value as a number.
        
        Args:
            value: The value to format
            
        Returns:
            Formatted number string
        """
        try:
            if isinstance(value, int):
                if self._use_thousands_separator:
                    return f"{value:,}"
                else:
                    return str(value)
            else:
                if self._use_thousands_separator:
                    return f"{value:,.{self._decimal_places}f}"
                else:
                    return f"{value:.{self._decimal_places}f}"
        except Exception:
            return str(value)
    
    def _apply_template_section(self, template_section: str, data: Dict[str, Any]) -> str:
        """
        Apply a template section with data.
        
        Args:
            template_section: Template section to apply
            data: Data to use in the template
            
        Returns:
            Formatted template section
        """
        result = template_section
        
        # Replace placeholders in the template
        for key, value in data.items():
            placeholder = f"{{{key}}}"
            if placeholder in result:
                if isinstance(value, list) and value:
                    # Join list items with commas
                    result = result.replace(placeholder, ", ".join(str(item) for item in value))
                else:
                    # Replace with the value
                    result = result.replace(placeholder, str(value))
        
        # Remove any remaining placeholders
        result = re.sub(r'\{[^}]*\}', '', result)
        
        return result
    
    def _calculate_confidence(self, data: Dict[str, Any], metadata: Dict[str, Any]) -> Dict[str, Any]:
        """
        Calculate confidence level for the response.
        
        Args:
            data: Response data
            metadata: Response metadata
            
        Returns:
            Confidence information
        """
        # Start with a high confidence level
        confidence_level = "High"
        confidence_score = 0.9
        factors = []
        
        # Check for direct data access vs calculated values
        if metadata.get("is_calculated", False):
            confidence_score -= 0.1
            factors.append("Response contains calculated values")
        
        # Check for completeness of time period
        if metadata.get("partial_time_period", False):
            confidence_score -= 0.2
            factors.append("Incomplete data for the requested time period")
        
        # Check for data freshness
        if metadata.get("data_freshness_days", 0) > 7:
            confidence_score -= 0.1
            factors.append(f"Data is {metadata.get('data_freshness_days')} days old")
        
        # Check for data completeness
        if metadata.get("data_completeness", 100) < 95:
            confidence_score -= 0.2
            factors.append(f"Data is {metadata.get('data_completeness')}% complete")
        
        # Determine confidence level
        if confidence_score < 0.7:
            confidence_level = "Low"
        elif confidence_score < 0.9:
            confidence_level = "Medium"
        
        return {
            "level": confidence_level,
            "score": round(confidence_score, 2),
            "factors": factors
        }
    
    def _generate_charts(self, results: List[Dict[str, Any]], 
                       preferences: Dict[str, Any]) -> List[Dict[str, Any]]:
        """
        Generate chart specifications for the results.
        
        Args:
            results: Results data
            preferences: User preferences
            
        Returns:
            List of chart specifications
        """
        if not results:
            return []
        
        # For now, return a placeholder chart specification
        # In a real implementation, this would generate chart configurations
        # based on the data type and patterns
        return [
            {
                "type": "placeholder",
                "message": "Chart generation would be implemented here with visualization libraries"
            }
        ]