"""
Response Agent Package

This package implements the Response Agent, responsible for generating final responses to
users based on query results and formatting information in a clear, accurate manner.

Components:
- ResponseAgent: Main agent implementation that processes and formats responses
- ResponseFormatter: Formats responses according to templates and user preferences
- ResultsAnalyzer: Analyzes query results for insights and notable patterns
- VerificationHandler: Performs final verification of response accuracy
"""

from .response_agent import ResponseAgent
from .response_formatter import ResponseFormatter
from .results_analyzer import ResultsAnalyzer
from .verification_handler import VerificationHandler