# Response Agent

The Response Agent is responsible for generating final responses to users based on query results, formatting information in a clear, accurate manner, and ensuring that all financial data is presented with appropriate context and verification.

## Overview

The Response Agent combines three primary components:

1. **ResponseFormatter**: Formats responses according to templates and user preferences
2. **ResultsAnalyzer**: Analyzes query results to identify insights and patterns
3. **VerificationHandler**: Performs final verification of response accuracy

The agent ensures that all responses meet the high standards required for financial information, with proper source attribution, confidence indicators, and appropriate qualifiers.

## Key Features

- Template-based response formatting for consistent presentation
- Automated analysis of results to extract meaningful insights
- Strict verification of response accuracy and completeness
- Financial data formatting with appropriate precision and notation
- Confidence scoring based on data quality and calculation complexity
- Comprehensive logging for auditing and improvement

## Components

### Response Formatter

The ResponseFormatter component formats responses according to templates and user preferences:

- Applies templates to structure responses consistently
- Formats financial data with appropriate precision and notation
- Generates charts and visualizations when appropriate
- Provides source attribution and confidence indicators
- Adapts output format based on user preferences

### Results Analyzer

The ResultsAnalyzer component analyzes query results to identify insights and patterns:

- Identifies trends and patterns in the result data
- Calculates statistical measures and key metrics
- Detects anomalies and outliers in the data
- Prioritizes information for inclusion in the response
- Generates insights based on domain-specific rules

### Verification Handler

The VerificationHandler component performs final verification of response accuracy:

- Validates that responses include proper source citations
- Ensures response data matches the original query results
- Verifies confidence levels are appropriate
- Checks for financial calculation accuracy
- Ensures appropriate qualifiers for estimates or projections

## Usage

The Response Agent can be used to generate responses from query results:

```python
# Example: Generate a response
result = await response_agent.generate_response(
    query="What was the total budget for the CTO department in Q1 2023?",
    results=query_results,
    sql="SELECT SUM(budget_amt) FROM pypl_opex_bau WHERE bu_level_3_desc = 'CTO' AND fiscal_quarter = 'Q1_2023'",
    metadata={
        "tables": ["pypl_opex_bau"],
        "time_period": ["Q1_2023"],
        "query_intent": "aggregation"
    }
)
```

## Response Templates

The Response Agent supports multiple response templates for different use cases:

- **Standard**: General-purpose template for most queries
- **Financial**: Detailed template for financial analysis
- **Executive**: Concise template with highlights for executive summaries
- **Simple**: Minimal template for single value responses

Templates define the structure and formatting of the response, ensuring consistent presentation across different types of queries.

## Configuration

The Response Agent can be configured through a JSON configuration file:

```json
{
  "agent_id": "response_agent_1",
  "default_template": "standard",
  "verify_responses": true,
  "auto_fix_issues": true,
  "log_responses": true,
  "log_dir": "logs/responses",
  
  "formatter_config": {
    "decimal_places": 2,
    "use_thousands_separator": true,
    "currency_symbol": "$",
    "date_format": "%Y-%m-%d",
    "table_format": "markdown"
  },
  
  "analyzer_config": {
    "significance_threshold": 0.1,
    "max_insights": 5,
    "detect_outliers": true,
    "outlier_threshold": 2.0
  },
  
  "verifier_config": {
    "verification_checks": ["source", "data", "confidence", "calculations", "qualifiers"],
    "min_sources_required": 1,
    "require_data_lineage": true,
    "confidence_required": true
  }
}
```

### Configuration Options

#### Top Level Options

| Option | Description | Default |
| --- | --- | --- |
| `agent_id` | Unique identifier for this agent | `"response_agent_1"` |
| `default_template` | Default template to use for formatting | `"standard"` |
| `verify_responses` | Whether to verify responses for accuracy | `true` |
| `auto_fix_issues` | Whether to automatically fix verification issues | `true` |
| `log_responses` | Whether to log responses for auditing | `true` |
| `log_dir` | Directory for response logs | `"logs/responses"` |

#### Formatter Options

| Option | Description | Default |
| --- | --- | --- |
| `decimal_places` | Number of decimal places for financial values | `2` |
| `use_thousands_separator` | Whether to use thousands separators | `true` |
| `currency_symbol` | Symbol to use for currency values | `"$"` |
| `date_format` | Format string for dates | `"%Y-%m-%d"` |
| `table_format` | Format for tables (markdown, html, csv, json) | `"markdown"` |

#### Analyzer Options

| Option | Description | Default |
| --- | --- | --- |
| `significance_threshold` | Threshold for significant changes | `0.1` |
| `time_series_periods` | Minimum periods for time series analysis | `3` |
| `max_insights` | Maximum number of insights to generate | `5` |
| `detect_outliers` | Whether to detect outliers in the data | `true` |
| `outlier_threshold` | Z-score threshold for outlier detection | `2.0` |

#### Verifier Options

| Option | Description | Default |
| --- | --- | --- |
| `verification_checks` | Types of verification checks to perform | `["source", "data", "confidence", "calculations", "qualifiers"]` |
| `min_sources_required` | Minimum number of sources required | `1` |
| `require_data_lineage` | Whether to require data lineage information | `true` |
| `confidence_required` | Whether to require confidence indicators | `true` |
| `verify_calculations` | Whether to verify calculation accuracy | `true` |
| `max_allowed_error` | Maximum allowed error in calculations | `0.01` |

## Event-Based Communication

The Response Agent interacts with other components through these event types:

### Subscriptions (Incoming Events)

- `generate_response`: Request to generate a response from query results
- `verify_response`: Request to verify a response for accuracy

### Publications (Outgoing Events)

- `response_generated`: Response with generated response
- `response_verified`: Response with verification results

## Integration with Other Agents

The Response Agent is designed to work closely with these other agents:

- **SQL Agent**: Provides query results for response generation
- **SQL Helper Agent**: Provides optimized SQL queries
- **RAG Agent**: Provides context information for response generation

## Response Quality Standards

The Response Agent enforces strict quality standards for financial responses:

1. **Source Attribution**: All responses must include clear source information, including the tables used, time period, and any filters applied.

2. **Data Lineage**: Responses must provide a clear data lineage showing how the results were derived from the source data.

3. **Confidence Indicators**: Responses must include appropriate confidence indicators based on data quality, freshness, and calculation complexity.

4. **Calculation Verification**: All calculations must be verified for accuracy, with any significant deviations flagged.

5. **Appropriate Qualifiers**: Responses must include appropriate qualifiers for estimates, projections, or incomplete data.

These standards ensure that responses meet the high bar required for financial information, providing users with accurate, trustworthy, and contextually appropriate answers to their queries.

## Examples

### Example 1: Standard Response

```json
{
  "summary": "Here are the results for your query: What was the total budget for the CTO department in Q1 2023?",
  "data_source": "Data source: pypl_opex_bau for the period: Q1_2023",
  "results": "The total budget for the CTO department in Q1 2023 was $370,000.",
  "confidence": {
    "level": "High",
    "factors": ["Data is complete for the requested time period", "Simple aggregation calculation"]
  }
}
```

### Example 2: Financial Response with Insights

```json
{
  "summary": "Financial analysis for: How does the Q1 2023 CTO budget compare to actual spend?",
  "data_source": "Source: pypl_opex_bau | Period: Q1_2023 | SQL: SELECT SUM(budget_amt), SUM(actual_amt) FROM pypl_opex_bau WHERE bu_level_3_desc = 'CTO' AND fiscal_quarter = 'Q1_2023'",
  "results": "CTO Budget: $370,000\nCTO Actual Spend: $365,000\nVariance: $5,000 (1.4% under budget)",
  "insights": [
    "CTO department was 1.4% under budget for Q1 2023",
    "January had the largest variance (2.3% under budget)",
    "IT services subcategory had the largest absolute variance ($3,200 under budget)"
  ],
  "confidence": {
    "level": "High",
    "score": 0.95,
    "factors": ["Complete data for the requested time period", "Direct data lookup with minimal calculation"]
  },
  "methodology": "The above analysis was conducted using standard financial calculations. All amounts are in USD unless otherwise specified."
}
```

## Error Handling

The Response Agent implements robust error handling to ensure that responses are always generated, even in the face of errors:

1. If response generation fails, a fallback response is created with the raw results
2. If verification fails, issues are logged and fixed if auto-fix is enabled
3. If a template is not found, the default template is used
4. If analysis fails, the response is generated without insights

This ensures that users always receive a response, even if it may not include all the desired features in case of errors.

## Logging and Auditing

The Response Agent logs all generated responses to the specified log directory, including:

- The original query
- The query results
- The generated response
- Verification results
- Metadata about the response

These logs can be used for auditing, debugging, and improving the response generation process over time.