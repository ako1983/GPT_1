# Query Enhancer Agent

## Overview

The Query Enhancer Agent is responsible for analyzing user queries, identifying ambiguities, requesting clarification when needed, and reformulating queries to improve the accuracy of SQL generation.

This agent acts as a bridge between raw user queries and the SQL generation process, ensuring that the SQL Agent receives clear, structured, and unambiguous input.

## Components

The Query Enhancer Agent consists of the following key components:

### 1. QueryEnhancerAgent

The main agent implementation that orchestrates the query enhancement process. It handles messages from other agents, manages clarification dialogs, and coordinates the analysis and reformulation components.

### 2. QueryAnalyzer

Analyzes user queries to identify:
- Business entities and terms
- Time periods and date references
- Aggregation operations and metrics
- Potential ambiguities requiring clarification
- The core intent of the query

### 3. QueryReformulator

Reformulates user queries to improve clarity and SQL generation accuracy by:
- Standardizing terms and language
- Expanding abbreviated terms to their full form
- Incorporating clarifications provided by users
- Restructuring queries for optimal SQL generation
- Formatting the query in a way that helps the SQL generation process

## Key Features

- **Query Analysis**: Identifies entities, intents, and ambiguities in user queries
- **Ambiguity Detection**: Detects missing or unclear information in queries
- **Clarification Handling**: Manages a clarification dialog with users when needed
- **Query Reformulation**: Restructures and reformats queries for improved clarity
- **SQL-Friendly Formatting**: Generates query representations optimized for SQL generation
- **Context Generation**: Provides structured context for downstream agents

## Usage

### Initialization

```python
from final_ako_opex.agents.query_enhancer import QueryEnhancerAgent

# Initialize with configuration
query_enhancer = QueryEnhancerAgent(agent_id="query_enhancer_1", config={
    "max_clarification_rounds": 3,
    "clarification_threshold": 0.7,
    "auto_enhance": True
})

# Initialize the agent
await query_enhancer.initialize({})
```

### Enhancing a Query

```python
# Direct method call
result = await query_enhancer.enhance_query(
    query="What was the total OPEX budget for CTO in Q1?",
    query_id="query-123"
)

# Check if clarification is needed
if result.get("status") == "clarification_requested":
    # Handle clarification request
    print("Clarification needed!")
    print(result["questions"])
else:
    # Use the enhanced query
    enhanced_query = result["enhanced_query"]
    sql_friendly_query = result["sql_friendly_query"]
    print(f"Enhanced query: {enhanced_query}")
```

### Providing Clarifications

```python
# Provide clarifications for a query
clarification_result = await query_enhancer.process_clarification(
    query_id="query-123",
    clarifications={
        "time_period": "Q1 2023",
        "business_unit": "CTO department"
    }
)

# Use the enhanced query with clarifications
enhanced_query = clarification_result["enhanced_query"]
print(f"Enhanced query with clarifications: {enhanced_query}")
```

### Analyzing a Query

```python
# Analyze a query without enhancement
analysis = query_enhancer.analyze_query(
    query="What was the total OPEX budget for CTO in Q1?"
)

# Examine the analysis results
entities = analysis["analysis"]["entities"]
ambiguities = analysis["analysis"]["ambiguities"]
print(f"Entities detected: {entities}")
print(f"Ambiguities: {ambiguities}")
```

## Configuration

The Query Enhancer Agent supports the following configuration options:

### Basic Configuration

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `agent_id` | string | - | Unique identifier for the agent |
| `max_clarification_rounds` | integer | `3` | Maximum number of clarification rounds |
| `clarification_threshold` | float | `0.7` | Threshold for requesting clarification |
| `auto_enhance` | boolean | `true` | Whether to automatically enhance queries |

### Analyzer Configuration

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `analyzer_config.entity_patterns` | object | - | Custom regex patterns for entity recognition |
| `analyzer_config.ambiguity_rules` | array | - | Custom rules for ambiguity detection |

### Reformulator Configuration

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `reformulator_config.term_mappings` | object | - | Custom term standardization mappings |
| `reformulator_config.templates` | object | - | Custom templates for structured queries |

## Integration with Other Agents

The Query Enhancer Agent integrates with:

- **User Interface**: Receives raw queries and requests clarifications
- **RAG Agent**: Provides enhanced queries for context retrieval
- **SQL Agent**: Delivers SQL-friendly queries for SQL generation

## Example Workflow

1. User asks: "What was the CTO department's Q1 budget?"
2. Query Enhancer analyzes the query and detects a missing year in the time period
3. Query Enhancer requests clarification: "Which year's Q1 are you interested in?"
4. User responds: "2023"
5. Query Enhancer incorporates the clarification and reformulates the query
6. Enhanced query "What was the CTO department's Q1 2023 budget?" is sent to the SQL Agent
7. SQL Agent generates accurate SQL based on the enhanced query

## Handling Ambiguities

The Query Enhancer Agent identifies several types of ambiguities:

1. **Missing Time Period**: The query doesn't specify a time period
2. **Ambiguous Metric**: The query implies a metric but doesn't specify which one
3. **Missing Business Unit**: The query implies a business unit scope but doesn't specify which one
4. **Missing Comparison Basis**: The query has a comparison without a clear basis
5. **Complex Query**: The query is too complex or contains multiple questions

For each ambiguity, the agent generates appropriate clarification questions to resolve the issue.

## Reformulation Strategies

The Query Enhancer Agent uses several strategies to reformulate queries:

1. **Term Standardization**: Replaces abbreviated or variant terms with standard forms
2. **Clarification Incorporation**: Seamlessly integrates user-provided clarifications
3. **Structural Reformulation**: Restructures queries for improved clarity
4. **SQL-Friendly Formatting**: Reformats queries specifically to assist SQL generation

## Best Practices

1. **Clarification Management**: Handle clarification requests promptly to maintain conversation flow
2. **Customizing Entity Recognition**: Add domain-specific entity patterns for better recognition
3. **Fine-tuning Clarification Thresholds**: Adjust thresholds based on user expertise level
4. **Tracking Query Transformations**: Monitor transformations to understand enhancement patterns
5. **Utilizing Structured Queries**: Use structured query representations for complex operations