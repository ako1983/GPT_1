"""
Query Analyzer Module

This module implements the query analysis functionality for the Query Enhancer Agent,
responsible for analyzing queries to identify entities, intents, and ambiguities.
"""

import logging
import re
from typing import Dict, List, Any, Optional, Set, Tuple
import json

class QueryAnalyzer:
    """
    Analyzes user queries to identify key components and potential ambiguities.
    
    The QueryAnalyzer:
    1. Identifies business entities and terms in queries
    2. Detects time periods and date references
    3. Recognizes aggregation operations and metrics
    4. Identifies potential ambiguities requiring clarification
    5. Extracts the core intent of the query
    """
    
    def __init__(self, config: Dict[str, Any] = None):
        """
        Initialize a new query analyzer.
        
        Args:
            config: Configuration parameters
        """
        self._logger = logging.getLogger(__name__)
        self._config = config or {}
        
        # Initialize regex patterns for entity recognition
        self._entity_patterns = {
            "time_period": [
                r'\b(Q[1-4]|quarter\s*[1-4])\s*(?:of\s*)?\s*([0-9]{4})\b',
                r'\b([0-9]{4})\s*(?:Q|quarter\s*)?([1-4])\b',
                r'\b(Jan(?:uary)?|Feb(?:ruary)?|Mar(?:ch)?|Apr(?:il)?|May|Jun(?:e)?|Jul(?:y)?|Aug(?:ust)?|Sep(?:tember)?|Oct(?:ober)?|Nov(?:ember)?|Dec(?:ember)?)\s*([0-9]{4})\b',
                r'\bFY\s*([0-9]{4})\b',
                r'\b(last|previous|current|next)\s+(quarter|month|year)\b',
                r'\bYTD\b',
                r'\b([0-9]{4})-([0-9]{2})-([0-9]{2})\b'  # YYYY-MM-DD
            ],
            "metrics": [
                r'\b(budget|actual|forecast|spend|expense|cost|revenue|headcount|hc)\b',
                r'\b(opex|capex)\b',
                r'\b(variance|difference|delta|gap)\b',
                r'\b(total|sum|average|avg|mean|median|min|max)\b',
                r'\b(growth|increase|decrease|change|trend)\b',
                r'\bMoM\b',  # Month over Month
                r'\bYoY\b',  # Year over Year
                r'\bQoQ\b'   # Quarter over Quarter
            ],
            "business_units": [
                r'\b(department|dept|team|group|division|bu|business\s*unit|org|organization)\b',
                r'\b(cost\s*center)\b',
                r'\b(region|country|market|geo|location)\b'
            ],
            "comparison": [
                r'\b(compare|comparison|versus|vs|against|to)\b',
                r'\b(over|under|above|below|greater than|less than|higher|lower)\b',
                r'\b(exceeding|below|within|outside)\b'
            ]
        }
        
        # Initialize ambiguity detection rules
        self._ambiguity_rules = [
            self._check_missing_time_period,
            self._check_ambiguous_metric,
            self._check_missing_business_unit,
            self._check_missing_comparison_basis,
            self._check_complex_query
        ]
    
    def analyze_query(self, query: str) -> Dict[str, Any]:
        """
        Analyze a user query to extract key components and identify ambiguities.
        
        Args:
            query: The user query to analyze
            
        Returns:
            Dictionary with analysis results
        """
        self._logger.debug(f"Analyzing query: {query}")
        
        # Initialize the analysis result
        analysis = {
            "original_query": query,
            "entities": self._extract_entities(query),
            "intent": self._determine_intent(query),
            "ambiguities": [],
            "clarification_needed": False,
            "suggested_clarification_questions": []
        }
        
        # Check for ambiguities
        for rule in self._ambiguity_rules:
            rule(query, analysis)
        
        # Determine if clarification is needed
        if analysis["ambiguities"]:
            analysis["clarification_needed"] = True
            analysis["suggested_clarification_questions"] = self._generate_clarification_questions(analysis)
        
        return analysis
    
    def _extract_entities(self, query: str) -> Dict[str, List[Dict[str, Any]]]:
        """
        Extract entities from the query.
        
        Args:
            query: The query to analyze
            
        Returns:
            Dictionary mapping entity types to extracted entities
        """
        entities = {
            "time_period": [],
            "metrics": [],
            "business_units": [],
            "comparison": []
        }
        
        # Extract entities using regex patterns
        for entity_type, patterns in self._entity_patterns.items():
            for pattern in patterns:
                matches = re.finditer(pattern, query, re.IGNORECASE)
                for match in matches:
                    entity = {
                        "text": match.group(0),
                        "start": match.start(),
                        "end": match.end(),
                        "value": match.group(0)
                    }
                    
                    # Special handling for time periods
                    if entity_type == "time_period":
                        entity["value"] = self._normalize_time_period(match)
                    
                    entities[entity_type].append(entity)
        
        return entities
    
    def _normalize_time_period(self, match) -> str:
        """
        Normalize time period matches to a standard format.
        
        Args:
            match: The regex match object
            
        Returns:
            Normalized time period string
        """
        # Get the full matched text
        time_text = match.group(0).lower()
        
        # Quarter pattern: Q1 2023 or 2023 Q1
        q_match = re.search(r'q([1-4])\s*(?:of\s*)?\s*([0-9]{4})', time_text) or \
                 re.search(r'quarter\s*([1-4])\s*(?:of\s*)?\s*([0-9]{4})', time_text) or \
                 re.search(r'([0-9]{4})\s*q([1-4])', time_text) or \
                 re.search(r'([0-9]{4})\s*quarter\s*([1-4])', time_text)
        
        if q_match:
            if len(q_match.groups()) == 2:
                if q_match.group(1).isdigit() and len(q_match.group(1)) == 4:
                    # Format: 2023 Q1
                    year = q_match.group(1)
                    quarter = q_match.group(2)
                else:
                    # Format: Q1 2023
                    quarter = q_match.group(1)
                    year = q_match.group(2)
                return f"Q{quarter}_{year}"
        
        # Month pattern: January 2023
        month_match = re.search(r'(jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)[a-z]*\s*([0-9]{4})', time_text)
        if month_match:
            month_map = {
                'jan': '01', 'feb': '02', 'mar': '03', 'apr': '04', 'may': '05', 'jun': '06',
                'jul': '07', 'aug': '08', 'sep': '09', 'oct': '10', 'nov': '11', 'dec': '12'
            }
            month_abbr = month_match.group(1).lower()
            year = month_match.group(2)
            month = month_map.get(month_abbr, '00')
            return f"{year}-{month}"
        
        # Fiscal year pattern: FY 2023
        fy_match = re.search(r'fy\s*([0-9]{4})', time_text)
        if fy_match:
            return f"FY_{fy_match.group(1)}"
        
        # Relative time pattern: last quarter, current year
        relative_match = re.search(r'(last|previous|current|next)\s+(quarter|month|year)', time_text)
        if relative_match:
            return f"{relative_match.group(1)}_{relative_match.group(2)}"
        
        # Date pattern: YYYY-MM-DD
        date_match = re.search(r'([0-9]{4})-([0-9]{2})-([0-9]{2})', time_text)
        if date_match:
            return date_match.group(0)
        
        # If no specific pattern matches, return the original text
        return time_text
    
    def _determine_intent(self, query: str) -> str:
        """
        Determine the primary intent of the query.
        
        Args:
            query: The query to analyze
            
        Returns:
            Intent string
        """
        # Look for common intent patterns
        if re.search(r'\b(what|show|display|list|give me)\b', query, re.IGNORECASE):
            if re.search(r'\b(total|sum|overall)\b', query, re.IGNORECASE):
                return "aggregation"
            if re.search(r'\b(trend|over time|change|growth)\b', query, re.IGNORECASE):
                return "trend_analysis"
            if re.search(r'\b(compare|comparison|versus|vs|against)\b', query, re.IGNORECASE):
                return "comparison"
            return "retrieval"
        
        if re.search(r'\b(how much|how many)\b', query, re.IGNORECASE):
            return "quantification"
        
        if re.search(r'\b(why|explain|reason)\b', query, re.IGNORECASE):
            return "explanation"
        
        if re.search(r'\b(forecast|predict|projection)\b', query, re.IGNORECASE):
            return "prediction"
        
        # Default to retrieval if no specific intent is detected
        return "retrieval"
    
    def _check_missing_time_period(self, query: str, analysis: Dict[str, Any]) -> None:
        """
        Check if the query is missing a time period.
        
        Args:
            query: The query to analyze
            analysis: The current analysis results to update
        """
        if not analysis["entities"]["time_period"]:
            analysis["ambiguities"].append({
                "type": "missing_time_period",
                "description": "The query does not specify a time period",
                "severity": "high"
            })
    
    def _check_ambiguous_metric(self, query: str, analysis: Dict[str, Any]) -> None:
        """
        Check if the query has ambiguous metrics.
        
        Args:
            query: The query to analyze
            analysis: The current analysis results to update
        """
        # Check if the query implies metrics but doesn't specify which ones
        if re.search(r'\b(how much|how many|total|amount)\b', query, re.IGNORECASE) and not analysis["entities"]["metrics"]:
            analysis["ambiguities"].append({
                "type": "ambiguous_metric",
                "description": "The query implies a metric but doesn't specify which one",
                "severity": "medium"
            })
    
    def _check_missing_business_unit(self, query: str, analysis: Dict[str, Any]) -> None:
        """
        Check if the query should specify a business unit but doesn't.
        
        Args:
            query: The query to analyze
            analysis: The current analysis results to update
        """
        # Check if the query implies a business unit scope but doesn't specify which one
        if (re.search(r'\b(department|dept|team|by org)\b', query, re.IGNORECASE) and 
            not analysis["entities"]["business_units"]):
            analysis["ambiguities"].append({
                "type": "missing_business_unit",
                "description": "The query implies a business unit scope but doesn't specify which one",
                "severity": "medium"
            })
    
    def _check_missing_comparison_basis(self, query: str, analysis: Dict[str, Any]) -> None:
        """
        Check if the query has a comparison without a clear basis.
        
        Args:
            query: The query to analyze
            analysis: The current analysis results to update
        """
        # Check if the query has comparison terms but doesn't specify what to compare against
        if analysis["entities"]["comparison"] and analysis["intent"] == "comparison":
            has_comparison_basis = False
            
            # Check for multiple time periods (implies comparison between periods)
            if len(analysis["entities"]["time_period"]) >= 2:
                has_comparison_basis = True
                
            # Check for specific comparison basis phrases
            comparison_basis_patterns = [
                r'\b(compared to|versus|vs|against)\s+[^.?!]+',
                r'\b(budget\s+vs\s+actual|actual\s+vs\s+budget)',
                r'\b(year[\s-]*over[\s-]*year|month[\s-]*over[\s-]*month|quarter[\s-]*over[\s-]*quarter)',
                r'\b(YoY|MoM|QoQ)\b'
            ]
            
            for pattern in comparison_basis_patterns:
                if re.search(pattern, query, re.IGNORECASE):
                    has_comparison_basis = True
                    break
            
            if not has_comparison_basis:
                analysis["ambiguities"].append({
                    "type": "missing_comparison_basis",
                    "description": "The query implies a comparison but doesn't clearly specify what to compare against",
                    "severity": "high"
                })
    
    def _check_complex_query(self, query: str, analysis: Dict[str, Any]) -> None:
        """
        Check if the query is too complex or contains multiple questions.
        
        Args:
            query: The query to analyze
            analysis: The current analysis results to update
        """
        # Check for multiple questions
        if len(re.findall(r'\?', query)) > 1:
            analysis["ambiguities"].append({
                "type": "multiple_questions",
                "description": "The query contains multiple questions",
                "severity": "high"
            })
            return
        
        # Check for complex sentence structure
        if len(re.findall(r'and|or|also|additionally|moreover|furthermore|besides|as well as', query, re.IGNORECASE)) > 2:
            analysis["ambiguities"].append({
                "type": "complex_query",
                "description": "The query has a complex structure that may lead to ambiguity",
                "severity": "medium"
            })
    
    def _generate_clarification_questions(self, analysis: Dict[str, Any]) -> List[Dict[str, Any]]:
        """
        Generate clarification questions based on identified ambiguities.
        
        Args:
            analysis: The query analysis results
            
        Returns:
            List of clarification questions
        """
        questions = []
        
        for ambiguity in analysis["ambiguities"]:
            if ambiguity["type"] == "missing_time_period":
                questions.append({
                    "question": "What time period would you like to analyze?",
                    "type": "time_period",
                    "options": ["Current quarter", "Previous quarter", "Year to date", "Last year", "Custom period"],
                    "priority": 1
                })
            
            elif ambiguity["type"] == "ambiguous_metric":
                metric_options = ["Budget amount", "Actual spend", "Forecast", "Headcount", "Revenue"]
                questions.append({
                    "question": "Which specific metric would you like to analyze?",
                    "type": "metric",
                    "options": metric_options,
                    "priority": 2
                })
            
            elif ambiguity["type"] == "missing_business_unit":
                questions.append({
                    "question": "Which business unit or department are you interested in?",
                    "type": "business_unit",
                    "priority": 2
                })
            
            elif ambiguity["type"] == "missing_comparison_basis":
                questions.append({
                    "question": "What would you like to compare against?",
                    "type": "comparison_basis",
                    "options": ["Prior period", "Budget", "Forecast", "Same period last year"],
                    "priority": 3
                })
            
            elif ambiguity["type"] == "multiple_questions":
                questions.append({
                    "question": "Your query contains multiple questions. Could you please ask one question at a time?",
                    "type": "simplification",
                    "priority": 1
                })
            
            elif ambiguity["type"] == "complex_query":
                questions.append({
                    "question": "Your query is quite complex. Could you please rephrase it more simply?",
                    "type": "simplification",
                    "priority": 2
                })
        
        # Sort questions by priority
        questions.sort(key=lambda x: x["priority"])
        
        return questions
    
    def generate_query_context(self, query: str, analysis: Dict[str, Any]) -> Dict[str, Any]:
        """
        Generate structured context from the query analysis.
        
        Args:
            query: The original query
            analysis: The query analysis results
            
        Returns:
            Dictionary with structured query context
        """
        context = {
            "original_query": query,
            "intent": analysis["intent"],
            "time_period": None,
            "metrics": [],
            "business_units": [],
            "comparison": None,
            "requires_clarification": analysis["clarification_needed"]
        }
        
        # Extract time period
        if analysis["entities"]["time_period"]:
            context["time_period"] = [e["value"] for e in analysis["entities"]["time_period"]]
        
        # Extract metrics
        if analysis["entities"]["metrics"]:
            context["metrics"] = [e["text"] for e in analysis["entities"]["metrics"]]
        
        # Extract business units
        if analysis["entities"]["business_units"]:
            context["business_units"] = [e["text"] for e in analysis["entities"]["business_units"]]
        
        # Extract comparison information
        if analysis["entities"]["comparison"]:
            comparison_texts = [e["text"] for e in analysis["entities"]["comparison"]]
            context["comparison"] = {
                "type": "comparison",
                "terms": comparison_texts
            }
        
        return context