"""
Query Reformulator Module

This module implements the query reformulation functionality for the Query Enhancer Agent,
responsible for reformulating user queries for improved clarity and SQL generation.
"""

import logging
from typing import Dict, List, Any, Optional, Tuple
import json

class QueryReformulator:
    """
    Reformulates user queries to improve clarity and SQL generation accuracy.
    
    The QueryReformulator:
    1. Standardizes terms and language in queries
    2. Expands abbreviated terms to their full form
    3. Incorporates clarifications provided by users
    4. Restructures queries for optimal SQL generation
    5. Formats the query in a way that helps the SQL generation process
    """
    
    def __init__(self, config: Dict[str, Any] = None):
        """
        Initialize a new query reformulator.
        
        Args:
            config: Configuration parameters
        """
        self._logger = logging.getLogger(__name__)
        self._config = config or {}
        
        # Standard term mappings
        self._term_mappings = {
            # Time periods
            "last quarter": "previous quarter",
            "this quarter": "current quarter",
            "ytd": "year to date",
            "mtd": "month to date",
            "qtd": "quarter to date",
            
            # Business units
            "dept": "department",
            "bu": "business unit",
            "org": "organization",
            
            # Metrics
            "spend": "expense",
            "expenses": "expense",
            "costs": "cost",
            "actuals": "actual",
            "budgets": "budget",
            "forecasts": "forecast",
            "hc": "headcount",
            "opex": "operational expense",
            "capex": "capital expense",
            
            # Comparison terms
            "vs": "versus",
            "compare": "comparison between",
            "diff": "difference",
            "var": "variance"
        }
        
        # Templates for query reformulation
        self._templates = {
            "aggregation": "What is the total {metric} for {business_unit} during {time_period}?",
            "comparison": "Compare the {metric} between {comparison_entities} during {time_period}.",
            "trend_analysis": "Show the trend of {metric} for {business_unit} over {time_period}.",
            "retrieval": "Retrieve the {metric} for {business_unit} during {time_period}."
        }
    
    def reformulate_query(self, original_query: str, analysis: Dict[str, Any], 
                          clarifications: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """
        Reformulate a query based on analysis and optional clarifications.
        
        Args:
            original_query: The original user query
            analysis: The query analysis results
            clarifications: Optional user-provided clarifications
            
        Returns:
            Dictionary with reformulation results
        """
        self._logger.debug(f"Reformulating query: {original_query}")
        
        # Start with the original query
        reformulated_query = original_query
        
        # Apply term standardization
        reformulated_query = self._standardize_terms(reformulated_query)
        
        # If clarifications were provided, incorporate them
        if clarifications:
            reformulated_query = self._incorporate_clarifications(reformulated_query, analysis, clarifications)
        
        # Generate a structured version if we have enough information
        structured_query = self._generate_structured_query(analysis, clarifications)
        
        # Create the result dictionary
        result = {
            "original_query": original_query,
            "reformulated_query": reformulated_query,
            "structured_query": structured_query,
            "transformations": []
        }
        
        if reformulated_query != original_query:
            result["transformations"].append({
                "type": "reformulation",
                "description": "Query was reformulated for improved clarity"
            })
        
        if clarifications:
            result["transformations"].append({
                "type": "clarification",
                "description": "User clarifications were incorporated"
            })
        
        return result
    
    def _standardize_terms(self, query: str) -> str:
        """
        Standardize terms in the query.
        
        Args:
            query: The query to standardize
            
        Returns:
            Standardized query
        """
        standardized_query = query.lower()
        
        # Replace terms with their standard forms
        for term, replacement in self._term_mappings.items():
            # Use word boundaries to ensure we match complete words
            standardized_query = standardized_query.replace(f" {term} ", f" {replacement} ")
            
            # Check for term at the beginning of the query
            if standardized_query.startswith(f"{term} "):
                standardized_query = f"{replacement} " + standardized_query[len(term)+1:]
            
            # Check for term at the end of the query
            if standardized_query.endswith(f" {term}"):
                standardized_query = standardized_query[:-len(term)-1] + f" {replacement}"
        
        # Restore the first letter capitalization
        if standardized_query and standardized_query[0].isalpha():
            standardized_query = standardized_query[0].upper() + standardized_query[1:]
        
        return standardized_query
    
    def _incorporate_clarifications(self, query: str, analysis: Dict[str, Any], 
                                   clarifications: Dict[str, Any]) -> str:
        """
        Incorporate user clarifications into the query.
        
        Args:
            query: The current query
            analysis: The query analysis results
            clarifications: User-provided clarifications
            
        Returns:
            Updated query with clarifications
        """
        updated_query = query
        
        # Handle time period clarification
        if "time_period" in clarifications and clarifications["time_period"]:
            # Check if we need to add or replace a time period
            if not analysis["entities"]["time_period"]:
                # Add time period if missing
                updated_query += f" for {clarifications['time_period']}"
            else:
                # Replace existing time period
                for entity in analysis["entities"]["time_period"]:
                    updated_query = updated_query.replace(entity["text"], clarifications["time_period"])
        
        # Handle metric clarification
        if "metric" in clarifications and clarifications["metric"]:
            if not analysis["entities"]["metrics"]:
                # If query doesn't mention a metric, add it
                if "show" in updated_query.lower() or "display" in updated_query.lower():
                    # For queries like "Show the ... for department X"
                    updated_query = updated_query.replace("the", f"the {clarifications['metric']}")
                else:
                    # For other queries, try to insert at an appropriate point
                    updated_query += f" for {clarifications['metric']}"
            else:
                # Replace ambiguous metric terms
                for entity in analysis["entities"]["metrics"]:
                    if entity["text"].lower() in ["data", "numbers", "figures", "information", "stats", "amount"]:
                        updated_query = updated_query.replace(entity["text"], clarifications["metric"])
        
        # Handle business unit clarification
        if "business_unit" in clarifications and clarifications["business_unit"]:
            if not analysis["entities"]["business_units"]:
                # Add business unit if missing
                updated_query += f" for {clarifications['business_unit']}"
            else:
                # Replace ambiguous business unit terms
                for entity in analysis["entities"]["business_units"]:
                    if entity["text"].lower() in ["department", "dept", "team", "org", "business unit"]:
                        updated_query = updated_query.replace(entity["text"], clarifications["business_unit"])
        
        # Handle comparison basis clarification
        if "comparison_basis" in clarifications and clarifications["comparison_basis"]:
            if "compare" in updated_query.lower() or "comparison" in updated_query.lower():
                if "to" in updated_query.lower() or "with" in updated_query.lower():
                    # Try to replace what comes after "to" or "with"
                    parts = updated_query.split(" to ", 1)
                    if len(parts) > 1:
                        updated_query = f"{parts[0]} to {clarifications['comparison_basis']}"
                    else:
                        parts = updated_query.split(" with ", 1)
                        if len(parts) > 1:
                            updated_query = f"{parts[0]} with {clarifications['comparison_basis']}"
                else:
                    # Add comparison basis
                    updated_query += f" compared to {clarifications['comparison_basis']}"
            else:
                # If no comparison terms, just add the basis
                updated_query += f" compared to {clarifications['comparison_basis']}"
        
        return updated_query
    
    def _generate_structured_query(self, analysis: Dict[str, Any], 
                                  clarifications: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """
        Generate a structured representation of the query.
        
        Args:
            analysis: The query analysis results
            clarifications: Optional user-provided clarifications
            
        Returns:
            Structured query dictionary
        """
        # Initialize with the analysis
        structured = {
            "intent": analysis["intent"],
            "time_period": None,
            "metrics": [],
            "business_units": [],
            "comparison": None,
            "aggregation": None
        }
        
        # Extract entities from analysis
        if analysis["entities"]["time_period"]:
            structured["time_period"] = [e["value"] for e in analysis["entities"]["time_period"]]
        
        if analysis["entities"]["metrics"]:
            structured["metrics"] = [e["text"] for e in analysis["entities"]["metrics"]]
        
        if analysis["entities"]["business_units"]:
            structured["business_units"] = [e["text"] for e in analysis["entities"]["business_units"]]
        
        # Extract comparison information
        if analysis["entities"]["comparison"]:
            structured["comparison"] = {
                "type": "comparison",
                "terms": [e["text"] for e in analysis["entities"]["comparison"]]
            }
        
        # Detect aggregation
        agg_terms = ["total", "sum", "average", "avg", "mean", "median", "min", "max", "count"]
        for term in agg_terms:
            if term in " ".join(structured["metrics"]).lower():
                structured["aggregation"] = term
                break
        
        # Incorporate clarifications if provided
        if clarifications:
            if "time_period" in clarifications and clarifications["time_period"]:
                if not structured["time_period"]:
                    structured["time_period"] = [clarifications["time_period"]]
                else:
                    # Replace if clarification is more specific
                    structured["time_period"] = [clarifications["time_period"]]
            
            if "metric" in clarifications and clarifications["metric"]:
                if not structured["metrics"]:
                    structured["metrics"] = [clarifications["metric"]]
                else:
                    # Add if not already present
                    if clarifications["metric"] not in structured["metrics"]:
                        structured["metrics"].append(clarifications["metric"])
            
            if "business_unit" in clarifications and clarifications["business_unit"]:
                if not structured["business_units"]:
                    structured["business_units"] = [clarifications["business_unit"]]
                else:
                    # Add if not already present
                    if clarifications["business_unit"] not in structured["business_units"]:
                        structured["business_units"].append(clarifications["business_unit"])
            
            if "comparison_basis" in clarifications and clarifications["comparison_basis"]:
                if not structured["comparison"]:
                    structured["comparison"] = {
                        "type": "comparison",
                        "terms": ["compared to"],
                        "basis": clarifications["comparison_basis"]
                    }
                else:
                    structured["comparison"]["basis"] = clarifications["comparison_basis"]
        
        return structured
    
    def generate_sql_friendly_query(self, analysis: Dict[str, Any], 
                                   reformulation: Dict[str, Any]) -> str:
        """
        Generate a query formatted specifically to assist SQL generation.
        
        Args:
            analysis: The query analysis results
            reformulation: The query reformulation results
            
        Returns:
            SQL-friendly query string
        """
        # Start with the structured query
        structured = reformulation.get("structured_query", {})
        
        # Build a query that's optimized for SQL generation
        sql_friendly_parts = []
        
        # Add the intent
        intent = structured.get("intent", analysis["intent"])
        if intent == "aggregation":
            sql_friendly_parts.append(f"Compute the aggregation")
        elif intent == "comparison":
            sql_friendly_parts.append(f"Compare the data")
        elif intent == "trend_analysis":
            sql_friendly_parts.append(f"Analyze the trend")
        else:
            sql_friendly_parts.append(f"Retrieve the data")
        
        # Add metrics
        metrics = structured.get("metrics", [])
        if metrics:
            metric_str = ", ".join(metrics)
            sql_friendly_parts.append(f"for the following metrics: {metric_str}")
        
        # Add business units
        business_units = structured.get("business_units", [])
        if business_units:
            bu_str = ", ".join(business_units)
            sql_friendly_parts.append(f"filtered by business units: {bu_str}")
        
        # Add time period
        time_period = structured.get("time_period", [])
        if time_period:
            time_str = ", ".join(time_period)
            sql_friendly_parts.append(f"during the time period: {time_str}")
        
        # Add comparison basis if applicable
        comparison = structured.get("comparison")
        if comparison and "basis" in comparison:
            sql_friendly_parts.append(f"compared to {comparison['basis']}")
        
        # Add aggregation if applicable
        aggregation = structured.get("aggregation")
        if aggregation:
            sql_friendly_parts.append(f"using the {aggregation} aggregation function")
        
        # Combine all parts
        sql_friendly_query = " ".join(sql_friendly_parts)
        
        return sql_friendly_query