"""
Query Enhancer Agent Module

This module implements the Query Enhancer Agent, responsible for analyzing user queries,
identifying ambiguities, requesting clarification when needed, and reformulating queries
for improved SQL generation.
"""

import os
import json
import logging
import asyncio
from typing import Dict, List, Any, Optional, Tuple
import re

from ...core.interfaces.agent_interface import Agent, AgentType, ExecutionStatus, Message
from ...core.communication.event_bus import get_event_bus
from ...core.state.state_manager import get_state_manager, QueryState
from .query_analyzer import QueryAnalyzer
from .query_reformulator import QueryReformulator


class QueryEnhancerAgent(Agent):
    """
    Query Enhancer Agent for analyzing and improving user queries.
    
    The QueryEnhancerAgent:
    1. Analyzes user queries to identify key components and ambiguities
    2. Requests clarification from users when necessary
    3. Reformulates queries for improved clarity and SQL generation
    4. Provides enhanced query context for downstream agents
    5. Maintains a record of query clarifications and transformations
    """
    
    def __init__(self, agent_id: str, config: Dict[str, Any]):
        """
        Initialize a new query enhancer agent.
        
        Args:
            agent_id: Unique identifier for this agent
            config: Configuration parameters for this agent
        """
        super().__init__(agent_id, AgentType.QUERY_ENHANCER)
        self._logger = logging.getLogger(__name__)
        self._config = config
        self._initialized = False
        self._event_bus = get_event_bus()
        self._state_manager = get_state_manager()
        
        # Initialize components
        self._analyzer = QueryAnalyzer(config.get("analyzer_config", {}))
        self._reformulator = QueryReformulator(config.get("reformulator_config", {}))
        
        # Settings
        self._max_clarification_rounds = config.get("max_clarification_rounds", 3)
        self._clarification_threshold = config.get("clarification_threshold", 0.7)
        self._auto_enhance = config.get("auto_enhance", True)
        
        # Tracking for active clarification dialogs
        self._clarification_dialogs = {}
    
    async def initialize(self, config: Dict[str, Any]) -> bool:
        """
        Initialize the agent with configuration parameters.
        
        Args:
            config: Configuration parameters
            
        Returns:
            True if initialization was successful, False otherwise
        """
        try:
            # Update configuration
            self._config.update(config)
            
            # Update settings from new config
            self._max_clarification_rounds = self._config.get("max_clarification_rounds", self._max_clarification_rounds)
            self._clarification_threshold = self._config.get("clarification_threshold", self._clarification_threshold)
            self._auto_enhance = self._config.get("auto_enhance", self._auto_enhance)
            
            # Re-initialize components with new config
            if "analyzer_config" in self._config:
                self._analyzer = QueryAnalyzer(self._config["analyzer_config"])
            
            if "reformulator_config" in self._config:
                self._reformulator = QueryReformulator(self._config["reformulator_config"])
            
            # Register with the event bus
            self._event_bus.register_agent(AgentType.QUERY_ENHANCER, self.process)
            
            self._initialized = True
            self._logger.info("Query enhancer agent initialized successfully")
            return True
            
        except Exception as e:
            self._logger.error(f"Error initializing query enhancer agent: {str(e)}")
            return False
    
    async def process(self, message: Message) -> Message:
        """
        Process an incoming message and produce a response.
        
        Args:
            message: The incoming message to process
            
        Returns:
            A response message
        """
        self._logger.info(f"Processing message: {message.message_type}")
        
        # Extract message content
        content = message.content
        
        # Check the message type and dispatch to the appropriate handler
        if message.message_type == "enhance_query":
            query = content.get("query")
            query_id = content.get("query_id")
            options = content.get("options", {})
            
            if query:
                result = await self.enhance_query(query, query_id, options)
                return Message(
                    sender=AgentType.QUERY_ENHANCER,
                    receiver=message.sender,
                    content=result,
                    message_type="query_enhanced",
                    trace_id=message.trace_id
                )
        
        elif message.message_type == "provide_clarification":
            query_id = content.get("query_id")
            clarifications = content.get("clarifications")
            
            if query_id and clarifications:
                result = await self.process_clarification(query_id, clarifications)
                return Message(
                    sender=AgentType.QUERY_ENHANCER,
                    receiver=message.sender,
                    content=result,
                    message_type="query_enhanced",
                    trace_id=message.trace_id
                )
        
        elif message.message_type == "analyze_query":
            query = content.get("query")
            
            if query:
                result = self.analyze_query(query)
                return Message(
                    sender=AgentType.QUERY_ENHANCER,
                    receiver=message.sender,
                    content=result,
                    message_type="query_analysis",
                    trace_id=message.trace_id
                )
        
        # Default response for unsupported message types
        return Message(
            sender=AgentType.QUERY_ENHANCER,
            receiver=message.sender,
            content={"error": "Unsupported message type"},
            message_type="error",
            trace_id=message.trace_id
        )
    
    def analyze_query(self, query: str) -> Dict[str, Any]:
        """
        Analyze a user query to extract components and identify ambiguities.
        
        Args:
            query: The user query to analyze
            
        Returns:
            Analysis results dictionary
        """
        self._logger.debug(f"Analyzing query: {query}")
        
        try:
            # Update status
            self.status = ExecutionStatus.IN_PROGRESS
            
            # Analyze the query
            analysis = self._analyzer.analyze_query(query)
            
            # Generate query context
            context = self._analyzer.generate_query_context(query, analysis)
            
            # Update status
            self.status = ExecutionStatus.COMPLETED
            
            # Return the analysis results
            return {
                "query": query,
                "analysis": analysis,
                "context": context
            }
            
        except Exception as e:
            self._logger.error(f"Error analyzing query: {str(e)}")
            self.status = ExecutionStatus.FAILED
            return {"error": str(e)}
    
    async def enhance_query(self, query: str, query_id: Optional[str] = None, 
                           options: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """
        Enhance a user query, potentially requesting clarifications if needed.
        
        Args:
            query: The user query to enhance
            query_id: Optional query ID for state tracking
            options: Optional enhancement options
            
        Returns:
            Dictionary with enhanced query results
        """
        self._logger.info(f"Enhancing query: {query}")
        
        try:
            # Update status
            self.status = ExecutionStatus.IN_PROGRESS
            
            # Get options
            options = options or {}
            skip_clarification = options.get("skip_clarification", False)
            force_clarification = options.get("force_clarification", False)
            
            # Analyze the query
            analysis = self._analyzer.analyze_query(query)
            
            # Generate a query ID if not provided
            if not query_id:
                query_id = f"query_{hash(query) & 0xffffffff}"
            
            # Check if clarification is needed
            needs_clarification = analysis["clarification_needed"] or force_clarification
            
            # If we need clarification and clarification is not skipped, request it
            if needs_clarification and not skip_clarification:
                # Create a clarification dialog
                self._clarification_dialogs[query_id] = {
                    "query": query,
                    "analysis": analysis,
                    "round": 0,
                    "clarifications": {},
                    "status": "pending"
                }
                
                # Store in query state if a query ID is provided
                self._update_query_state(query_id, query, analysis)
                
                # Create clarification request
                clarification_request = {
                    "query_id": query_id,
                    "query": query,
                    "questions": analysis["suggested_clarification_questions"],
                    "status": "clarification_requested"
                }
                
                # Update status
                self.status = ExecutionStatus.WAITING
                
                return clarification_request
            
            # If no clarification needed or skipped, proceed with reformulation
            reformulation = self._reformulator.reformulate_query(query, analysis)
            
            # Generate SQL-friendly query
            sql_friendly_query = self._reformulator.generate_sql_friendly_query(analysis, reformulation)
            
            # Generate enhanced query context
            context = self._analyzer.generate_query_context(query, analysis)
            
            # Store in query state if a query ID is provided
            self._update_query_state(query_id, query, analysis, reformulation, sql_friendly_query, context)
            
            # Update status
            self.status = ExecutionStatus.COMPLETED
            
            # Return the enhanced query results
            return {
                "query_id": query_id,
                "original_query": query,
                "enhanced_query": reformulation["reformulated_query"],
                "sql_friendly_query": sql_friendly_query,
                "structured_query": reformulation["structured_query"],
                "analysis": analysis,
                "context": context,
                "status": "enhanced"
            }
            
        except Exception as e:
            self._logger.error(f"Error enhancing query: {str(e)}")
            self.status = ExecutionStatus.FAILED
            return {"error": str(e)}
    
    async def process_clarification(self, query_id: str, 
                                  clarifications: Dict[str, Any]) -> Dict[str, Any]:
        """
        Process user-provided clarifications and update the query enhancement.
        
        Args:
            query_id: The query ID for the clarification dialog
            clarifications: User-provided clarifications
            
        Returns:
            Dictionary with updated enhancement results
        """
        self._logger.info(f"Processing clarification for query ID: {query_id}")
        
        try:
            # Update status
            self.status = ExecutionStatus.IN_PROGRESS
            
            # Check if we have an active clarification dialog for this query ID
            if query_id not in self._clarification_dialogs:
                raise ValueError(f"No active clarification dialog for query ID: {query_id}")
            
            # Get the dialog state
            dialog = self._clarification_dialogs[query_id]
            query = dialog["query"]
            analysis = dialog["analysis"]
            
            # Update the dialog state
            dialog["round"] += 1
            dialog["clarifications"].update(clarifications)
            
            # Get the updated clarifications
            updated_clarifications = dialog["clarifications"]
            
            # Reformulate the query with the clarifications
            reformulation = self._reformulator.reformulate_query(query, analysis, updated_clarifications)
            
            # Generate SQL-friendly query
            sql_friendly_query = self._reformulator.generate_sql_friendly_query(analysis, reformulation)
            
            # Generate enhanced query context with clarifications
            context = self._analyzer.generate_query_context(query, analysis)
            
            # Check if we need further clarification
            needs_more_clarification = False
            remaining_questions = []
            
            # If we haven't reached the maximum rounds and there are still ambiguities,
            # check if we need more clarification
            if dialog["round"] < self._max_clarification_rounds:
                for ambiguity in analysis["ambiguities"]:
                    ambiguity_type = ambiguity["type"]
                    
                    # Check if this ambiguity type has been clarified
                    if ambiguity_type == "missing_time_period" and "time_period" not in updated_clarifications:
                        needs_more_clarification = True
                        # Find the corresponding question
                        for question in analysis["suggested_clarification_questions"]:
                            if question["type"] == "time_period":
                                remaining_questions.append(question)
                                break
                    
                    elif ambiguity_type == "ambiguous_metric" and "metric" not in updated_clarifications:
                        needs_more_clarification = True
                        for question in analysis["suggested_clarification_questions"]:
                            if question["type"] == "metric":
                                remaining_questions.append(question)
                                break
                    
                    elif ambiguity_type == "missing_business_unit" and "business_unit" not in updated_clarifications:
                        needs_more_clarification = True
                        for question in analysis["suggested_clarification_questions"]:
                            if question["type"] == "business_unit":
                                remaining_questions.append(question)
                                break
                    
                    elif ambiguity_type == "missing_comparison_basis" and "comparison_basis" not in updated_clarifications:
                        needs_more_clarification = True
                        for question in analysis["suggested_clarification_questions"]:
                            if question["type"] == "comparison_basis":
                                remaining_questions.append(question)
                                break
            
            # Store in query state
            self._update_query_state(query_id, query, analysis, reformulation, sql_friendly_query, context, updated_clarifications)
            
            # If we need more clarification, return a new clarification request
            if needs_more_clarification and remaining_questions:
                dialog["status"] = "pending"
                
                # Update status
                self.status = ExecutionStatus.WAITING
                
                return {
                    "query_id": query_id,
                    "query": query,
                    "reformulated_query": reformulation["reformulated_query"],
                    "questions": remaining_questions,
                    "status": "clarification_requested"
                }
            
            # If no more clarification needed, return the enhanced query results
            dialog["status"] = "completed"
            
            # Update status
            self.status = ExecutionStatus.COMPLETED
            
            return {
                "query_id": query_id,
                "original_query": query,
                "enhanced_query": reformulation["reformulated_query"],
                "sql_friendly_query": sql_friendly_query,
                "structured_query": reformulation["structured_query"],
                "analysis": analysis,
                "context": context,
                "clarifications": updated_clarifications,
                "status": "enhanced"
            }
            
        except Exception as e:
            self._logger.error(f"Error processing clarification: {str(e)}")
            self.status = ExecutionStatus.FAILED
            return {"error": str(e)}
    
    def _update_query_state(self, query_id: str, query: str, analysis: Dict[str, Any],
                          reformulation: Optional[Dict[str, Any]] = None,
                          sql_friendly_query: Optional[str] = None,
                          context: Optional[Dict[str, Any]] = None,
                          clarifications: Optional[Dict[str, Any]] = None) -> None:
        """
        Update the query state with enhancement information.
        
        Args:
            query_id: The query ID
            query: The original query
            analysis: The query analysis results
            reformulation: Optional query reformulation results
            sql_friendly_query: Optional SQL-friendly query
            context: Optional query context
            clarifications: Optional user-provided clarifications
        """
        # Get the query state
        query_state = self._state_manager.get_query_state(query_id)
        
        # If no existing state, create one
        if not query_state:
            self._state_manager.create_query_state(query_id, {
                "raw_query": query,
                "timestamp": asyncio.get_event_loop().time()
            })
            query_state = self._state_manager.get_query_state(query_id)
        
        # Update the state
        state_updates = {
            "analysis": analysis,
            "requires_clarification": analysis["clarification_needed"]
        }
        
        if reformulation:
            state_updates["reformulated_query"] = reformulation["reformulated_query"]
            state_updates["structured_query"] = reformulation["structured_query"]
            state_updates["transformations"] = reformulation.get("transformations", [])
        
        if sql_friendly_query:
            state_updates["sql_friendly_query"] = sql_friendly_query
        
        if context:
            state_updates["query_context"] = context
        
        if clarifications:
            state_updates["clarifications"] = clarifications
        
        # Update the state
        self._state_manager.update_query_state(query_id, state_updates)
    
    def get_capabilities(self) -> List[str]:
        """
        Return a list of capabilities this agent provides.
        
        Returns:
            List of capability strings
        """
        return [
            "query_analysis",
            "query_enhancement",
            "clarification_handling",
            "query_reformulation",
            "context_generation"
        ]
    
    def get_status(self) -> Dict[str, Any]:
        """
        Get the current status of this agent.
        
        Returns:
            A dictionary with status information
        """
        return {
            "agent_id": self.agent_id,
            "agent_type": self.agent_type,
            "status": self.status,
            "active_dialogs": len(self._clarification_dialogs),
            "initialized": self._initialized
        }
    
    async def shutdown(self) -> bool:
        """
        Perform cleanup when shutting down the agent.
        
        Returns:
            True if shutdown was successful, False otherwise
        """
        try:
            # Clear clarification dialogs
            self._clarification_dialogs.clear()
            
            # Unregister from the event bus
            self._event_bus.unregister_agent(AgentType.QUERY_ENHANCER)
            
            return True
            
        except Exception as e:
            self._logger.error(f"Error shutting down query enhancer agent: {str(e)}")
            return False