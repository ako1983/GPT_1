"""
SQL Optimizer Module

This module optimizes SQL queries for improved performance and efficiency.
"""

import logging
import re
from typing import Dict, List, Any, Optional, Tuple
import sqlparse
from sqlparse.sql import Token, TokenList, Identifier, IdentifierList, Parenthesis, Where


class SQLOptimizer:
    """
    Optimizes SQL queries for improved performance and efficiency.
    
    The SQLOptimizer:
    1. Identifies potential performance bottlenecks in SQL queries
    2. Suggests query optimizations for better performance
    3. Applies optimization techniques specific to the SQL dialect
    4. Provides alternative query formulations
    5. Explains optimization rationale for educational purposes
    """
    
    def __init__(self, config: Dict[str, Any] = None):
        """
        Initialize a new SQL optimizer.
        
        Args:
            config: Configuration parameters
        """
        self._logger = logging.getLogger(__name__)
        self._config = config or {}
        
        # Optimization settings
        self._dialect = self._config.get("dialect", "bigquery")
        self._aggressive = self._config.get("aggressive_optimization", False)
        
        # Load optimization patterns for the specific dialect
        self._optimization_patterns = self._load_optimization_patterns()
    
    def _load_optimization_patterns(self) -> Dict[str, List[Dict[str, Any]]]:
        """
        Load optimization patterns based on the dialect.
        
        Returns:
            Dictionary of optimization patterns
        """
        # Common patterns for all dialects
        patterns = {
            "table_scans": [],
            "joins": [],
            "aggregations": [],
            "filters": []
        }
        
        # Add dialect-specific patterns
        if self._dialect == "bigquery":
            patterns["table_scans"].extend([
                {
                    "description": "Avoid SELECT *",
                    "pattern": r"SELECT\s+\*\s+FROM",
                    "condition": lambda sql: "SELECT *" in sql.upper(),
                    "suggestion": "Specify only the columns you need instead of using SELECT *",
                    "replacement": None,
                    "impact": "high"
                },
                {
                    "description": "Add LIMIT for development queries",
                    "pattern": r"SELECT\s+.*\s+FROM\s+.*(?!\s+LIMIT\s+\d+)",
                    "condition": lambda sql: "LIMIT" not in sql.upper(),
                    "suggestion": "Add a LIMIT clause for development queries",
                    "replacement": lambda sql: sql + " LIMIT 1000",
                    "impact": "medium"
                }
            ])
            
            patterns["joins"].extend([
                {
                    "description": "Use explicit JOIN syntax",
                    "pattern": r"FROM\s+(\w+)(?:\s+,\s+|\s*,\s*)(\w+)\s+WHERE\s+(\w+)\.(\w+)\s*=\s*(\w+)\.(\w+)",
                    "condition": lambda sql: "," in sql and "WHERE" in sql.upper(),
                    "suggestion": "Use explicit JOIN syntax instead of implicit joins with commas",
                    "replacement": r"FROM \1 JOIN \2 ON \3.\4 = \5.\6",
                    "impact": "medium"
                },
                {
                    "description": "Ensure JOIN conditions use indexed columns",
                    "pattern": None,  # This requires schema knowledge
                    "condition": lambda sql: " JOIN " in sql.upper() and " ON " in sql.upper(),
                    "suggestion": "Ensure JOIN conditions use indexed columns or primary/foreign keys",
                    "replacement": None,
                    "impact": "high"
                }
            ])
            
            patterns["aggregations"].extend([
                {
                    "description": "Add WHERE before GROUP BY for filtering",
                    "pattern": r"GROUP BY\s+.*\s+HAVING\s+(\w+)\s*([<>=!]+)\s*([^,)\s]+)",
                    "condition": lambda sql: "GROUP BY" in sql.upper() and "HAVING" in sql.upper() and "WHERE" not in sql.upper(),
                    "suggestion": "Move simple filter conditions from HAVING to WHERE when possible",
                    "replacement": None,  # This is complex to automate
                    "impact": "medium"
                }
            ])
            
            patterns["filters"].extend([
                {
                    "description": "Use partitioned column filters",
                    "pattern": None,  # This requires schema knowledge
                    "condition": lambda sql: True,  # Check all queries
                    "suggestion": "Include filters on partitioned columns (like date/time) to reduce data scanned",
                    "replacement": None,
                    "impact": "high"
                },
                {
                    "description": "Avoid functions in WHERE clause",
                    "pattern": r"WHERE\s+\w+\(([^)]+)\)",
                    "condition": lambda sql: "WHERE" in sql.upper() and re.search(r"WHERE\s+\w+\([^)]+\)", sql, re.IGNORECASE),
                    "suggestion": "Avoid using functions on columns in WHERE clauses as it prevents using indexes",
                    "replacement": None,  # This is complex to automate
                    "impact": "high"
                }
            ])
        
        return patterns
    
    def optimize_sql(self, sql: str, schema: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """
        Optimize a SQL query for improved performance.
        
        Args:
            sql: The SQL query to optimize
            schema: Optional schema information for more targeted optimizations
            
        Returns:
            Dictionary with optimization results
        """
        self._logger.debug(f"Optimizing SQL: {sql}")
        
        try:
            # Initialize result
            result = {
                "original_sql": sql,
                "optimized_sql": sql,
                "optimizations": [],
                "suggestions": [],
                "warnings": []
            }
            
            # Parse the SQL query
            parsed = sqlparse.parse(sql)
            if not parsed:
                result["warnings"].append({
                    "type": "parse_error",
                    "message": "Failed to parse SQL query"
                })
                return result
            
            stmt = parsed[0]
            
            # Analyze query structure
            query_structure = self._analyze_query_structure(stmt)
            
            # Apply optimizations based on patterns
            optimized_sql, optimizations, suggestions = self._apply_optimizations(sql, query_structure, schema)
            
            # Update the result
            result["optimized_sql"] = optimized_sql
            result["optimizations"] = optimizations
            result["suggestions"] = suggestions
            
            return result
            
        except Exception as e:
            self._logger.error(f"Error optimizing SQL: {str(e)}")
            return {
                "original_sql": sql,
                "optimized_sql": sql,
                "error": str(e),
                "optimizations": [],
                "suggestions": [],
                "warnings": [{"type": "error", "message": str(e)}]
            }
    
    def _analyze_query_structure(self, stmt: TokenList) -> Dict[str, Any]:
        """
        Analyze the structure of a SQL statement.
        
        Args:
            stmt: The SQL statement to analyze
            
        Returns:
            Dictionary with query structure information
        """
        structure = {
            "type": stmt.get_type(),
            "has_where": False,
            "has_group_by": False,
            "has_having": False,
            "has_order_by": False,
            "has_limit": False,
            "tables": [],
            "columns": [],
            "joins": [],
            "filters": []
        }
        
        # Check for presence of clauses
        for token in stmt.tokens:
            if token.is_keyword:
                token_upper = token.value.upper()
                if token_upper == "WHERE":
                    structure["has_where"] = True
                elif token_upper == "GROUP":
                    structure["has_group_by"] = True
                elif token_upper == "HAVING":
                    structure["has_having"] = True
                elif token_upper == "ORDER":
                    structure["has_order_by"] = True
                elif token_upper == "LIMIT":
                    structure["has_limit"] = True
        
        # Extract tables and columns if possible
        self._extract_tables_and_columns(stmt, structure)
        
        return structure
    
    def _extract_tables_and_columns(self, stmt: TokenList, structure: Dict[str, Any]) -> None:
        """
        Extract tables and columns from a SQL statement.
        
        Args:
            stmt: The SQL statement to analyze
            structure: The structure dictionary to update
        """
        # Extract FROM clause to identify tables
        from_seen = False
        select_seen = False
        current_token_type = None
        
        for token in stmt.tokens:
            # Track current clause
            if token.is_keyword:
                token_upper = token.value.upper()
                if token_upper == "SELECT":
                    select_seen = True
                    current_token_type = "SELECT"
                elif token_upper == "FROM":
                    from_seen = True
                    current_token_type = "FROM"
                elif token_upper in ("WHERE", "JOIN", "GROUP", "ORDER", "HAVING", "LIMIT"):
                    current_token_type = token_upper
            
            # Extract tables from FROM clause
            if from_seen and current_token_type == "FROM" and token.ttype is None:
                if isinstance(token, Identifier):
                    structure["tables"].append(token.get_real_name())
                elif isinstance(token, IdentifierList):
                    for identifier in token.get_identifiers():
                        structure["tables"].append(identifier.get_real_name())
            
            # Extract columns from SELECT clause
            if select_seen and current_token_type == "SELECT" and token.ttype is None:
                if isinstance(token, IdentifierList):
                    for identifier in token.get_identifiers():
                        column_name = identifier.get_real_name()
                        if column_name:
                            structure["columns"].append(column_name)
                elif isinstance(token, Identifier):
                    column_name = token.get_real_name()
                    if column_name:
                        structure["columns"].append(column_name)
            
            # Extract joins
            if "JOIN" in str(token).upper():
                structure["joins"].append(str(token))
            
            # Extract WHERE conditions
            if isinstance(token, Where):
                structure["filters"].append(str(token)[6:])  # Remove "WHERE " prefix
    
    def _apply_optimizations(self, sql: str, structure: Dict[str, Any], 
                           schema: Optional[Dict[str, Any]] = None) -> Tuple[str, List[Dict[str, Any]], List[Dict[str, Any]]]:
        """
        Apply optimization patterns to the SQL query.
        
        Args:
            sql: The SQL query to optimize
            structure: The query structure information
            schema: Optional schema information
            
        Returns:
            Tuple of (optimized SQL, applied optimizations, optimization suggestions)
        """
        optimized_sql = sql
        optimizations = []
        suggestions = []
        
        # Check for table scan optimizations
        for pattern in self._optimization_patterns["table_scans"]:
            if "condition" in pattern and not pattern["condition"](sql):
                continue
                
            if pattern["pattern"] is not None:
                if re.search(pattern["pattern"], sql, re.IGNORECASE | re.DOTALL):
                    # This pattern matches
                    if pattern["replacement"] is not None:
                        if callable(pattern["replacement"]):
                            # Function replacement
                            new_sql = pattern["replacement"](optimized_sql)
                        else:
                            # String replacement
                            new_sql = re.sub(pattern["pattern"], pattern["replacement"], optimized_sql, flags=re.IGNORECASE | re.DOTALL)
                        
                        if new_sql != optimized_sql:
                            optimized_sql = new_sql
                            optimizations.append({
                                "type": "table_scan",
                                "description": pattern["description"],
                                "impact": pattern["impact"]
                            })
                    else:
                        # No automatic replacement, add as suggestion
                        suggestions.append({
                            "type": "table_scan",
                            "description": pattern["description"],
                            "suggestion": pattern["suggestion"],
                            "impact": pattern["impact"]
                        })
            else:
                # Pattern with no regex, add as suggestion
                suggestions.append({
                    "type": "table_scan",
                    "description": pattern["description"],
                    "suggestion": pattern["suggestion"],
                    "impact": pattern["impact"]
                })
        
        # Check for join optimizations
        for pattern in self._optimization_patterns["joins"]:
            if "condition" in pattern and not pattern["condition"](sql):
                continue
                
            if pattern["pattern"] is not None:
                if re.search(pattern["pattern"], sql, re.IGNORECASE | re.DOTALL):
                    # This pattern matches
                    if pattern["replacement"] is not None:
                        if callable(pattern["replacement"]):
                            # Function replacement
                            new_sql = pattern["replacement"](optimized_sql)
                        else:
                            # String replacement
                            new_sql = re.sub(pattern["pattern"], pattern["replacement"], optimized_sql, flags=re.IGNORECASE | re.DOTALL)
                        
                        if new_sql != optimized_sql:
                            optimized_sql = new_sql
                            optimizations.append({
                                "type": "join",
                                "description": pattern["description"],
                                "impact": pattern["impact"]
                            })
                    else:
                        # No automatic replacement, add as suggestion
                        suggestions.append({
                            "type": "join",
                            "description": pattern["description"],
                            "suggestion": pattern["suggestion"],
                            "impact": pattern["impact"]
                        })
            else:
                # Pattern with no regex, add as suggestion
                suggestions.append({
                    "type": "join",
                    "description": pattern["description"],
                    "suggestion": pattern["suggestion"],
                    "impact": pattern["impact"]
                })
        
        # Check for aggregation optimizations
        for pattern in self._optimization_patterns["aggregations"]:
            if "condition" in pattern and not pattern["condition"](sql):
                continue
                
            if pattern["pattern"] is not None:
                if re.search(pattern["pattern"], sql, re.IGNORECASE | re.DOTALL):
                    # This pattern matches
                    if pattern["replacement"] is not None:
                        if callable(pattern["replacement"]):
                            # Function replacement
                            new_sql = pattern["replacement"](optimized_sql)
                        else:
                            # String replacement
                            new_sql = re.sub(pattern["pattern"], pattern["replacement"], optimized_sql, flags=re.IGNORECASE | re.DOTALL)
                        
                        if new_sql != optimized_sql:
                            optimized_sql = new_sql
                            optimizations.append({
                                "type": "aggregation",
                                "description": pattern["description"],
                                "impact": pattern["impact"]
                            })
                    else:
                        # No automatic replacement, add as suggestion
                        suggestions.append({
                            "type": "aggregation",
                            "description": pattern["description"],
                            "suggestion": pattern["suggestion"],
                            "impact": pattern["impact"]
                        })
            else:
                # Pattern with no regex, add as suggestion
                suggestions.append({
                    "type": "aggregation",
                    "description": pattern["description"],
                    "suggestion": pattern["suggestion"],
                    "impact": pattern["impact"]
                })
        
        # Check for filter optimizations
        for pattern in self._optimization_patterns["filters"]:
            if "condition" in pattern and not pattern["condition"](sql):
                continue
                
            if pattern["pattern"] is not None:
                if re.search(pattern["pattern"], sql, re.IGNORECASE | re.DOTALL):
                    # This pattern matches
                    if pattern["replacement"] is not None:
                        if callable(pattern["replacement"]):
                            # Function replacement
                            new_sql = pattern["replacement"](optimized_sql)
                        else:
                            # String replacement
                            new_sql = re.sub(pattern["pattern"], pattern["replacement"], optimized_sql, flags=re.IGNORECASE | re.DOTALL)
                        
                        if new_sql != optimized_sql:
                            optimized_sql = new_sql
                            optimizations.append({
                                "type": "filter",
                                "description": pattern["description"],
                                "impact": pattern["impact"]
                            })
                    else:
                        # No automatic replacement, add as suggestion
                        suggestions.append({
                            "type": "filter",
                            "description": pattern["description"],
                            "suggestion": pattern["suggestion"],
                            "impact": pattern["impact"]
                        })
            else:
                # Pattern with no regex, add as suggestion
                suggestions.append({
                    "type": "filter",
                    "description": pattern["description"],
                    "suggestion": pattern["suggestion"],
                    "impact": pattern["impact"]
                })
        
        # Add schema-specific optimizations if schema is provided
        if schema:
            schema_suggestions = self._get_schema_specific_optimizations(sql, structure, schema)
            suggestions.extend(schema_suggestions)
        
        return optimized_sql, optimizations, suggestions
    
    def _get_schema_specific_optimizations(self, sql: str, structure: Dict[str, Any], 
                                         schema: Dict[str, Any]) -> List[Dict[str, Any]]:
        """
        Get schema-specific optimization suggestions.
        
        Args:
            sql: The SQL query
            structure: The query structure information
            schema: The database schema
            
        Returns:
            List of optimization suggestions
        """
        suggestions = []
        
        # Check if schema has table information
        if "tables" not in schema:
            return suggestions
        
        # Check for partitioned columns
        for table_name, table_info in schema.get("tables", {}).items():
            # Skip tables not used in the query
            if table_name not in structure["tables"]:
                continue
            
            # Check for partitioned columns
            if "partitioned_by" in table_info:
                partition_column = table_info["partitioned_by"]
                
                # Check if the partition column is used in WHERE clause
                if structure["has_where"]:
                    # Simple check for partition column in WHERE
                    where_clause = " ".join(structure["filters"]).lower()
                    if partition_column.lower() not in where_clause and f"{table_name}.{partition_column}".lower() not in where_clause:
                        suggestions.append({
                            "type": "partition",
                            "description": f"Add filter on partition column '{partition_column}'",
                            "suggestion": f"Add a WHERE condition on {table_name}.{partition_column} to improve performance",
                            "impact": "high"
                        })
            
            # Check for clustered columns
            if "clustered_by" in table_info:
                cluster_columns = table_info["clustered_by"]
                if isinstance(cluster_columns, str):
                    cluster_columns = [cluster_columns]
                
                # Check if any cluster column is used in WHERE clause
                if structure["has_where"]:
                    where_clause = " ".join(structure["filters"]).lower()
                    cluster_used = False
                    
                    for cluster_column in cluster_columns:
                        if cluster_column.lower() in where_clause or f"{table_name}.{cluster_column}".lower() in where_clause:
                            cluster_used = True
                            break
                    
                    if not cluster_used:
                        suggestions.append({
                            "type": "cluster",
                            "description": f"Add filter on clustered columns {', '.join(cluster_columns)}",
                            "suggestion": f"Add a WHERE condition on one of the clustered columns to improve performance",
                            "impact": "medium"
                        })
        
        return suggestions
    
    def get_explanation(self, optimization: Dict[str, Any]) -> str:
        """
        Get a detailed explanation for an optimization.
        
        Args:
            optimization: The optimization to explain
            
        Returns:
            Explanation string
        """
        opt_type = optimization.get("type")
        description = optimization.get("description")
        impact = optimization.get("impact", "medium")
        
        if opt_type == "table_scan":
            explanation = f"{description}: "
            explanation += "Reducing the amount of data scanned is one of the most effective ways to improve query performance. "
            
            if "SELECT *" in description:
                explanation += "When you use SELECT *, the query engine has to process every column in the table, even if you only need a few. "
                explanation += "This increases the amount of data processed, network transfer, and memory usage. "
                explanation += "Instead, explicitly list only the columns you need in your query."
            
            elif "LIMIT" in description:
                explanation += "Adding a LIMIT clause to your query restricts the number of rows returned, which is especially useful during development and testing. "
                explanation += "This reduces the amount of data transferred and processed after the query execution."
        
        elif opt_type == "join":
            explanation = f"{description}: "
            
            if "explicit JOIN syntax" in description:
                explanation += "Using explicit JOIN syntax with ON conditions makes your query more readable and maintainable. "
                explanation += "It also helps the query optimizer better understand the relationships between tables and potentially choose a more efficient execution plan."
            
            elif "indexed columns" in description:
                explanation += "Joining tables on indexed columns allows the query engine to use more efficient join algorithms. "
                explanation += "When joins use non-indexed columns, the engine may need to perform full table scans, which can be very expensive for large tables."
        
        elif opt_type == "aggregation":
            explanation = f"{description}: "
            
            if "WHERE before GROUP BY" in description:
                explanation += "Filtering data with WHERE before GROUP BY reduces the amount of data that needs to be grouped and aggregated. "
                explanation += "This can significantly improve performance for large datasets. "
                explanation += "HAVING should only be used for filters that need to be applied after aggregation."
        
        elif opt_type == "filter":
            explanation = f"{description}: "
            
            if "partitioned column" in description:
                explanation += "Partitioned tables in BigQuery are divided into segments based on the partition column. "
                explanation += "Including a filter on the partition column allows the query engine to scan only the relevant partitions instead of the entire table. "
                explanation += "This can dramatically reduce the amount of data processed and query cost."
            
            elif "functions in WHERE" in description:
                explanation += "Using functions on columns in WHERE clauses prevents the query engine from using indexes effectively. "
                explanation += "Instead, try to restructure the query to apply the function to the constant value in the comparison, or create a materialized view or additional column with the pre-computed function result."
        
        elif opt_type == "partition":
            explanation = f"{description}: "
            explanation += "Partitioned tables in BigQuery are divided into segments based on the partition column. "
            explanation += "Adding a filter on the partition column allows the query engine to prune partitions and scan only the relevant data. "
            explanation += "This can reduce the amount of data processed by orders of magnitude, lowering query cost and improving performance."
        
        elif opt_type == "cluster":
            explanation = f"{description}: "
            explanation += "Clustered tables in BigQuery are sorted by the cluster columns within each partition. "
            explanation += "Adding a filter on a cluster column allows the query engine to skip reading blocks of data that don't match the filter. "
            explanation += "This can significantly improve performance for queries that filter on cluster columns."
        
        # Add impact assessment
        if impact == "high":
            explanation += "\n\nThis optimization has a HIGH impact on query performance and is strongly recommended."
        elif impact == "medium":
            explanation += "\n\nThis optimization has a MEDIUM impact on query performance and is recommended."
        else:
            explanation += "\n\nThis optimization has a LOW impact on query performance but is still good practice."
        
        return explanation