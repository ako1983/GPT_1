"""
SQL Helper Agent Module

This module implements the SQL Helper Agent, responsible for refining, testing, and optimizing 
SQL queries to ensure accuracy, performance, and adherence to best practices.
"""

import os
import json
import logging
import asyncio
from typing import Dict, List, Any, Optional, Tuple

from ...core.interfaces.agent_interface import Agent, AgentType, ExecutionStatus, Message
from ...core.communication.event_bus import get_event_bus
from ...core.state.state_manager import get_state_manager
from .sql_refiner import SQLRefiner
from .sql_tester import SQLTester
from .sql_optimizer import SQLOptimizer


class SQLHelperAgent(Agent):
    """
    SQL Helper Agent for refining, testing, and optimizing SQL queries.
    
    The SQLHelperAgent:
    1. Refines SQL queries for improved readability and adherence to best practices
    2. Tests SQL queries for correctness and performance
    3. Optimizes SQL queries for better performance
    4. Provides suggestions and explanations for SQL improvements
    5. Validates refined and optimized SQL queries
    """
    
    def __init__(self, agent_id: str, config: Dict[str, Any]):
        """
        Initialize a new SQL Helper agent.
        
        Args:
            agent_id: Unique identifier for this agent
            config: Configuration parameters for this agent
        """
        super().__init__(agent_id, AgentType.SQL_HELPER)
        self._logger = logging.getLogger(__name__)
        self._config = config
        self._initialized = False
        self._event_bus = get_event_bus()
        self._state_manager = get_state_manager()
        
        # Initialize components
        self._refiner = SQLRefiner(config.get("refiner_config", {}))
        self._tester = SQLTester(config.get("tester_config", {}))
        self._optimizer = SQLOptimizer(config.get("optimizer_config", {}))
        
        # Settings
        self._test_queries = config.get("test_queries", True)
        self._optimize_queries = config.get("optimize_queries", True)
        self._dialect = config.get("dialect", "bigquery")
        self._max_iterations = config.get("max_iterations", 3)
        self._schema = config.get("schema", {})
    
    async def initialize(self, config: Dict[str, Any]) -> bool:
        """
        Initialize the agent with configuration parameters.
        
        Args:
            config: Configuration parameters
            
        Returns:
            True if initialization was successful, False otherwise
        """
        try:
            # Update configuration
            self._config.update(config)
            
            # Update settings from new config
            self._test_queries = self._config.get("test_queries", self._test_queries)
            self._optimize_queries = self._config.get("optimize_queries", self._optimize_queries)
            self._dialect = self._config.get("dialect", self._dialect)
            self._max_iterations = self._config.get("max_iterations", self._max_iterations)
            
            # Load schema from file if specified
            schema_file = self._config.get("schema_file")
            if schema_file and os.path.exists(schema_file):
                with open(schema_file, 'r') as f:
                    self._schema = json.load(f)
            
            # Register with the event bus
            self._event_bus.register_agent(AgentType.SQL_HELPER, self.process)
            
            self._initialized = True
            self._logger.info("SQL Helper agent initialized successfully")
            return True
            
        except Exception as e:
            self._logger.error(f"Error initializing SQL Helper agent: {str(e)}")
            return False
    
    async def process(self, message: Message) -> Message:
        """
        Process an incoming message and produce a response.
        
        Args:
            message: The incoming message to process
            
        Returns:
            A response message
        """
        self._logger.info(f"Processing message: {message.message_type}")
        
        # Extract message content
        content = message.content
        
        # Check the message type and dispatch to the appropriate handler
        if message.message_type == "refine_sql":
            sql = content.get("sql")
            query_id = content.get("query_id")
            query_context = content.get("query_context")
            options = content.get("options", {})
            
            if sql:
                result = await self.refine_sql(sql, query_id, query_context, options)
                return Message(
                    sender=AgentType.SQL_HELPER,
                    receiver=message.sender,
                    content=result,
                    message_type="sql_refined",
                    trace_id=message.trace_id
                )
        
        elif message.message_type == "test_sql":
            sql = content.get("sql")
            query_id = content.get("query_id")
            test_options = content.get("test_options", {})
            
            if sql:
                result = await self.test_sql(sql, query_id, test_options)
                return Message(
                    sender=AgentType.SQL_HELPER,
                    receiver=message.sender,
                    content=result,
                    message_type="sql_tested",
                    trace_id=message.trace_id
                )
        
        elif message.message_type == "optimize_sql":
            sql = content.get("sql")
            query_id = content.get("query_id")
            schema_info = content.get("schema_info")
            options = content.get("options", {})
            
            if sql:
                result = await self.optimize_sql(sql, query_id, schema_info, options)
                return Message(
                    sender=AgentType.SQL_HELPER,
                    receiver=message.sender,
                    content=result,
                    message_type="sql_optimized",
                    trace_id=message.trace_id
                )
        
        elif message.message_type == "improve_sql":
            sql = content.get("sql")
            query_id = content.get("query_id")
            query_context = content.get("query_context")
            schema_info = content.get("schema_info")
            options = content.get("options", {})
            
            if sql:
                result = await self.improve_sql(sql, query_id, query_context, schema_info, options)
                return Message(
                    sender=AgentType.SQL_HELPER,
                    receiver=message.sender,
                    content=result,
                    message_type="sql_improved",
                    trace_id=message.trace_id
                )
        
        # Default response for unsupported message types
        return Message(
            sender=AgentType.SQL_HELPER,
            receiver=message.sender,
            content={"error": "Unsupported message type"},
            message_type="error",
            trace_id=message.trace_id
        )
    
    async def refine_sql(self, sql: str, query_id: Optional[str] = None,
                      query_context: Optional[Dict[str, Any]] = None,
                      options: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """
        Refine a SQL query for improved readability and best practices.
        
        Args:
            sql: The SQL query to refine
            query_id: Optional query ID for state tracking
            query_context: Optional query context
            options: Optional refinement options
            
        Returns:
            Dictionary with refined SQL and refinement metadata
        """
        self._logger.info(f"Refining SQL query: {sql}")
        
        try:
            # Update status
            self.status = ExecutionStatus.IN_PROGRESS
            
            # Generate a query ID if not provided
            if not query_id:
                query_id = f"query_{hash(sql) & 0xffffffff}"
            
            # Refine the SQL
            refine_result = self._refiner.refine_sql(sql, query_context)
            refined_sql = refine_result.get("refined_sql", sql)
            improvements = refine_result.get("improvements", [])
            
            # Add query context comment if context is provided
            if query_context and refined_sql:
                refined_sql = self._refiner.add_query_context_comment(refined_sql, query_context)
            
            # Update query state
            self._update_query_state(query_id, "refined_sql", refined_sql)
            
            # Update status
            self.status = ExecutionStatus.COMPLETED
            
            # Return result
            return {
                "query_id": query_id,
                "original_sql": sql,
                "refined_sql": refined_sql,
                "improvements": improvements,
                "success": True
            }
            
        except Exception as e:
            self._logger.error(f"Error refining SQL: {str(e)}")
            self.status = ExecutionStatus.FAILED
            return {
                "query_id": query_id,
                "original_sql": sql,
                "error": str(e),
                "success": False
            }
    
    async def test_sql(self, sql: str, query_id: Optional[str] = None,
                     test_options: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """
        Test a SQL query for correctness and performance.
        
        Args:
            sql: The SQL query to test
            query_id: Optional query ID for state tracking
            test_options: Optional test options
            
        Returns:
            Dictionary with test results
        """
        self._logger.info(f"Testing SQL query: {sql}")
        
        try:
            # Update status
            self.status = ExecutionStatus.IN_PROGRESS
            
            # Generate a query ID if not provided
            if not query_id:
                query_id = f"query_{hash(sql) & 0xffffffff}"
            
            # Test the SQL
            test_result = self._tester.test_sql(sql, test_options)
            
            # Update query state
            self._update_query_state(query_id, "test_result", test_result)
            
            # Update status
            self.status = ExecutionStatus.COMPLETED if test_result.get("success", False) else ExecutionStatus.FAILED
            
            # Return result
            return {
                "query_id": query_id,
                "sql": sql,
                "test_result": test_result,
                "success": test_result.get("success", False)
            }
            
        except Exception as e:
            self._logger.error(f"Error testing SQL: {str(e)}")
            self.status = ExecutionStatus.FAILED
            return {
                "query_id": query_id,
                "sql": sql,
                "error": str(e),
                "success": False
            }
    
    async def optimize_sql(self, sql: str, query_id: Optional[str] = None,
                         schema_info: Optional[Dict[str, Any]] = None,
                         options: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """
        Optimize a SQL query for improved performance.
        
        Args:
            sql: The SQL query to optimize
            query_id: Optional query ID for state tracking
            schema_info: Optional schema information for optimization
            options: Optional optimization options
            
        Returns:
            Dictionary with optimized SQL and optimization metadata
        """
        self._logger.info(f"Optimizing SQL query: {sql}")
        
        try:
            # Update status
            self.status = ExecutionStatus.IN_PROGRESS
            
            # Generate a query ID if not provided
            if not query_id:
                query_id = f"query_{hash(sql) & 0xffffffff}"
            
            # Optimize the SQL
            optimization_result = self._optimizer.optimize_sql(sql, schema_info or self._schema)
            optimized_sql = optimization_result.get("optimized_sql", sql)
            optimizations = optimization_result.get("optimizations", [])
            suggestions = optimization_result.get("suggestions", [])
            
            # Update query state
            self._update_query_state(query_id, "optimized_sql", optimized_sql)
            self._update_query_state(query_id, "optimization_result", optimization_result)
            
            # Update status
            self.status = ExecutionStatus.COMPLETED
            
            # Return result
            return {
                "query_id": query_id,
                "original_sql": sql,
                "optimized_sql": optimized_sql,
                "optimizations": optimizations,
                "suggestions": suggestions,
                "success": True
            }
            
        except Exception as e:
            self._logger.error(f"Error optimizing SQL: {str(e)}")
            self.status = ExecutionStatus.FAILED
            return {
                "query_id": query_id,
                "original_sql": sql,
                "error": str(e),
                "success": False
            }
    
    async def improve_sql(self, sql: str, query_id: Optional[str] = None,
                        query_context: Optional[Dict[str, Any]] = None,
                        schema_info: Optional[Dict[str, Any]] = None,
                        options: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """
        Comprehensively improve a SQL query through refinement, testing, and optimization.
        
        Args:
            sql: The SQL query to improve
            query_id: Optional query ID for state tracking
            query_context: Optional query context
            schema_info: Optional schema information for optimization
            options: Optional improvement options
            
        Returns:
            Dictionary with improved SQL and improvement metadata
        """
        self._logger.info(f"Improving SQL query: {sql}")
        
        try:
            # Update status
            self.status = ExecutionStatus.IN_PROGRESS
            
            # Generate a query ID if not provided
            if not query_id:
                query_id = f"query_{hash(sql) & 0xffffffff}"
            
            # Initialize result
            result = {
                "query_id": query_id,
                "original_sql": sql,
                "improved_sql": sql,
                "improvements": [],
                "success": True,
                "improvement_steps": []
            }
            
            # Step 1: Refine the SQL
            refine_result = await self.refine_sql(sql, query_id, query_context, options)
            if not refine_result.get("success", False):
                # If refinement fails, return the original SQL with error
                self.status = ExecutionStatus.FAILED
                return {
                    **result,
                    "error": refine_result.get("error", "Unknown error during SQL refinement"),
                    "success": False
                }
            
            refined_sql = refine_result.get("refined_sql", sql)
            result["improved_sql"] = refined_sql
            result["improvements"].extend(refine_result.get("improvements", []))
            result["improvement_steps"].append({
                "step": "refine",
                "result": refine_result
            })
            
            # Step 2: Optimize the SQL if enabled
            if self._optimize_queries:
                optimize_result = await self.optimize_sql(refined_sql, query_id, schema_info, options)
                if optimize_result.get("success", False):
                    optimized_sql = optimize_result.get("optimized_sql", refined_sql)
                    result["improved_sql"] = optimized_sql
                    result["improvements"].extend(optimize_result.get("optimizations", []))
                    result["improvement_steps"].append({
                        "step": "optimize",
                        "result": optimize_result
                    })
            
            # Step 3: Test the improved SQL if enabled
            if self._test_queries:
                test_options = options.get("test_options", {})
                test_result = await self.test_sql(result["improved_sql"], query_id, test_options)
                result["improvement_steps"].append({
                    "step": "test",
                    "result": test_result
                })
                
                # Update success based on test result
                if not test_result.get("success", False):
                    result["test_warnings"] = test_result.get("error") or "SQL test did not pass"
            
            # Extract metadata about the final SQL
            if query_context:
                sql_metadata = self._refiner.extract_query_metadata(result["improved_sql"])
                result["sql_metadata"] = sql_metadata
            
            # Update query state
            self._update_query_state(query_id, "improved_sql", result["improved_sql"])
            
            # Update status
            self.status = ExecutionStatus.COMPLETED
            
            return result
            
        except Exception as e:
            self._logger.error(f"Error improving SQL: {str(e)}")
            self.status = ExecutionStatus.FAILED
            return {
                "query_id": query_id,
                "original_sql": sql,
                "error": str(e),
                "success": False
            }
    
    def _update_query_state(self, query_id: str, key: str, value: Any) -> None:
        """
        Update the query state with a key-value pair.
        
        Args:
            query_id: The query ID
            key: The key to update
            value: The value to set
        """
        # Get the query state
        query_state = self._state_manager.get_query_state(query_id)
        
        # If no existing state, create one
        if not query_state:
            self._state_manager.create_query_state(query_id, {
                "timestamp": asyncio.get_event_loop().time()
            })
            query_state = self._state_manager.get_query_state(query_id)
        
        # Update the state
        self._state_manager.update_query_state(query_id, {key: value})
    
    def get_capabilities(self) -> List[str]:
        """
        Return a list of capabilities this agent provides.
        
        Returns:
            List of capability strings
        """
        return [
            "sql_refinement",
            "sql_testing",
            "sql_optimization",
            "sql_improvement",
            "performance_analysis"
        ]
    
    def get_status(self) -> Dict[str, Any]:
        """
        Get the current status of this agent.
        
        Returns:
            A dictionary with status information
        """
        return {
            "agent_id": self.agent_id,
            "agent_type": self.agent_type,
            "status": self.status,
            "initialized": self._initialized,
            "test_queries": self._test_queries,
            "optimize_queries": self._optimize_queries,
            "dialect": self._dialect
        }
    
    async def shutdown(self) -> bool:
        """
        Perform cleanup when shutting down the agent.
        
        Returns:
            True if shutdown was successful, False otherwise
        """
        try:
            # Unregister from the event bus
            self._event_bus.unregister_agent(AgentType.SQL_HELPER)
            
            return True
            
        except Exception as e:
            self._logger.error(f"Error shutting down SQL Helper agent: {str(e)}")
            return False