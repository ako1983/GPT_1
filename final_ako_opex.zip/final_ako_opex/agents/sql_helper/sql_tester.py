"""
SQL Tester Module

This module tests SQL queries for correctness and performance by executing them
against a test database or using dry-run features of the database.
"""

import logging
import time
from typing import Dict, List, Any, Optional, Union, Tuple
import sqlite3
from google.cloud import bigquery
from google.cloud.exceptions import BadRequest


class SQLTester:
    """
    Tests SQL queries for correctness and performance.
    
    The SQLTester:
    1. Validates SQL queries by executing them in a safe manner
    2. Measures performance characteristics of queries
    3. Collects and analyzes query execution metrics
    4. Identifies potential issues with query execution
    5. Provides alternative execution plans for comparison
    """
    
    def __init__(self, config: Dict[str, Any] = None):
        """
        Initialize a new SQL tester.
        
        Args:
            config: Configuration parameters
        """
        self._logger = logging.getLogger(__name__)
        self._config = config or {}
        
        # Tester settings
        self._dialect = self._config.get("dialect", "bigquery")
        self._test_mode = self._config.get("test_mode", "dry_run")  # or "mock_db"
        self._timeout = self._config.get("timeout", 30)  # seconds
        self._max_rows = self._config.get("max_rows", 10)  # for preview
        
        # Initialize the appropriate database client based on dialect
        self._initialize_client()
    
    def _initialize_client(self) -> None:
        """
        Initialize the appropriate database client based on dialect.
        """
        if self._dialect == "bigquery":
            # Initialize BigQuery client if credentials are provided
            credentials_file = self._config.get("bigquery_credentials")
            project_id = self._config.get("bigquery_project")
            
            if credentials_file:
                import os
                os.environ["GOOGLE_APPLICATION_CREDENTIALS"] = credentials_file
            
            if project_id:
                self._client = bigquery.Client(project=project_id)
            else:
                # Initialize without explicit project, using credentials
                self._client = bigquery.Client()
                
        elif self._dialect == "sqlite" or self._test_mode == "mock_db":
            # Initialize SQLite connection
            db_path = self._config.get("sqlite_db_path", ":memory:")
            self._connection = sqlite3.connect(db_path)
            self._cursor = self._connection.cursor()
            
            # Create test tables if needed
            if self._test_mode == "mock_db" and db_path == ":memory:":
                self._create_mock_tables()
    
    def _create_mock_tables(self) -> None:
        """
        Create mock tables for testing SQLite queries.
        """
        # Create OPEX budget table
        self._cursor.execute("""
        CREATE TABLE IF NOT EXISTS pypl_opex_bau (
            id INTEGER PRIMARY KEY,
            budget_amt REAL,
            actual_amt REAL,
            forecast_amt REAL,
            fiscal_year TEXT,
            fiscal_quarter TEXT,
            fiscal_month TEXT,
            bu_level_1_desc TEXT,
            bu_level_2_desc TEXT,
            bu_level_3_desc TEXT,
            cost_center_id TEXT,
            cost_center_name TEXT,
            expense_category TEXT,
            expense_subcategory TEXT
        )
        """)
        
        # Create headcount table
        self._cursor.execute("""
        CREATE TABLE IF NOT EXISTS rpt_hdcnt_bdgt_view (
            id INTEGER PRIMARY KEY,
            headcount INTEGER,
            fiscal_year TEXT,
            fiscal_quarter TEXT,
            fiscal_month TEXT,
            bu_level_1_desc TEXT,
            bu_level_2_desc TEXT,
            bu_level_3_desc TEXT,
            cost_center_id TEXT
        )
        """)
        
        # Insert sample data for OPEX table
        self._cursor.execute("""
        INSERT INTO pypl_opex_bau 
        (budget_amt, actual_amt, forecast_amt, fiscal_year, fiscal_quarter, fiscal_month, 
         bu_level_1_desc, bu_level_2_desc, bu_level_3_desc, cost_center_id)
        VALUES
        (100000, 95000, 98000, '2023', 'Q1_2023', '2023-01', 'Technology', 'Engineering', 'CTO', 'CC001'),
        (150000, 145000, 148000, '2023', 'Q1_2023', '2023-02', 'Technology', 'Engineering', 'CTO', 'CC001'),
        (120000, 125000, 122000, '2023', 'Q1_2023', '2023-03', 'Technology', 'Engineering', 'CTO', 'CC001'),
        (90000, 88000, 89000, '2023', 'Q1_2023', '2023-01', 'Finance', 'Accounting', 'Finance', 'CC002'),
        (95000, 97000, 96000, '2023', 'Q1_2023', '2023-02', 'Finance', 'Accounting', 'Finance', 'CC002'),
        (100000, 102000, 101000, '2023', 'Q1_2023', '2023-03', 'Finance', 'Accounting', 'Finance', 'CC002')
        """)
        
        # Insert sample data for headcount table
        self._cursor.execute("""
        INSERT INTO rpt_hdcnt_bdgt_view
        (headcount, fiscal_year, fiscal_quarter, fiscal_month, 
         bu_level_1_desc, bu_level_2_desc, bu_level_3_desc, cost_center_id)
        VALUES
        (50, '2023', 'Q1_2023', '2023-01', 'Technology', 'Engineering', 'CTO', 'CC001'),
        (52, '2023', 'Q1_2023', '2023-02', 'Technology', 'Engineering', 'CTO', 'CC001'),
        (54, '2023', 'Q1_2023', '2023-03', 'Technology', 'Engineering', 'CTO', 'CC001'),
        (25, '2023', 'Q1_2023', '2023-01', 'Finance', 'Accounting', 'Finance', 'CC002'),
        (26, '2023', 'Q1_2023', '2023-02', 'Finance', 'Accounting', 'Finance', 'CC002'),
        (26, '2023', 'Q1_2023', '2023-03', 'Finance', 'Accounting', 'Finance', 'CC002')
        """)
        
        self._connection.commit()
        self._logger.info("Created mock tables for SQLite testing")
    
    def test_sql(self, sql: str, test_options: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """
        Test a SQL query for correctness and performance.
        
        Args:
            sql: The SQL query to test
            test_options: Optional test configuration options
            
        Returns:
            Dictionary with test results
        """
        self._logger.debug(f"Testing SQL: {sql}")
        
        # Get test options
        test_options = test_options or {}
        test_mode = test_options.get("test_mode", self._test_mode)
        timeout = test_options.get("timeout", self._timeout)
        max_rows = test_options.get("max_rows", self._max_rows)
        
        try:
            # Initialize result
            result = {
                "success": False,
                "execution_time": 0,
                "preview_rows": [],
                "row_count": 0,
                "processed_bytes": None,
                "error": None,
                "warnings": []
            }
            
            # Choose the appropriate test method based on dialect and mode
            if self._dialect == "bigquery":
                if test_mode == "dry_run":
                    result.update(self._test_bigquery_dry_run(sql))
                else:
                    result.update(self._test_bigquery_execution(sql, max_rows, timeout))
            
            elif self._dialect == "sqlite":
                result.update(self._test_sqlite(sql, max_rows, timeout))
            
            return result
            
        except Exception as e:
            self._logger.error(f"Error testing SQL: {str(e)}")
            return {
                "success": False,
                "error": str(e),
                "execution_time": 0,
                "preview_rows": [],
                "row_count": 0
            }
    
    def _test_bigquery_dry_run(self, sql: str) -> Dict[str, Any]:
        """
        Test a SQL query using BigQuery's dry run feature.
        
        Args:
            sql: The SQL query to test
            
        Returns:
            Dictionary with test results
        """
        result = {
            "success": False,
            "execution_mode": "dry_run"
        }
        
        try:
            # Create job config for dry run
            job_config = bigquery.QueryJobConfig(dry_run=True, use_query_cache=False)
            
            # Start timer
            start_time = time.time()
            
            # Execute dry run
            query_job = self._client.query(sql, job_config=job_config)
            
            # Stop timer
            end_time = time.time()
            
            # Update result
            result["success"] = True
            result["execution_time"] = end_time - start_time
            result["processed_bytes"] = query_job.total_bytes_processed
            result["estimated_cost"] = self._estimate_bigquery_cost(query_job.total_bytes_processed)
            
            return result
            
        except BadRequest as e:
            # Bad request usually means a syntax or schema error
            result["error"] = str(e)
            return result
            
        except Exception as e:
            # Other errors
            result["error"] = f"Error during BigQuery dry run: {str(e)}"
            return result
    
    def _test_bigquery_execution(self, sql: str, max_rows: int, timeout: int) -> Dict[str, Any]:
        """
        Test a SQL query by executing it on BigQuery.
        
        Args:
            sql: The SQL query to test
            max_rows: Maximum number of rows to return
            timeout: Timeout in seconds
            
        Returns:
            Dictionary with test results
        """
        result = {
            "success": False,
            "execution_mode": "execution"
        }
        
        try:
            # Add LIMIT clause if not present to avoid large result sets
            if "LIMIT" not in sql.upper():
                sql = f"{sql} LIMIT {max_rows}"
            
            # Create job config
            job_config = bigquery.QueryJobConfig(use_query_cache=True)
            
            # Start timer
            start_time = time.time()
            
            # Execute query
            query_job = self._client.query(sql, job_config=job_config)
            
            # Wait for the query to complete with timeout
            rows = list(query_job.result(timeout=timeout))
            
            # Stop timer
            end_time = time.time()
            
            # Get column names
            column_names = [field.name for field in query_job.schema]
            
            # Format preview rows
            preview_rows = []
            for row in rows:
                preview_rows.append({column: row[column] for column in column_names})
            
            # Update result
            result["success"] = True
            result["execution_time"] = end_time - start_time
            result["preview_rows"] = preview_rows[:max_rows]
            result["row_count"] = query_job.total_rows
            result["processed_bytes"] = query_job.total_bytes_processed
            result["estimated_cost"] = self._estimate_bigquery_cost(query_job.total_bytes_processed)
            
            return result
            
        except BadRequest as e:
            # Bad request usually means a syntax or schema error
            result["error"] = str(e)
            return result
            
        except Exception as e:
            # Other errors
            result["error"] = f"Error executing BigQuery query: {str(e)}"
            return result
    
    def _test_sqlite(self, sql: str, max_rows: int, timeout: int) -> Dict[str, Any]:
        """
        Test a SQL query using SQLite.
        
        Args:
            sql: The SQL query to test
            max_rows: Maximum number of rows to return
            timeout: Timeout in seconds
            
        Returns:
            Dictionary with test results
        """
        result = {
            "success": False,
            "execution_mode": "sqlite"
        }
        
        try:
            # Adapt SQL for SQLite if needed
            sqlite_sql = self._adapt_sql_for_sqlite(sql)
            
            # Set timeout
            self._connection.execute(f"PRAGMA busy_timeout = {timeout * 1000}")
            
            # Start timer
            start_time = time.time()
            
            # Execute query
            self._cursor.execute(sqlite_sql)
            
            # Fetch results
            rows = self._cursor.fetchmany(max_rows)
            
            # Stop timer
            end_time = time.time()
            
            # Get column names
            column_names = [description[0] for description in self._cursor.description]
            
            # Format preview rows
            preview_rows = []
            for row in rows:
                preview_rows.append({column_names[i]: row[i] for i in range(len(column_names))})
            
            # Update result
            result["success"] = True
            result["execution_time"] = end_time - start_time
            result["preview_rows"] = preview_rows
            result["row_count"] = len(rows)
            
            return result
            
        except sqlite3.OperationalError as e:
            # Operational error usually means a syntax or schema error
            result["error"] = str(e)
            return result
            
        except Exception as e:
            # Other errors
            result["error"] = f"Error executing SQLite query: {str(e)}"
            return result
    
    def _adapt_sql_for_sqlite(self, sql: str) -> str:
        """
        Adapt BigQuery SQL to SQLite syntax for testing.
        
        Args:
            sql: The BigQuery SQL query
            
        Returns:
            SQLite-compatible SQL query
        """
        # Replace BigQuery-specific functions with SQLite equivalents
        replacements = [
            (r'TIMESTAMP\([^)]+\)', 'DATETIME'),
            (r'ARRAY\([^)]+\)', 'JSON'),
            (r'STRUCT\([^)]+\)', 'JSON'),
            (r'DATE\([^)]+\)', 'DATE'),
            (r'DATETIME\([^)]+\)', 'DATETIME'),
            (r'UNNEST\([^)]+\)', 'JSON_EACH'),
            (r'INT64', 'INTEGER'),
            (r'FLOAT64', 'REAL'),
            (r'BOOL', 'INTEGER'),
            (r'STRING', 'TEXT')
        ]
        
        sqlite_sql = sql
        for pattern, replacement in replacements:
            sqlite_sql = re.sub(pattern, replacement, sqlite_sql, flags=re.IGNORECASE)
        
        return sqlite_sql
    
    def _estimate_bigquery_cost(self, bytes_processed: Optional[int]) -> Optional[float]:
        """
        Estimate BigQuery cost based on bytes processed.
        
        Args:
            bytes_processed: Bytes processed by the query
            
        Returns:
            Estimated cost in USD
        """
        if bytes_processed is None:
            return None
        
        # Current BigQuery pricing is $5 per TB
        # 1 TB = 1,099,511,627,776 bytes
        cost_per_tb = 5.0
        tb = bytes_processed / 1099511627776.0
        
        return tb * cost_per_tb
    
    def get_query_statistics(self, sql: str) -> Dict[str, Any]:
        """
        Get statistics about a SQL query without executing it.
        
        Args:
            sql: The SQL query to analyze
            
        Returns:
            Dictionary with query statistics
        """
        stats = {
            "estimated_bytes": None,
            "estimated_cost": None,
            "tables_referenced": [],
            "columns_referenced": []
        }
        
        try:
            if self._dialect == "bigquery":
                # Get statistics using dry run
                job_config = bigquery.QueryJobConfig(dry_run=True, use_query_cache=False)
                query_job = self._client.query(sql, job_config=job_config)
                
                stats["estimated_bytes"] = query_job.total_bytes_processed
                stats["estimated_cost"] = self._estimate_bigquery_cost(query_job.total_bytes_processed)
                
                # Extract referenced tables and columns if available
                if hasattr(query_job, "referenced_tables"):
                    stats["tables_referenced"] = [f"{table.project}.{table.dataset_id}.{table.table_id}" 
                                              for table in query_job.referenced_tables]
            
            return stats
            
        except Exception as e:
            self._logger.error(f"Error getting query statistics: {str(e)}")
            return stats