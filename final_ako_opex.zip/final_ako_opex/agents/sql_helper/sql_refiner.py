"""
SQL Refiner Module

This module refines SQL queries for improved accuracy, readability, and adherence
to best practices.
"""

import logging
import re
from typing import Dict, List, Any, Optional, Tuple
import sqlparse
from sqlparse.sql import Token, TokenList, Identifier, IdentifierList, Parenthesis, Where, Function
from sqlparse.tokens import Keyword, DML, Name, Whitespace


class SQLRefiner:
    """
    Refines SQL queries for improved accuracy and readability.
    
    The SQLRefiner:
    1. Enhances SQL query structure for readability
    2. Applies consistent formatting and style
    3. Standardizes SQL patterns for better maintainability
    4. Adds descriptive comments when helpful
    5. Implements SQL best practices for the specific dialect
    """
    
    def __init__(self, config: Dict[str, Any] = None):
        """
        Initialize a new SQL refiner.
        
        Args:
            config: Configuration parameters
        """
        self._logger = logging.getLogger(__name__)
        self._config = config or {}
        
        # Refinement settings
        self._dialect = self._config.get("dialect", "bigquery")
        self._max_line_length = self._config.get("max_line_length", 80)
        self._indent_size = self._config.get("indent_size", 4)
        self._comma_style = self._config.get("comma_style", "trailing")  # or "leading"
        self._keyword_case = self._config.get("keyword_case", "upper")  # or "lower"
        self._identifier_case = self._config.get("identifier_case", "preserve")  # or "lower", "upper"
        
        # Load patterns for improvements
        self._improvement_patterns = self._load_improvement_patterns()
    
    def _load_improvement_patterns(self) -> Dict[str, List[Dict[str, Any]]]:
        """
        Load patterns for SQL improvements based on the dialect.
        
        Returns:
            Dictionary of improvement patterns
        """
        # Default patterns
        patterns = {
            "readability": [],
            "performance": [],
            "best_practices": []
        }
        
        # Add dialect-specific patterns
        if self._dialect == "bigquery":
            patterns["readability"].extend([
                {
                    "description": "Use table aliases for readability",
                    "pattern": r"FROM\s+(\w+)(?!\s+AS\s+\w+|\s+\w+\s)",
                    "replacement": r"FROM \1 AS \1_alias",
                    "condition": lambda sql: " JOIN " in sql
                },
                {
                    "description": "Add newlines after each column in SELECT",
                    "pattern": r"SELECT\s+(.*?)\s+FROM",
                    "replacement": self._format_select_columns,
                    "is_function": True
                }
            ])
            
            patterns["performance"].extend([
                {
                    "description": "Add LIMIT clause if missing",
                    "pattern": r"(?i)^(SELECT.*?)(?!\sLIMIT\s+\d+)$",
                    "replacement": r"\1 LIMIT 1000",
                    "condition": lambda sql: "LIMIT" not in sql.upper()
                }
            ])
            
            patterns["best_practices"].extend([
                {
                    "description": "Use explicit column names instead of *",
                    "pattern": r"SELECT\s+\*\s+FROM",
                    "replacement": r"SELECT /* Consider specifying explicit columns */ * FROM",
                    "is_comment": True
                },
                {
                    "description": "Add explicit join condition if missing",
                    "pattern": r"(JOIN\s+\w+)(?!\s+ON)",
                    "replacement": r"\1 /* Add ON condition */",
                    "condition": lambda sql: " JOIN " in sql and " ON " not in sql,
                    "is_comment": True
                }
            ])
        
        return patterns
    
    def refine_sql(self, sql: str, query_context: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """
        Refine a SQL query for improved accuracy and readability.
        
        Args:
            sql: The SQL query to refine
            query_context: Optional query context for more targeted refinements
            
        Returns:
            Dictionary with refined SQL and refinement metadata
        """
        self._logger.debug(f"Refining SQL: {sql}")
        
        try:
            # Initialize result
            result = {
                "original_sql": sql,
                "refined_sql": sql,
                "improvements": [],
                "warnings": []
            }
            
            # Parse the SQL query
            parsed = sqlparse.parse(sql)
            if not parsed:
                result["warnings"].append({
                    "type": "parse_error",
                    "message": "Failed to parse SQL query"
                })
                return result
            
            stmt = parsed[0]
            
            # Apply formatting improvements
            formatted_sql = self._format_sql(sql)
            
            # Apply dialect-specific improvements
            improved_sql, improvements = self._apply_improvements(formatted_sql, query_context)
            
            # Update the result
            result["refined_sql"] = improved_sql
            result["improvements"] = improvements
            
            return result
            
        except Exception as e:
            self._logger.error(f"Error refining SQL: {str(e)}")
            return {
                "original_sql": sql,
                "refined_sql": sql,
                "error": str(e),
                "improvements": [],
                "warnings": [{"type": "error", "message": str(e)}]
            }
    
    def _format_sql(self, sql: str) -> str:
        """
        Format a SQL query for readability.
        
        Args:
            sql: The SQL query to format
            
        Returns:
            Formatted SQL query
        """
        try:
            # Use sqlparse for basic formatting
            formatted = sqlparse.format(
                sql,
                keyword_case="upper" if self._keyword_case == "upper" else "lower",
                identifier_case="preserve",
                reindent=True,
                indent_width=self._indent_size
            )
            
            # Additional formatting based on comma style
            if self._comma_style == "leading":
                formatted = self._convert_to_leading_commas(formatted)
            
            return formatted
            
        except Exception as e:
            self._logger.warning(f"Error formatting SQL: {str(e)}")
            return sql
    
    def _convert_to_leading_commas(self, sql: str) -> str:
        """
        Convert comma-separated lists to use leading commas.
        
        Args:
            sql: The SQL query to convert
            
        Returns:
            SQL query with leading commas
        """
        # Convert trailing commas to leading commas in SELECT clause
        lines = sql.split('\n')
        in_select = False
        result = []
        
        for line in lines:
            stripped = line.strip()
            
            if stripped.upper().startswith('SELECT'):
                in_select = True
                result.append(line)
            elif in_select and (stripped.upper().startswith('FROM') or stripped.upper().startswith('WHERE')):
                in_select = False
                result.append(line)
            elif in_select and stripped.endswith(','):
                # Replace trailing comma with leading comma for next line
                result.append(line[:-1])
            elif in_select and result and not result[-1].endswith(','):
                # Add leading comma to this line
                indent = len(line) - len(line.lstrip())
                result.append(' ' * indent + ', ' + stripped)
            else:
                result.append(line)
        
        return '\n'.join(result)
    
    def _format_select_columns(self, match) -> str:
        """
        Format columns in SELECT clause for readability.
        
        Args:
            match: Regex match object
            
        Returns:
            Formatted SELECT clause
        """
        select_part = match.group(1)
        
        # If already has newlines, don't modify
        if '\n' in select_part:
            return f"SELECT {select_part} FROM"
        
        # Split columns by commas, but respect parentheses
        columns = []
        current_col = ""
        paren_level = 0
        
        for char in select_part:
            if char == '(':
                paren_level += 1
                current_col += char
            elif char == ')':
                paren_level -= 1
                current_col += char
            elif char == ',' and paren_level == 0:
                columns.append(current_col.strip())
                current_col = ""
            else:
                current_col += char
        
        if current_col.strip():
            columns.append(current_col.strip())
        
        # Format with newlines and indentation
        indent = ' ' * (self._indent_size + 2)  # 2 spaces after SELECT
        formatted_cols = ",\n" + indent + ("\n" + indent).join(columns)
        
        return f"SELECT{formatted_cols}\nFROM"
    
    def _apply_improvements(self, sql: str, query_context: Optional[Dict[str, Any]] = None) -> Tuple[str, List[Dict[str, Any]]]:
        """
        Apply improvement patterns to the SQL query.
        
        Args:
            sql: The SQL query to improve
            query_context: Optional query context
            
        Returns:
            Tuple of (improved SQL, list of improvements)
        """
        improved_sql = sql
        improvements = []
        
        # Apply readability improvements
        for pattern in self._improvement_patterns["readability"]:
            if "condition" in pattern and not pattern["condition"](sql):
                continue
                
            if pattern.get("is_function"):
                # Use function replacement
                replacement_func = pattern["replacement"]
                new_sql = re.sub(pattern["pattern"], replacement_func, improved_sql, flags=re.IGNORECASE | re.DOTALL)
            else:
                # Use string replacement
                new_sql = re.sub(pattern["pattern"], pattern["replacement"], improved_sql, flags=re.IGNORECASE | re.DOTALL)
            
            if new_sql != improved_sql:
                improved_sql = new_sql
                if not pattern.get("is_comment"):
                    improvements.append({
                        "type": "readability",
                        "description": pattern["description"]
                    })
        
        # Apply performance improvements
        for pattern in self._improvement_patterns["performance"]:
            if "condition" in pattern and not pattern["condition"](sql):
                continue
                
            new_sql = re.sub(pattern["pattern"], pattern["replacement"], improved_sql, flags=re.IGNORECASE | re.DOTALL)
            
            if new_sql != improved_sql:
                improved_sql = new_sql
                if not pattern.get("is_comment"):
                    improvements.append({
                        "type": "performance",
                        "description": pattern["description"]
                    })
        
        # Apply best practices improvements
        for pattern in self._improvement_patterns["best_practices"]:
            if "condition" in pattern and not pattern["condition"](sql):
                continue
                
            new_sql = re.sub(pattern["pattern"], pattern["replacement"], improved_sql, flags=re.IGNORECASE | re.DOTALL)
            
            if new_sql != improved_sql:
                improved_sql = new_sql
                if not pattern.get("is_comment"):
                    improvements.append({
                        "type": "best_practice",
                        "description": pattern["description"]
                    })
        
        return improved_sql, improvements
    
    def add_query_context_comment(self, sql: str, query_context: Dict[str, Any]) -> str:
        """
        Add a comment with query context information.
        
        Args:
            sql: The SQL query to annotate
            query_context: The query context
            
        Returns:
            SQL query with added context comment
        """
        # Extract relevant information from query context
        intent = query_context.get("intent", "")
        time_period = query_context.get("time_period", [])
        metrics = query_context.get("metrics", [])
        business_units = query_context.get("business_units", [])
        
        # Format the comment
        comment = "/*\n"
        comment += f" * Query Intent: {intent}\n"
        
        if time_period:
            comment += f" * Time Period: {', '.join(time_period)}\n"
        
        if metrics:
            comment += f" * Metrics: {', '.join(metrics)}\n"
        
        if business_units:
            comment += f" * Business Units: {', '.join(business_units)}\n"
        
        comment += " */\n\n"
        
        return comment + sql
    
    def extract_query_metadata(self, sql: str) -> Dict[str, Any]:
        """
        Extract metadata from a SQL query.
        
        Args:
            sql: The SQL query to analyze
            
        Returns:
            Dictionary with query metadata
        """
        metadata = {
            "tables": [],
            "columns": [],
            "conditions": [],
            "aggregations": [],
            "joins": [],
            "query_type": None
        }
        
        try:
            # Parse the SQL query
            parsed = sqlparse.parse(sql)
            if not parsed:
                return metadata
            
            stmt = parsed[0]
            
            # Determine query type
            if stmt.get_type() == "SELECT":
                metadata["query_type"] = "SELECT"
            
            # Extract tables, columns, and other components
            self._extract_statement_components(stmt, metadata)
            
            return metadata
            
        except Exception as e:
            self._logger.error(f"Error extracting query metadata: {str(e)}")
            return metadata
    
    def _extract_statement_components(self, stmt: TokenList, metadata: Dict[str, Any]) -> None:
        """
        Extract components from a SQL statement.
        
        Args:
            stmt: The SQL statement to analyze
            metadata: The metadata dictionary to update
        """
        # Extract FROM clause to identify tables
        from_seen = False
        current_token_type = None
        
        for token in stmt.tokens:
            # Track current clause
            if token.is_keyword:
                token_upper = token.value.upper()
                if token_upper in ("SELECT", "FROM", "WHERE", "JOIN", "GROUP", "ORDER", "HAVING", "LIMIT"):
                    current_token_type = token_upper
                    if token_upper == "FROM":
                        from_seen = True
            
            # Extract tables from FROM clause
            if from_seen and current_token_type == "FROM" and token.ttype is None:
                if isinstance(token, Identifier):
                    metadata["tables"].append(token.get_real_name())
                elif isinstance(token, IdentifierList):
                    for identifier in token.get_identifiers():
                        metadata["tables"].append(identifier.get_real_name())
            
            # Extract columns from SELECT clause
            if current_token_type == "SELECT" and token.ttype is None:
                if isinstance(token, IdentifierList):
                    for identifier in token.get_identifiers():
                        if isinstance(identifier, Function):
                            # This is an aggregation function
                            metadata["aggregations"].append(identifier.value)
                        else:
                            # Regular column
                            column_name = identifier.get_real_name()
                            if column_name:
                                metadata["columns"].append(column_name)
                elif isinstance(token, Identifier):
                    metadata["columns"].append(token.get_real_name())
                elif isinstance(token, Function):
                    metadata["aggregations"].append(token.value)
            
            # Extract joins
            if "JOIN" in str(token).upper():
                if isinstance(token, TokenList):
                    for subtoken in token.tokens:
                        if isinstance(subtoken, Identifier):
                            metadata["joins"].append({
                                "table": subtoken.get_real_name()
                            })
            
            # Extract WHERE conditions
            if isinstance(token, Where):
                metadata["conditions"].append(str(token)[6:])  # Remove "WHERE " prefix