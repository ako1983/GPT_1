# SQL Helper Agent

The SQL Helper Agent is responsible for refining, testing, and optimizing SQL queries to ensure accuracy, performance, and adherence to best practices. It serves as a post-processing layer after SQL generation to improve query quality before execution.

## Overview

The SQL Helper Agent combines three primary components:

1. **SQL Refiner**: Improves SQL readability, applies consistent formatting, and implements SQL best practices
2. **SQL Tester**: Tests SQL queries for correctness and performance by executing them in a safe manner
3. **SQL Optimizer**: Identifies potential performance bottlenecks and suggests query optimizations

## Key Features

- Comprehensive SQL refinement for improved readability and maintainability
- Query testing with performance metrics and validation
- SQL optimization with detailed suggestions and explanations
- Multi-step improvement workflow that combines refinement, testing, and optimization
- Configurable behavior to adapt to different requirements and environments
- Detailed reporting of improvements and suggestions

## Components

### SQL Refiner

The SQL Refiner component enhances SQL queries by:

- Improving query structure and readability
- Applying consistent formatting and style
- Standardizing SQL patterns for maintainability
- Adding descriptive comments when helpful
- Implementing SQL dialect-specific best practices

### SQL Tester

The SQL Tester component validates SQL queries by:

- Executing queries in a safe manner (dry-run or test database)
- Measuring performance characteristics
- Collecting and analyzing query execution metrics
- Identifying potential issues with query execution
- Providing sample result sets for verification

### SQL Optimizer

The SQL Optimizer component improves SQL performance by:

- Identifying potential performance bottlenecks
- Suggesting query optimizations based on established patterns
- Providing alternatives for poorly performing queries
- Analyzing query structure for optimization opportunities
- Explaining optimization rationale for educational purposes

## Usage

The SQL Helper Agent can be used to process SQL queries in several ways:

### Refine SQL Query

Improves SQL query readability and structure:

```python
# Example: Refine a SQL query
result = await sql_helper_agent.refine_sql(
    sql="SELECT * FROM users WHERE status = 'active'",
    query_context={"intent": "retrieval", "entities": ["users", "status"]}
)
```

### Test SQL Query

Tests a SQL query for correctness and performance:

```python
# Example: Test a SQL query
result = await sql_helper_agent.test_sql(
    sql="SELECT COUNT(*) FROM large_table WHERE created_at > '2023-01-01'",
    test_options={"test_mode": "dry_run"}
)
```

### Optimize SQL Query

Optimizes a SQL query for better performance:

```python
# Example: Optimize a SQL query
result = await sql_helper_agent.optimize_sql(
    sql="SELECT * FROM orders JOIN order_items ON orders.id = order_items.order_id",
    schema_info=schema_info
)
```

### Improve SQL Query (Comprehensive)

Applies refinement, testing, and optimization in a single operation:

```python
# Example: Comprehensively improve a SQL query
result = await sql_helper_agent.improve_sql(
    sql="SELECT * FROM users JOIN orders ON users.id = orders.user_id WHERE status = 'completed'",
    query_context={"intent": "aggregation"},
    schema_info=schema_info
)
```

## Configuration

The SQL Helper Agent can be configured through a JSON configuration file:

```json
{
  "agent_id": "sql_helper_agent_1",
  "dialect": "bigquery",
  "test_queries": true,
  "optimize_queries": true,
  "max_iterations": 3,
  
  "refiner_config": {
    "dialect": "bigquery",
    "max_line_length": 80,
    "indent_size": 4,
    "comma_style": "trailing",
    "keyword_case": "upper"
  },
  
  "tester_config": {
    "dialect": "bigquery",
    "test_mode": "dry_run",
    "timeout": 30,
    "max_rows": 10
  },
  
  "optimizer_config": {
    "dialect": "bigquery",
    "aggressive_optimization": false
  }
}
```

### Configuration Options

#### Top Level Options

| Option | Description | Default |
| --- | --- | --- |
| `agent_id` | Unique identifier for this agent | `"sql_helper_agent_1"` |
| `dialect` | SQL dialect to use (e.g., "bigquery", "sqlite") | `"bigquery"` |
| `test_queries` | Whether to test queries during the improvement workflow | `true` |
| `optimize_queries` | Whether to optimize queries during the improvement workflow | `true` |
| `max_iterations` | Maximum number of improvement iterations | `3` |

#### SQL Refiner Options

| Option | Description | Default |
| --- | --- | --- |
| `max_line_length` | Maximum line length for formatted SQL | `80` |
| `indent_size` | Number of spaces for indentation | `4` |
| `comma_style` | Comma placement style ("trailing" or "leading") | `"trailing"` |
| `keyword_case` | Case for SQL keywords ("upper" or "lower") | `"upper"` |
| `identifier_case` | Case for identifiers ("preserve", "upper", "lower") | `"preserve"` |

#### SQL Tester Options

| Option | Description | Default |
| --- | --- | --- |
| `test_mode` | Testing mode ("dry_run" or "mock_db") | `"dry_run"` |
| `timeout` | Timeout in seconds for query execution | `30` |
| `max_rows` | Maximum number of rows to return in preview | `10` |
| `bigquery_credentials` | Path to BigQuery credentials file | `null` |
| `bigquery_project` | BigQuery project ID | `null` |

#### SQL Optimizer Options

| Option | Description | Default |
| --- | --- | --- |
| `aggressive_optimization` | Whether to apply aggressive optimizations | `false` |

## Event-Based Communication

The SQL Helper Agent interacts with other components through these event types:

### Subscriptions (Incoming Events)

- `refine_sql`: Request to refine a SQL query
- `test_sql`: Request to test a SQL query
- `optimize_sql`: Request to optimize a SQL query
- `improve_sql`: Request to comprehensively improve a SQL query

### Publications (Outgoing Events)

- `sql_refined`: Response with refined SQL query
- `sql_tested`: Response with SQL test results
- `sql_optimized`: Response with optimized SQL query
- `sql_improved`: Response with comprehensively improved SQL query

## Integration with Other Agents

The SQL Helper Agent is designed to work closely with these other agents:

- **SQL Agent**: Generates initial SQL queries that the SQL Helper Agent refines
- **Response Agent**: Presents the improved SQL and its results to the user
- **State Manager**: Tracks query state throughout the improvement process

## Examples

### Example 1: Simple Query Refinement

```python
# Initial poorly formatted query
sql = "SELECT * from users where status='active' and created_at>'2023-01-01'"

# Refined query result
refined_sql = """
/*
 * Query Intent: retrieval
 * Business Units: Users
 */

SELECT
    *
FROM
    users
WHERE
    status = 'active'
    AND created_at > '2023-01-01'
"""
```

### Example 2: Query Optimization

```python
# Initial query with potential performance issues
sql = "SELECT * FROM orders JOIN order_items ON orders.id = order_items.order_id"

# Optimized query result
optimized_sql = """
SELECT
    o.*,
    oi.*
FROM
    orders AS o
    JOIN order_items AS oi ON o.id = oi.order_id
WHERE
    o.created_at > '2023-01-01'
LIMIT 1000
"""
```

## Error Handling

The SQL Helper Agent implements robust error handling to ensure that SQL processing failures don't disrupt the entire workflow:

- Parsing errors during refinement are captured and reported
- Test execution errors provide detailed error messages
- Optimization failures fall back to the original SQL
- All processing steps are independent, allowing partial improvements when some steps fail