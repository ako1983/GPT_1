"""
Metadata Agent Package

This package implements the Metadata Agent, responsible for analyzing database schemas,
understanding data relationships, and providing comprehensive metadata to other agents.

Components:
- SchemaAnalyzer: Analyzes database schemas to extract metadata
- BusinessTermMapper: Maps business terms to database elements
- MetadataAgent: Main agent implementation that orchestrates metadata processes
"""

from .metadata_agent import MetadataAgent
from .schema_analyzer import SchemaAnalyzer
from .business_term_mapper import BusinessTermMapper