"""
Schema Analyzer Module

This module is responsible for analyzing database schemas, extracting metadata,
and building a comprehensive understanding of the data model.
"""

import json
import re
import logging
from typing import Dict, List, Any, Optional, Set, Tuple
import google.cloud.bigquery as bq


class SchemaAnalyzer:
    """
    Analyzes BigQuery schemas to extract detailed metadata.
    
    The SchemaAnalyzer:
    1. Extracts table and column information
    2. Detects relationships between tables
    3. Identifies primary and foreign keys
    4. Analyzes column data types and patterns
    5. Generates comprehensive metadata repository
    """
    
    def __init__(self):
        """Initialize a new schema analyzer."""
        self._logger = logging.getLogger(__name__)
    
    async def analyze_schema(self, client: bq.Client, dataset_id: str) -> Dict[str, Any]:
        """
        Analyze a BigQuery dataset schema.
        
        Args:
            client: BigQuery client
            dataset_id: ID of the dataset to analyze
            
        Returns:
            Comprehensive metadata dictionary
        """
        self._logger.info(f"Analyzing schema for dataset: {dataset_id}")
        
        try:
            # Get all tables in the dataset
            tables = list(client.list_tables(dataset_id))
            
            # Initialize the metadata repository
            metadata = {
                "dataset": dataset_id,
                "tables": {},
                "relationships": [],
                "timestamps": self._detect_timestamp_columns(client, dataset_id, tables),
                "analysis_date": self._get_current_datetime()
            }
            
            # Process each table
            for table in tables:
                table_id = f"{dataset_id}.{table.table_id}"
                self._logger.debug(f"Processing table: {table_id}")
                
                # Get table schema
                table_ref = client.get_table(table_id)
                
                # Extract table metadata
                metadata["tables"][table.table_id] = self._extract_table_metadata(table_ref)
            
            # Detect relationships between tables
            metadata["relationships"] = self._detect_relationships(client, dataset_id, metadata["tables"])
            
            # Detect value distributions
            metadata = self._analyze_value_distributions(client, dataset_id, metadata)
            
            return metadata
        
        except Exception as e:
            self._logger.error(f"Error analyzing schema: {str(e)}")
            raise
    
    def _extract_table_metadata(self, table: bq.Table) -> Dict[str, Any]:
        """
        Extract metadata for a specific table.
        
        Args:
            table: BigQuery table reference
            
        Returns:
            Table metadata dictionary
        """
        columns = {}
        
        # Process each column in the table
        for field in table.schema:
            columns[field.name] = self._extract_column_metadata(field)
        
        # Build table metadata
        return {
            "description": table.description or "",
            "num_rows": table.num_rows,
            "num_bytes": table.num_bytes,
            "created": table.created.isoformat() if table.created else None,
            "modified": table.modified.isoformat() if table.modified else None,
            "columns": columns,
            "possible_primary_keys": self._identify_possible_primary_keys(columns),
            "labels": table.labels or {}
        }
    
    def _extract_column_metadata(self, field: bq.SchemaField) -> Dict[str, Any]:
        """
        Extract metadata for a specific column.
        
        Args:
            field: BigQuery schema field
            
        Returns:
            Column metadata dictionary
        """
        # Build column metadata
        column_metadata = {
            "description": field.description or "",
            "type": field.field_type,
            "mode": field.mode,
            "is_nullable": field.mode == "NULLABLE",
            "possible_values": None,
            "patterns": self._detect_column_patterns(field.name, field.field_type),
            "is_categorical": self._is_categorical_column(field.name, field.field_type),
            "is_temporal": self._is_temporal_column(field.name, field.field_type),
            "is_numeric": self._is_numeric_column(field.field_type)
        }
        
        # For nested fields, recursively extract metadata
        if field.field_type == "RECORD":
            column_metadata["fields"] = {}
            for nested_field in field.fields:
                column_metadata["fields"][nested_field.name] = self._extract_column_metadata(nested_field)
        
        return column_metadata
    
    def _detect_timestamp_columns(self, client: bq.Client, dataset_id: str, tables: List[bq.Table]) -> Dict[str, List[str]]:
        """
        Detect timestamp columns across all tables.
        
        Args:
            client: BigQuery client
            dataset_id: ID of the dataset
            tables: List of tables
            
        Returns:
            Dictionary mapping table names to lists of timestamp columns
        """
        timestamp_columns = {}
        
        for table in tables:
            table_id = f"{dataset_id}.{table.table_id}"
            table_ref = client.get_table(table_id)
            
            timestamp_cols = []
            for field in table_ref.schema:
                if field.field_type in ["TIMESTAMP", "DATETIME", "DATE"]:
                    timestamp_cols.append(field.name)
                elif self._is_temporal_column(field.name, field.field_type):
                    timestamp_cols.append(field.name)
            
            if timestamp_cols:
                timestamp_columns[table.table_id] = timestamp_cols
        
        return timestamp_columns
    
    def _detect_relationships(self, client: bq.Client, dataset_id: str, tables_metadata: Dict[str, Dict[str, Any]]) -> List[Dict[str, Any]]:
        """
        Detect relationships between tables.
        
        Args:
            client: BigQuery client
            dataset_id: ID of the dataset
            tables_metadata: Metadata for all tables
            
        Returns:
            List of relationships
        """
        relationships = []
        table_names = list(tables_metadata.keys())
        
        # Check each pair of tables for potential relationships
        for i, table1 in enumerate(table_names):
            for table2 in table_names[i+1:]:
                # Get potential relationships between these tables
                table_relationships = self._detect_table_relationships(
                    client, dataset_id, table1, table2, 
                    tables_metadata[table1], tables_metadata[table2]
                )
                
                relationships.extend(table_relationships)
        
        return relationships
    
    def _detect_table_relationships(self, client: bq.Client, dataset_id: str, 
                                  table1: str, table2: str, 
                                  table1_metadata: Dict[str, Any], 
                                  table2_metadata: Dict[str, Any]) -> List[Dict[str, Any]]:
        """
        Detect relationships between two tables.
        
        Args:
            client: BigQuery client
            dataset_id: ID of the dataset
            table1: Name of the first table
            table2: Name of the second table
            table1_metadata: Metadata for the first table
            table2_metadata: Metadata for the second table
            
        Returns:
            List of relationships between the tables
        """
        relationships = []
        
        # Get columns for both tables
        columns1 = table1_metadata["columns"]
        columns2 = table2_metadata["columns"]
        
        # Strategy 1: Name-based matching (e.g., id in one table matches table_id in another)
        name_based_relations = self._detect_name_based_relationships(
            table1, table2, columns1, columns2
        )
        relationships.extend(name_based_relations)
        
        # Strategy 2: Column similarity (type and pattern matching)
        similarity_based_relations = self._detect_similarity_based_relationships(
            table1, table2, columns1, columns2
        )
        relationships.extend(similarity_based_relations)
        
        # Strategy 3: Check for common join patterns in sample queries
        # This could be added later based on query logs analysis
        
        return relationships
    
    def _detect_name_based_relationships(self, table1: str, table2: str, 
                                      columns1: Dict[str, Any], columns2: Dict[str, Any]) -> List[Dict[str, Any]]:
        """
        Detect relationships based on column names.
        
        Args:
            table1: Name of the first table
            table2: Name of the second table
            columns1: Columns in the first table
            columns2: Columns in the second table
            
        Returns:
            List of name-based relationships
        """
        relationships = []
        
        # Common primary key patterns
        pk_patterns = [
            r'^id$',
            r'^{table}_id$',
            r'^{table}id$'
        ]
        
        # Common foreign key patterns
        fk_patterns = [
            r'^{ref_table}_id$',
            r'^{ref_table}id$',
            r'^{ref_table}_key$',
            r'^{ref_table}.*_id$'
        ]
        
        # Check for primary key to foreign key relationships
        for col1 in columns1:
            # Check if col1 could be a primary key in table1
            is_potential_pk = any(re.match(pattern.format(table=table1), col1, re.IGNORECASE) 
                                for pattern in pk_patterns)
            
            if is_potential_pk or col1 in table1_metadata.get("possible_primary_keys", []):
                # Look for corresponding foreign keys in table2
                for col2 in columns2:
                    # Check if col2 could be a foreign key referencing table1
                    is_potential_fk = any(re.match(pattern.format(ref_table=table1), col2, re.IGNORECASE) 
                                        for pattern in fk_patterns)
                    
                    if is_potential_fk and columns1[col1]["type"] == columns2[col2]["type"]:
                        relationships.append({
                            "source_table": table1,
                            "source_column": col1,
                            "target_table": table2,
                            "target_column": col2,
                            "relationship_type": "one_to_many",
                            "confidence": "medium",
                            "detection_method": "name_based"
                        })
        
        # Check the reverse direction as well
        for col2 in columns2:
            is_potential_pk = any(re.match(pattern.format(table=table2), col2, re.IGNORECASE) 
                                for pattern in pk_patterns)
            
            if is_potential_pk or col2 in table2_metadata.get("possible_primary_keys", []):
                for col1 in columns1:
                    is_potential_fk = any(re.match(pattern.format(ref_table=table2), col1, re.IGNORECASE) 
                                        for pattern in fk_patterns)
                    
                    if is_potential_fk and columns2[col2]["type"] == columns1[col1]["type"]:
                        relationships.append({
                            "source_table": table2,
                            "source_column": col2,
                            "target_table": table1,
                            "target_column": col1,
                            "relationship_type": "one_to_many",
                            "confidence": "medium",
                            "detection_method": "name_based"
                        })
        
        return relationships
    
    def _detect_similarity_based_relationships(self, table1: str, table2: str,
                                            columns1: Dict[str, Any], columns2: Dict[str, Any]) -> List[Dict[str, Any]]:
        """
        Detect relationships based on column similarity.
        
        Args:
            table1: Name of the first table
            table2: Name of the second table
            columns1: Columns in the first table
            columns2: Columns in the second table
            
        Returns:
            List of similarity-based relationships
        """
        relationships = []
        
        # Check for columns with identical names and types
        for col1 in columns1:
            for col2 in columns2:
                if col1 == col2 and columns1[col1]["type"] == columns2[col2]["type"]:
                    # Same name and type suggests a potential join key
                    relationships.append({
                        "source_table": table1,
                        "source_column": col1,
                        "target_table": table2,
                        "target_column": col2,
                        "relationship_type": "unspecified",
                        "confidence": "low",
                        "detection_method": "column_similarity"
                    })
        
        return relationships
    
    def _identify_possible_primary_keys(self, columns: Dict[str, Any]) -> List[str]:
        """
        Identify columns that could be primary keys.
        
        Args:
            columns: Columns dictionary
            
        Returns:
            List of potential primary key columns
        """
        potential_pk_columns = []
        
        pk_patterns = [
            r'^id$',
            r'^.*_id$',
            r'^.*id$',
            r'^.*_key$',
            r'^key$'
        ]
        
        for col_name, col_metadata in columns.items():
            # Check for naming conventions that suggest primary keys
            if any(re.match(pattern, col_name, re.IGNORECASE) for pattern in pk_patterns):
                # Primary keys should typically be non-nullable
                if not col_metadata.get("is_nullable", True):
                    potential_pk_columns.append(col_name)
                else:
                    # Still consider nullable columns, but with lower confidence
                    potential_pk_columns.append(col_name)
        
        return potential_pk_columns
    
    def _detect_column_patterns(self, col_name: str, col_type: str) -> Dict[str, Any]:
        """
        Detect patterns in column names and types.
        
        Args:
            col_name: Column name
            col_type: Column data type
            
        Returns:
            Dictionary of detected patterns
        """
        patterns = {}
        
        # Detect common column name patterns
        if re.match(r'^id$', col_name, re.IGNORECASE):
            patterns["is_id"] = True
        
        if re.match(r'^.*_id$', col_name, re.IGNORECASE):
            patterns["is_foreign_key"] = True
        
        if re.match(r'^(created|created_at|creation_date|create_time)$', col_name, re.IGNORECASE):
            patterns["is_creation_timestamp"] = True
        
        if re.match(r'^(updated|updated_at|update_date|update_time|modified|modified_at)$', col_name, re.IGNORECASE):
            patterns["is_update_timestamp"] = True
        
        if re.match(r'^(deleted|deleted_at|delete_date|delete_time|is_deleted)$', col_name, re.IGNORECASE):
            patterns["is_deletion_flag"] = True
        
        if re.match(r'^(status|state)$', col_name, re.IGNORECASE):
            patterns["is_status"] = True
        
        if re.match(r'^(name|title|label)$', col_name, re.IGNORECASE):
            patterns["is_display_name"] = True
        
        # Type-specific patterns
        if col_type in ["STRING", "VARCHAR"]:
            if re.match(r'^.*code$', col_name, re.IGNORECASE):
                patterns["is_code"] = True
            
            if re.match(r'^.*name$', col_name, re.IGNORECASE):
                patterns["is_name"] = True
        
        if col_type in ["INT64", "INTEGER", "NUMERIC", "FLOAT64", "FLOAT"]:
            if re.match(r'^(amount|total|sum|count|quantity|price|cost).*$', col_name, re.IGNORECASE):
                patterns["is_measure"] = True
        
        return patterns
    
    def _is_categorical_column(self, col_name: str, col_type: str) -> bool:
        """
        Determine if a column is likely to be categorical.
        
        Args:
            col_name: Column name
            col_type: Column data type
            
        Returns:
            True if the column is likely categorical, False otherwise
        """
        # Type-based categorization
        if col_type not in ["STRING", "VARCHAR"]:
            return False
        
        # Name-based categorization
        categorical_patterns = [
            r'^(type|category|status|state|level|grade|class|classification|tier|segment|group|bucket)$',
            r'^.*_(type|category|status|state|level|grade|class|classification|tier|segment|group|bucket)$',
            r'^(is_|has_|can_|should_).*$'
        ]
        
        return any(re.match(pattern, col_name, re.IGNORECASE) for pattern in categorical_patterns)
    
    def _is_temporal_column(self, col_name: str, col_type: str) -> bool:
        """
        Determine if a column is likely to be temporal.
        
        Args:
            col_name: Column name
            col_type: Column data type
            
        Returns:
            True if the column is likely temporal, False otherwise
        """
        # Type-based categorization
        if col_type in ["TIMESTAMP", "DATETIME", "DATE"]:
            return True
        
        # Name-based categorization
        temporal_patterns = [
            r'^(date|time|timestamp|datetime|year|month|day|hour|minute|second)$',
            r'^.*_(date|time|timestamp|datetime)$',
            r'^(created|updated|modified|deleted)(_at|_on)?$',
            r'^(start|end)_(date|time)$',
            r'^(begin|finish)_(date|time)$',
            r'^(from|to)_(date|time)$'
        ]
        
        return any(re.match(pattern, col_name, re.IGNORECASE) for pattern in temporal_patterns)
    
    def _is_numeric_column(self, col_type: str) -> bool:
        """
        Determine if a column is numeric.
        
        Args:
            col_type: Column data type
            
        Returns:
            True if the column is numeric, False otherwise
        """
        return col_type in ["INT64", "INTEGER", "NUMERIC", "FLOAT64", "FLOAT", "DECIMAL"]
    
    def _analyze_value_distributions(self, client: bq.Client, dataset_id: str, metadata: Dict[str, Any]) -> Dict[str, Any]:
        """
        Analyze value distributions for categorical columns.
        
        Args:
            client: BigQuery client
            dataset_id: ID of the dataset
            metadata: Current metadata dictionary
            
        Returns:
            Updated metadata dictionary
        """
        # For each table, identify categorical columns and sample their values
        for table_name, table_metadata in metadata["tables"].items():
            for col_name, col_metadata in table_metadata["columns"].items():
                # Only analyze categorical columns or columns with limited distinct values
                if col_metadata.get("is_categorical", False) or col_name.lower() in ["status", "type", "category"]:
                    # Sample distinct values
                    try:
                        query = f"""
                        SELECT DISTINCT {col_name} 
                        FROM `{dataset_id}.{table_name}` 
                        WHERE {col_name} IS NOT NULL 
                        LIMIT 100
                        """
                        
                        results = client.query(query).result()
                        
                        # Store the distinct values
                        distinct_values = [row[0] for row in results]
                        if distinct_values:
                            metadata["tables"][table_name]["columns"][col_name]["possible_values"] = distinct_values
                    
                    except Exception as e:
                        self._logger.warning(f"Error sampling values for {table_name}.{col_name}: {str(e)}")
        
        return metadata
    
    def _get_current_datetime(self) -> str:
        """Get the current datetime as an ISO-formatted string."""
        from datetime import datetime
        return datetime.now().isoformat()