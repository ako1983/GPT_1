"""
Metadata Agent Module

This module implements the Metadata Agent responsible for analyzing database schemas,
understanding data relationships, and providing comprehensive metadata to other agents.
"""

import os
import json
import logging
import asyncio
import re
from typing import Dict, List, Any, Optional, Tuple
import google.cloud.bigquery as bq

from ...core.interfaces.agent_interface import Agent, AgentType, ExecutionStatus, Message
from ...core.communication.event_bus import get_event_bus
from ...core.state.state_manager import get_state_manager, QueryState
from ...core.memory.vector_store import create_vector_store, VectorStore, Document
from .schema_analyzer import SchemaAnalyzer
from .business_term_mapper import BusinessTermMapper


class MetadataAgent(Agent):
    """
    Metadata Agent for analyzing and managing database metadata.
    
    The MetadataAgent:
    1. Extracts and analyzes database schema
    2. Identifies relationships between tables
    3. Maps business terms to database elements
    4. Provides metadata context to other agents
    5. Vectorizes metadata for semantic search
    """
    
    def __init__(self, agent_id: str, config: Dict[str, Any]):
        """
        Initialize a new metadata agent.
        
        Args:
            agent_id: Unique identifier for this agent
            config: Configuration parameters for this agent
        """
        super().__init__(agent_id, AgentType.METADATA)
        self._logger = logging.getLogger(__name__)
        self._config = config
        self._schema_analyzer = SchemaAnalyzer()
        self._business_term_mapper = BusinessTermMapper()
        self._vector_store = None
        self._metadata_cache = {}
        self._initialized = False
        self._event_bus = get_event_bus()
        self._state_manager = get_state_manager()
        
        # BigQuery client
        self._client = None
    
    async def initialize(self, config: Dict[str, Any]) -> bool:
        """
        Initialize the agent with configuration parameters.
        
        Args:
            config: Configuration parameters
            
        Returns:
            True if initialization was successful, False otherwise
        """
        try:
            # Update configuration
            self._config.update(config)
            
            # Initialize BigQuery client
            if "bigquery" in self._config:
                # Use credentials file if provided
                if "credentials_file" in self._config["bigquery"]:
                    os.environ["GOOGLE_APPLICATION_CREDENTIALS"] = self._config["bigquery"]["credentials_file"]
                
                # Create the client
                project_id = self._config["bigquery"].get("project_id")
                if project_id:
                    self._client = bq.Client(project=project_id)
                else:
                    self._client = bq.Client()
            
            # Initialize business term mapper
            if "business_term_mapping_file" in self._config:
                self._business_term_mapper.load_mappings(self._config["business_term_mapping_file"])
            
            # Initialize vector store
            vector_store_type = self._config.get("vector_store_type", "memory")
            vector_store_path = self._config.get("vector_store_path")
            embedding_function = self._config.get("embedding_function")
            
            self._vector_store = create_vector_store(
                vector_store_type,
                embedding_fn=embedding_function
            )
            
            # Load existing vector store if available
            if vector_store_path and os.path.exists(vector_store_path) and hasattr(self._vector_store, "load"):
                self._vector_store = self._vector_store.load(vector_store_path, embedding_function)
            
            # Load cached metadata if available
            metadata_cache_path = self._config.get("metadata_cache_path")
            if metadata_cache_path and os.path.exists(metadata_cache_path):
                with open(metadata_cache_path, 'r') as f:
                    self._metadata_cache = json.load(f)
            
            # Register with the event bus
            self._event_bus.register_agent(AgentType.METADATA, self.process)
            
            self._initialized = True
            self._logger.info("Metadata agent initialized successfully")
            
            # If instructed to analyze schemas on startup, do so
            if self._config.get("analyze_on_startup", False) and self._client:
                datasets = self._config.get("datasets", [])
                for dataset in datasets:
                    await self.analyze_dataset(dataset)
            
            return True
            
        except Exception as e:
            self._logger.error(f"Error initializing metadata agent: {str(e)}")
            return False
    
    async def process(self, message: Message) -> Message:
        """
        Process an incoming message and produce a response.
        
        Args:
            message: The incoming message to process
            
        Returns:
            A response message
        """
        self._logger.info(f"Processing message: {message.message_type}")
        
        # Extract message content
        content = message.content
        
        # Check the message type and dispatch to the appropriate handler
        if message.message_type == "analyze_dataset":
            dataset = content.get("dataset")
            if dataset:
                result = await self.analyze_dataset(dataset)
                return Message(
                    sender=AgentType.METADATA,
                    receiver=message.sender,
                    content=result,
                    message_type="analyze_dataset_result",
                    trace_id=message.trace_id
                )
        
        elif message.message_type == "get_metadata":
            dataset = content.get("dataset")
            table = content.get("table")
            query_id = content.get("query_id")
            
            if dataset or table or query_id:
                result = self.get_metadata(dataset, table, query_id)
                return Message(
                    sender=AgentType.METADATA,
                    receiver=message.sender,
                    content=result,
                    message_type="metadata_result",
                    trace_id=message.trace_id
                )
        
        elif message.message_type == "search_metadata":
            query = content.get("query")
            filter_dataset = content.get("dataset")
            filter_table = content.get("table")
            limit = content.get("limit", 5)
            
            if query:
                result = await self.search_metadata(query, filter_dataset, filter_table, limit)
                return Message(
                    sender=AgentType.METADATA,
                    receiver=message.sender,
                    content=result,
                    message_type="search_result",
                    trace_id=message.trace_id
                )
        
        elif message.message_type == "map_business_terms":
            query = content.get("query")
            query_id = content.get("query_id")
            
            if query or query_id:
                result = self.map_business_terms(query, query_id)
                return Message(
                    sender=AgentType.METADATA,
                    receiver=message.sender,
                    content=result,
                    message_type="term_mapping_result",
                    trace_id=message.trace_id
                )
        
        # Default response for unsupported message types
        return Message(
            sender=AgentType.METADATA,
            receiver=message.sender,
            content={"error": "Unsupported message type"},
            message_type="error",
            trace_id=message.trace_id
        )
    
    async def analyze_dataset(self, dataset: str) -> Dict[str, Any]:
        """
        Analyze a BigQuery dataset and extract metadata.
        
        Args:
            dataset: The dataset ID to analyze
            
        Returns:
            Dictionary of analysis results
        """
        self._logger.info(f"Analyzing dataset: {dataset}")
        
        try:
            # Check if we have a BigQuery client
            if not self._client:
                return {"error": "BigQuery client not initialized"}
            
            # Update status
            self.status = ExecutionStatus.IN_PROGRESS
            
            # Check if we have cached metadata for this dataset
            if dataset in self._metadata_cache:
                self._logger.info(f"Using cached metadata for dataset: {dataset}")
                metadata = self._metadata_cache[dataset]
            else:
                # Analyze the dataset schema
                self._logger.info(f"Analyzing schema for dataset: {dataset}")
                metadata = await self._schema_analyzer.analyze_schema(self._client, dataset)
                
                # Enrich with business terms
                metadata = self._business_term_mapper.enrich_schema_metadata(metadata)
                
                # Cache the metadata
                self._metadata_cache[dataset] = metadata
                
                # Save the metadata cache if configured
                metadata_cache_path = self._config.get("metadata_cache_path")
                if metadata_cache_path:
                    os.makedirs(os.path.dirname(metadata_cache_path), exist_ok=True)
                    with open(metadata_cache_path, 'w') as f:
                        json.dump(self._metadata_cache, f, indent=2)
            
            # Vectorize the metadata for search
            await self._vectorize_metadata(dataset, metadata)
            
            # Update status
            self.status = ExecutionStatus.COMPLETED
            
            return {
                "status": "success",
                "dataset": dataset,
                "tables": list(metadata.get("tables", {}).keys()),
                "relationships": len(metadata.get("relationships", [])),
                "timestamp": metadata.get("analysis_date")
            }
            
        except Exception as e:
            self._logger.error(f"Error analyzing dataset: {str(e)}")
            self.status = ExecutionStatus.FAILED
            return {"error": str(e)}
    
    async def _vectorize_metadata(self, dataset: str, metadata: Dict[str, Any]) -> None:
        """
        Vectorize metadata for efficient retrieval.
        
        Args:
            dataset: The dataset ID
            metadata: The metadata to vectorize
        """
        # Check if we have a vector store and embedding function
        if not self._vector_store or not hasattr(self._vector_store, "add_texts"):
            self._logger.warning("Vector store not available for metadata vectorization")
            return
        
        self._logger.info(f"Vectorizing metadata for dataset: {dataset}")
        
        try:
            # Create a collection for this dataset
            collection_name = f"metadata_{dataset}"
            
            # Process each table
            for table_name, table_metadata in metadata.get("tables", {}).items():
                # Create a document for the table
                table_doc = {
                    "text": f"Table: {table_name}\nDescription: {table_metadata.get('description', '')}\n",
                    "metadata": {
                        "dataset": dataset,
                        "table": table_name,
                        "type": "table",
                        "num_rows": table_metadata.get("num_rows"),
                        "num_bytes": table_metadata.get("num_bytes")
                    }
                }
                
                # Add column information to the table document
                for col_name, col_metadata in table_metadata.get("columns", {}).items():
                    col_desc = col_metadata.get("description", "")
                    col_type = col_metadata.get("type", "")
                    business_terms = col_metadata.get("business_terms", [])
                    
                    table_doc["text"] += f"Column: {col_name}\nType: {col_type}\nDescription: {col_desc}\n"
                    
                    if business_terms:
                        table_doc["text"] += f"Business Terms: {', '.join(business_terms)}\n"
                    
                    table_doc["text"] += "\n"
                
                # Add the table document to the vector store
                self._vector_store.add_texts(
                    texts=[table_doc["text"]],
                    metadatas=[table_doc["metadata"]],
                    collection_name=collection_name
                )
                
                # Create individual documents for each column
                for col_name, col_metadata in table_metadata.get("columns", {}).items():
                    col_desc = col_metadata.get("description", "")
                    col_type = col_metadata.get("type", "")
                    business_terms = col_metadata.get("business_terms", [])
                    
                    col_doc = {
                        "text": f"Dataset: {dataset}\nTable: {table_name}\nColumn: {col_name}\nType: {col_type}\nDescription: {col_desc}\n",
                        "metadata": {
                            "dataset": dataset,
                            "table": table_name,
                            "column": col_name,
                            "type": "column",
                            "data_type": col_type,
                            "business_terms": business_terms
                        }
                    }
                    
                    if business_terms:
                        col_doc["text"] += f"Business Terms: {', '.join(business_terms)}\n"
                    
                    # Add the column document to the vector store
                    self._vector_store.add_texts(
                        texts=[col_doc["text"]],
                        metadatas=[col_doc["metadata"]],
                        collection_name=collection_name
                    )
            
            # Process relationships
            for relationship in metadata.get("relationships", []):
                rel_doc = {
                    "text": f"Relationship: {relationship.get('source_table')}.{relationship.get('source_column')} -> {relationship.get('target_table')}.{relationship.get('target_column')}\n"
                           f"Type: {relationship.get('relationship_type')}\n"
                           f"Confidence: {relationship.get('confidence')}\n",
                    "metadata": {
                        "dataset": dataset,
                        "type": "relationship",
                        "source_table": relationship.get("source_table"),
                        "source_column": relationship.get("source_column"),
                        "target_table": relationship.get("target_table"),
                        "target_column": relationship.get("target_column"),
                        "relationship_type": relationship.get("relationship_type")
                    }
                }
                
                # Add the relationship document to the vector store
                self._vector_store.add_texts(
                    texts=[rel_doc["text"]],
                    metadatas=[rel_doc["metadata"]],
                    collection_name=collection_name
                )
            
            # Save the vector store if configured
            vector_store_path = self._config.get("vector_store_path")
            if vector_store_path and hasattr(self._vector_store, "save"):
                self._vector_store.save(vector_store_path)
            
            self._logger.info(f"Vectorized metadata for dataset: {dataset}")
            
        except Exception as e:
            self._logger.error(f"Error vectorizing metadata: {str(e)}")
    
    def get_metadata(self, dataset: Optional[str] = None, table: Optional[str] = None, 
                     query_id: Optional[str] = None) -> Dict[str, Any]:
        """
        Get metadata for a dataset or table.
        
        Args:
            dataset: Optional dataset ID
            table: Optional table name
            query_id: Optional query ID to associate the metadata with
            
        Returns:
            Dictionary of metadata
        """
        # If a query ID is provided, associate the metadata with the query
        if query_id:
            query_state = self._state_manager.get_query_state(query_id)
            if query_state:
                # Update the query state with metadata context
                context_update = {}
                
                if dataset:
                    context_update["dataset"] = dataset
                    
                    if dataset in self._metadata_cache:
                        if table:
                            # Add table metadata if available
                            if table in self._metadata_cache[dataset].get("tables", {}):
                                context_update["table_metadata"] = self._metadata_cache[dataset]["tables"][table]
                        else:
                            # Add dataset metadata
                            context_update["dataset_metadata"] = {
                                "tables": list(self._metadata_cache[dataset].get("tables", {}).keys()),
                                "relationships": self._metadata_cache[dataset].get("relationships", []),
                                "analysis_date": self._metadata_cache[dataset].get("analysis_date")
                            }
                
                self._state_manager.update_query_context(query_id, context_update)
        
        # Return metadata based on provided parameters
        if dataset:
            if dataset in self._metadata_cache:
                if table:
                    # Return table metadata
                    if table in self._metadata_cache[dataset].get("tables", {}):
                        return {
                            "dataset": dataset,
                            "table": table,
                            "metadata": self._metadata_cache[dataset]["tables"][table]
                        }
                    else:
                        return {"error": f"Table {table} not found in dataset {dataset}"}
                else:
                    # Return dataset metadata
                    return {
                        "dataset": dataset,
                        "tables": list(self._metadata_cache[dataset].get("tables", {}).keys()),
                        "relationships": self._metadata_cache[dataset].get("relationships", []),
                        "analysis_date": self._metadata_cache[dataset].get("analysis_date")
                    }
            else:
                return {"error": f"Dataset {dataset} not found"}
        else:
            # Return list of available datasets
            return {
                "datasets": list(self._metadata_cache.keys())
            }
    
    async def search_metadata(self, query: str, filter_dataset: Optional[str] = None, 
                           filter_table: Optional[str] = None, limit: int = 5) -> Dict[str, Any]:
        """
        Search metadata using semantic similarity.
        
        Args:
            query: The search query
            filter_dataset: Optional dataset to filter results
            filter_table: Optional table to filter results
            limit: Maximum number of results to return
            
        Returns:
            Dictionary of search results
        """
        # Check if we have a vector store
        if not self._vector_store:
            return {"error": "Vector store not available"}
        
        try:
            # Determine which collection(s) to search
            collections = []
            if filter_dataset:
                collections.append(f"metadata_{filter_dataset}")
            else:
                # Search all dataset collections
                collections = [name for name in self._vector_store.list_collections() 
                              if name.startswith("metadata_")]
            
            # Prepare filter for table if specified
            filter_dict = {}
            if filter_table:
                filter_dict["table"] = filter_table
            
            # Search each collection
            all_results = []
            for collection in collections:
                try:
                    results = self._vector_store.similarity_search(
                        query=query,
                        k=limit,
                        collection_name=collection,
                        filter=filter_dict if filter_dict else None
                    )
                    all_results.extend(results)
                except Exception as e:
                    self._logger.warning(f"Error searching collection {collection}: {str(e)}")
            
            # Sort results by relevance and limit
            # (This is a bit of a simplification since we're combining results from different collections)
            all_results = all_results[:limit]
            
            # Format the results
            formatted_results = []
            for doc in all_results:
                formatted_results.append({
                    "text": doc.get("text", ""),
                    "metadata": doc.get("metadata", {})
                })
            
            return {
                "query": query,
                "results": formatted_results
            }
            
        except Exception as e:
            self._logger.error(f"Error searching metadata: {str(e)}")
            return {"error": str(e)}
    
    def map_business_terms(self, query: Optional[str] = None, query_id: Optional[str] = None) -> Dict[str, Any]:
        """
        Map business terms in a query to database elements.
        
        Args:
            query: The query to analyze
            query_id: Optional query ID to associate the mappings with
            
        Returns:
            Dictionary of business term mappings
        """
        # Get the query text if a query ID is provided
        if query_id and not query:
            query_state = self._state_manager.get_query_state(query_id)
            if query_state:
                query = query_state.get("raw_query")
        
        if not query:
            return {"error": "No query provided"}
        
        # Find business terms in the query
        business_terms = self._business_term_mapper.find_business_terms(query)
        
        # Map terms to database elements
        mappings = {}
        for term in business_terms:
            column = self._business_term_mapper.get_column_for_term(term)
            if column:
                mappings[term] = column
        
        # Look for similar terms for unmapped words
        words = set(re.findall(r'\b\w+\b', query))
        for word in words:
            if word.lower() not in [term.lower() for term in business_terms] and len(word) > 3:
                similar_terms = self._business_term_mapper.find_similar_terms(word, threshold=0.8)
                if similar_terms:
                    # Add the top similar term to suggestions
                    if "suggestions" not in mappings:
                        mappings["suggestions"] = {}
                    
                    mappings["suggestions"][word] = {
                        "term": similar_terms[0][0],
                        "similarity": similar_terms[0][1]
                    }
        
        # If a query ID is provided, associate the mappings with the query
        if query_id:
            self._state_manager.update_query_context(query_id, {
                "business_term_mappings": mappings
            })
        
        return {
            "query": query,
            "mappings": mappings
        }
    
    def get_capabilities(self) -> List[str]:
        """
        Return a list of capabilities this agent provides.
        
        Returns:
            List of capability strings
        """
        return [
            "schema_analysis",
            "metadata_search",
            "business_term_mapping",
            "relationship_detection"
        ]
    
    def get_status(self) -> Dict[str, Any]:
        """
        Get the current status of this agent.
        
        Returns:
            A dictionary with status information
        """
        return {
            "agent_id": self.agent_id,
            "agent_type": self.agent_type,
            "status": self.status,
            "datasets": list(self._metadata_cache.keys()),
            "initialized": self._initialized
        }
    
    async def shutdown(self) -> bool:
        """
        Perform cleanup when shutting down the agent.
        
        Returns:
            True if shutdown was successful, False otherwise
        """
        try:
            # Save vector store if configured
            vector_store_path = self._config.get("vector_store_path")
            if vector_store_path and self._vector_store and hasattr(self._vector_store, "save"):
                self._vector_store.save(vector_store_path)
            
            # Save metadata cache if configured
            metadata_cache_path = self._config.get("metadata_cache_path")
            if metadata_cache_path:
                with open(metadata_cache_path, 'w') as f:
                    json.dump(self._metadata_cache, f, indent=2)
            
            # Unregister from the event bus
            self._event_bus.unregister_agent(AgentType.METADATA)
            
            return True
            
        except Exception as e:
            self._logger.error(f"Error shutting down metadata agent: {str(e)}")
            return False