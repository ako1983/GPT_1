"""
Business Term Mapper Module

This module is responsible for mapping business terms to their corresponding
technical database elements, such as tables and columns.
"""

import json
import re
import logging
from typing import Dict, List, Any, Optional, Set, Tuple
import os
from difflib import SequenceMatcher


class BusinessTermMapper:
    """
    Maps business terminology to database structures.
    
    The BusinessTermMapper:
    1. Loads business term mappings from configuration
    2. Identifies business terms in user queries
    3. Maps terms to their corresponding database elements
    4. Provides context for query understanding and SQL generation
    """
    
    def __init__(self, mapping_file_path: Optional[str] = None):
        """
        Initialize a new business term mapper.
        
        Args:
            mapping_file_path: Path to the business term mapping file
        """
        self._logger = logging.getLogger(__name__)
        self.term_to_column: Dict[str, Dict[str, str]] = {}
        self.column_to_terms: Dict[str, Dict[str, List[str]]] = {}
        self.all_terms: Set[str] = set()
        
        # Load mappings if provided
        if mapping_file_path and os.path.exists(mapping_file_path):
            self.load_mappings(mapping_file_path)
    
    def load_mappings(self, mapping_file_path: str) -> None:
        """
        Load business term mappings from a file.
        
        Args:
            mapping_file_path: Path to the mapping file
        """
        try:
            with open(mapping_file_path, 'r', encoding='utf-8') as f:
                mappings = json.load(f)
            
            # Process the mappings
            if isinstance(mappings, dict) and "business_terms" in mappings:
                self._process_mappings(mappings["business_terms"])
            elif isinstance(mappings, list):
                self._process_mappings(mappings)
            else:
                self._logger.error(f"Invalid mapping format in {mapping_file_path}")
                
            self._logger.info(f"Loaded {len(self.all_terms)} business term mappings")
            
        except Exception as e:
            self._logger.error(f"Error loading business term mappings: {str(e)}")
    
    def _process_mappings(self, mappings: List[Dict[str, Any]]) -> None:
        """
        Process business term mappings.
        
        Args:
            mappings: List of mapping dictionaries
        """
        for mapping in mappings:
            # Extract the business term
            business_term = mapping.get("term") or mapping.get("business_term")
            if not business_term:
                continue
            
            # Extract the database mapping
            table = mapping.get("table")
            column = mapping.get("column")
            
            if table and column:
                # Add to term-to-column mapping
                if business_term not in self.term_to_column:
                    self.term_to_column[business_term] = {}
                
                self.term_to_column[business_term][table] = column
                
                # Add to column-to-terms mapping
                if table not in self.column_to_terms:
                    self.column_to_terms[table] = {}
                
                if column not in self.column_to_terms[table]:
                    self.column_to_terms[table][column] = []
                
                self.column_to_terms[table][column].append(business_term)
                
                # Add to all terms set
                self.all_terms.add(business_term)
    
    def add_term_mapping(self, business_term: str, table: str, column: str) -> None:
        """
        Add a new business term mapping.
        
        Args:
            business_term: The business term
            table: The corresponding table
            column: The corresponding column
        """
        # Add to term-to-column mapping
        if business_term not in self.term_to_column:
            self.term_to_column[business_term] = {}
        
        self.term_to_column[business_term][table] = column
        
        # Add to column-to-terms mapping
        if table not in self.column_to_terms:
            self.column_to_terms[table] = {}
        
        if column not in self.column_to_terms[table]:
            self.column_to_terms[table][column] = []
        
        self.column_to_terms[table][column].append(business_term)
        
        # Add to all terms set
        self.all_terms.add(business_term)
        
        self._logger.debug(f"Added mapping: {business_term} -> {table}.{column}")
    
    def get_column_for_term(self, business_term: str, table: Optional[str] = None) -> Optional[str]:
        """
        Get the database column for a business term.
        
        Args:
            business_term: The business term to look up
            table: Optional table to restrict the search to
            
        Returns:
            The corresponding column, or None if not found
        """
        # Check for exact match
        if business_term in self.term_to_column:
            if table is None:
                # Return the first table.column mapping
                for t, col in self.term_to_column[business_term].items():
                    return col
            
            # Return the column for the specified table
            return self.term_to_column[business_term].get(table)
        
        # Try case-insensitive match
        lowercase_term = business_term.lower()
        for term in self.term_to_column:
            if term.lower() == lowercase_term:
                if table is None:
                    # Return the first table.column mapping
                    for t, col in self.term_to_column[term].items():
                        return col
                
                # Return the column for the specified table
                return self.term_to_column[term].get(table)
        
        # No match found
        return None
    
    def get_terms_for_column(self, table: str, column: str) -> List[str]:
        """
        Get the business terms for a database column.
        
        Args:
            table: The database table
            column: The database column
            
        Returns:
            List of corresponding business terms
        """
        if table in self.column_to_terms and column in self.column_to_terms[table]:
            return self.column_to_terms[table][column]
        
        return []
    
    def find_business_terms(self, text: str) -> List[str]:
        """
        Find business terms in a text.
        
        Args:
            text: The text to search
            
        Returns:
            List of found business terms
        """
        found_terms = []
        
        # First, look for exact matches
        for term in self.all_terms:
            if re.search(r'\b' + re.escape(term) + r'\b', text, re.IGNORECASE):
                found_terms.append(term)
        
        return found_terms
    
    def find_similar_terms(self, term: str, threshold: float = 0.8) -> List[Tuple[str, float]]:
        """
        Find business terms similar to the input term.
        
        Args:
            term: The term to find similar terms for
            threshold: Similarity threshold (0-1)
            
        Returns:
            List of (term, similarity) pairs
        """
        similar_terms = []
        
        for existing_term in self.all_terms:
            similarity = self._calculate_similarity(term, existing_term)
            if similarity >= threshold:
                similar_terms.append((existing_term, similarity))
        
        # Sort by similarity (highest first)
        similar_terms.sort(key=lambda x: x[1], reverse=True)
        
        return similar_terms
    
    def _calculate_similarity(self, a: str, b: str) -> float:
        """
        Calculate the similarity between two strings.
        
        Args:
            a: First string
            b: Second string
            
        Returns:
            Similarity score (0-1)
        """
        # Simple case: one string contains the other
        a_lower = a.lower()
        b_lower = b.lower()
        
        if a_lower in b_lower or b_lower in a_lower:
            return 0.9
        
        # Use SequenceMatcher for more complex comparison
        return SequenceMatcher(None, a_lower, b_lower).ratio()
    
    def enrich_schema_metadata(self, schema_metadata: Dict[str, Any]) -> Dict[str, Any]:
        """
        Enrich schema metadata with business term mappings.
        
        Args:
            schema_metadata: Schema metadata dictionary
            
        Returns:
            Enriched metadata dictionary
        """
        # Create a deep copy to avoid modifying the original
        enriched_metadata = json.loads(json.dumps(schema_metadata))
        
        # Add business terms to each column
        for table_name, table_metadata in enriched_metadata.get("tables", {}).items():
            for column_name, column_metadata in table_metadata.get("columns", {}).items():
                # Get business terms for this column
                business_terms = self.get_terms_for_column(table_name, column_name)
                
                if business_terms:
                    # Add the business terms to the column metadata
                    column_metadata["business_terms"] = business_terms
        
        # Add a business term glossary to the metadata
        business_term_glossary = {}
        for term in self.all_terms:
            glossary_entry = {
                "term": term,
                "mappings": []
            }
            
            # Add all table.column mappings for this term
            for table, column in self.term_to_column.get(term, {}).items():
                glossary_entry["mappings"].append({
                    "table": table,
                    "column": column
                })
            
            business_term_glossary[term] = glossary_entry
        
        enriched_metadata["business_term_glossary"] = business_term_glossary
        
        return enriched_metadata
    
    def save_mappings(self, output_file_path: str) -> bool:
        """
        Save the current mappings to a file.
        
        Args:
            output_file_path: Path to save the mappings to
            
        Returns:
            True if successful, False otherwise
        """
        try:
            # Create the output directory if it doesn't exist
            os.makedirs(os.path.dirname(output_file_path), exist_ok=True)
            
            # Convert mappings to a serializable format
            mappings = {
                "business_terms": []
            }
            
            for term, table_columns in self.term_to_column.items():
                for table, column in table_columns.items():
                    mappings["business_terms"].append({
                        "term": term,
                        "table": table,
                        "column": column
                    })
            
            # Write to the output file
            with open(output_file_path, 'w', encoding='utf-8') as f:
                json.dump(mappings, f, indent=2)
            
            self._logger.info(f"Saved {len(mappings['business_terms'])} business term mappings to {output_file_path}")
            return True
            
        except Exception as e:
            self._logger.error(f"Error saving business term mappings: {str(e)}")
            return False