# SQL Agent Module

## Overview

The SQL Agent is responsible for generating accurate SQL queries based on natural language user queries and context from other agents. It maps query entities to database schema elements, generates SQL queries based on those mappings, and validates the generated SQL for correctness and safety.

The SQL Agent plays a crucial role in the OPEX_BOT system by translating user intent into executable SQL queries, allowing users to access database information without needing SQL expertise.

## Components

The SQL Agent module consists of the following key components:

### 1. SQLAgent

The main agent implementation that orchestrates the SQL generation process. It handles messages from other agents, coordinates the schema mapping, SQL generation, and validation components, and manages the generation workflow.

### 2. SchemaMapper

Maps query entities to database schema elements by:
- Mapping business terms to database tables
- Mapping metrics to database columns
- Translating time periods to SQL conditions
- Generating joins between tables

### 3. SQLGenerator

Generates SQL queries based on mapped schema elements by:
- Translating user intents to SQL structures
- Creating appropriate SELECT, FROM, WHERE, JOIN clauses
- Handling different query types (aggregation, comparison, retrieval)
- Formatting and optimizing the generated SQL

### 4. SQLValidator

Validates SQL queries for correctness and safety by:
- Checking syntax for errors
- Validating table and column references against schema
- Identifying security issues like SQL injection
- Suggesting fixes for invalid SQL

## Key Features

- **Entity Mapping**: Maps business terms and entities to database elements
- **SQL Generation**: Translates user intent to SQL queries
- **SQL Validation**: Ensures generated SQL is correct and safe
- **Iterative Improvement**: Refines SQL through validation and regeneration
- **Schema-Aware**: Uses database schema to guide generation
- **Context Integration**: Incorporates context from RAG for improved accuracy

## Usage

### Initialization

```python
from final_ako_opex.agents.sql import SQLAgent

# Initialize with configuration
sql_agent = SQLAgent(agent_id="sql_agent_1", config={
    "schema_file": "path/to/schema.json",
    "mappings_file": "path/to/mappings.json",
    "validation_required": True,
    "auto_fix": True
})

# Initialize the agent
await sql_agent.initialize({})
```

### Generating SQL

```python
# Direct method call
result = await sql_agent.generate_sql(
    query="What was the total OPEX budget for CTO in Q1 2023?",
    query_id="query-123",
    query_context={
        "intent": "aggregation",
        "business_units": ["CTO"],
        "metrics": ["budget"],
        "time_period": ["Q1_2023"]
    }
)

# Check if SQL generation was successful
if result["success"]:
    print(f"Generated SQL: {result['sql']}")
else:
    print(f"Error generating SQL: {result.get('error')}")
```

### Mapping Query Entities

```python
# Map query entities to schema elements
mapping_result = sql_agent.map_query(
    query="What was the total OPEX budget for CTO in Q1 2023?",
    query_context={
        "intent": "aggregation",
        "business_units": ["CTO"],
        "metrics": ["budget"],
        "time_period": ["Q1_2023"]
    }
)

# Get the mapped schema elements
schema_mapping = mapping_result["schema_mapping"]
mapped_tables = mapping_result["tables"]
mapped_columns = mapping_result["columns"]
```

### Validating SQL

```python
# Validate a SQL query
validation_result = sql_agent.validate_sql(
    sql="SELECT SUM(budget_amt) FROM pypl_opex_bau WHERE bu_level_3_desc = 'CTO' AND fiscal_quarter = 'Q1_2023'"
)

# Check if the SQL is valid
if validation_result["is_valid"]:
    print("SQL is valid")
else:
    # Print validation errors
    for error in validation_result["errors"]:
        print(f"Error: {error['message']}")
```

## Configuration

The SQL Agent supports the following configuration options:

### Basic Configuration

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `agent_id` | string | - | Unique identifier for the agent |
| `schema_file` | string | - | Path to the JSON schema file |
| `mappings_file` | string | - | Path to the business term mappings file |
| `max_iterations` | integer | 3 | Maximum number of SQL generation iterations |
| `validation_required` | boolean | true | Whether to validate generated SQL |
| `auto_fix` | boolean | true | Whether to automatically fix invalid SQL |

### Schema Mapper Configuration

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `schema_mapper_config.exact_match_threshold` | integer | 100 | Threshold for exact term matching |
| `schema_mapper_config.high_match_threshold` | integer | 90 | Threshold for high confidence matching |
| `schema_mapper_config.medium_match_threshold` | integer | 75 | Threshold for medium confidence matching |
| `schema_mapper_config.low_match_threshold` | integer | 60 | Threshold for low confidence matching |

### SQL Generator Configuration

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `sql_generator_config.dialect` | string | "bigquery" | SQL dialect to generate |
| `sql_generator_config.format_sql` | boolean | true | Whether to format the generated SQL |
| `sql_generator_config.add_comments` | boolean | true | Whether to add comments to the SQL |
| `sql_generator_config.max_limit` | integer | 1000 | Default LIMIT clause value |

### SQL Validator Configuration

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `sql_validator_config.dialect` | string | "bigquery" | SQL dialect to validate |
| `sql_validator_config.validation_level` | string | "strict" | Validation strictness level |
| `sql_validator_config.max_query_length` | integer | 10000 | Maximum allowed query length |
| `sql_validator_config.bigquery_credentials` | string | - | Path to BigQuery credentials file |
| `sql_validator_config.bigquery_project` | string | - | BigQuery project ID |

## Integration with Other Agents

The SQL Agent integrates with:

- **Query Enhancer Agent**: Receives enhanced queries for improved understanding
- **RAG Agent**: Receives relevant context for accurate SQL generation
- **SQL Helper Agent**: Passes generated SQL for further refinement
- **Response Agent**: Provides generated SQL for final presentation

## Example Workflow

1. User asks: "What was the CTO department's Q1 2023 budget?"
2. Query Enhancer analyzes and enhances the query
3. RAG Agent provides relevant context from the database schema
4. SQL Agent maps query entities to schema elements:
   - "CTO" → table: pypl_opex_bau, column: bu_level_3_desc
   - "budget" → table: pypl_opex_bau, column: budget_amt
   - "Q1 2023" → conditions: fiscal_quarter = 'Q1_2023'
5. SQL Agent generates SQL:
   ```sql
   SELECT SUM(budget_amt) AS budget_sum
   FROM pypl_opex_bau
   WHERE bu_level_3_desc = 'CTO' 
     AND fiscal_quarter = 'Q1_2023'
   ```
6. SQL Agent validates the SQL for correctness
7. SQL is passed to the next agent in the workflow

## Schema and Mappings Structure

### Schema Format

The schema file should have the following structure:

```json
{
  "tables": {
    "pypl_opex_bau": {
      "description": "OPEX budget, forecast, and actual data",
      "columns": {
        "budget_amt": {
          "type": "FLOAT64",
          "description": "Budget amount in USD"
        },
        "fiscal_quarter": {
          "type": "STRING",
          "description": "Fiscal quarter (e.g., 'Q1_2023')"
        },
        "bu_level_3_desc": {
          "type": "STRING",
          "description": "Business unit level 3 description"
        }
      }
    }
  },
  "relationships": [
    {
      "source_table": "pypl_opex_bau",
      "source_column": "cost_center_id",
      "target_table": "cost_center",
      "target_column": "id",
      "relationship_type": "many-to-one"
    }
  ]
}
```

### Mappings Format

The mappings file should have the following structure:

```json
{
  "term_to_table": {
    "CTO": "pypl_opex_bau",
    "Finance": "pypl_opex_bau",
    "OPEX": "pypl_opex_bau"
  },
  "term_to_column": {
    "budget": {
      "table": "pypl_opex_bau",
      "column": "budget_amt"
    },
    "headcount": {
      "table": "rpt_hdcnt_bdgt_view",
      "column": "headcount"
    }
  }
}
```

## Best Practices

1. **Schema Definition**: Define a comprehensive schema with accurate table and column information
2. **Business Term Mappings**: Maintain a rich set of mappings between business terms and database elements
3. **Query Context**: Provide detailed query context from the Query Enhancer for better entity mapping
4. **RAG Integration**: Use context from RAG to improve SQL generation accuracy
5. **Validation Settings**: Configure validation based on your database dialect and requirements
6. **Iteration Control**: Adjust max_iterations based on your accuracy and performance needs