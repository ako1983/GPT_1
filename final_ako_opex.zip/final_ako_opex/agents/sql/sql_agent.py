"""
SQL Agent Module

This module implements the SQL Agent, responsible for generating accurate SQL queries
based on user queries and context from other agents.
"""

import os
import json
import logging
import asyncio
from typing import Dict, List, Any, Optional, Tuple
import re

from ...core.interfaces.agent_interface import Agent, AgentType, ExecutionStatus, Message
from ...core.communication.event_bus import get_event_bus
from ...core.state.state_manager import get_state_manager, QueryState
from .schema_mapper import SchemaMapper
from .sql_generator import SQLGenerator
from .sql_validator import SQLValidator


class SQLAgent(Agent):
    """
    SQL Agent for generating SQL queries from natural language.
    
    The SQLAgent:
    1. Maps query entities to database schema elements
    2. Generates SQL based on the mapped schema elements
    3. Validates the generated SQL for correctness
    4. Provides detailed metadata about the generated SQL
    5. Handles failure cases gracefully
    """
    
    def __init__(self, agent_id: str, config: Dict[str, Any]):
        """
        Initialize a new SQL agent.
        
        Args:
            agent_id: Unique identifier for this agent
            config: Configuration parameters for this agent
        """
        super().__init__(agent_id, AgentType.SQL)
        self._logger = logging.getLogger(__name__)
        self._config = config
        self._initialized = False
        self._event_bus = get_event_bus()
        self._state_manager = get_state_manager()
        
        # Initialize components
        self._schema_mapper = SchemaMapper(config.get("schema_mapper_config", {}))
        self._sql_generator = SQLGenerator(config.get("sql_generator_config", {}))
        self._sql_validator = SQLValidator(config.get("sql_validator_config", {}))
        
        # Load schema if provided
        self._schema = config.get("schema", {})
        if self._schema:
            self._schema_mapper.load_schema(self._schema)
        
        # Load mappings if provided
        self._mappings = config.get("mappings", {})
        if self._mappings:
            self._schema_mapper.load_mappings(self._mappings)
        
        # Settings
        self._max_iterations = config.get("max_iterations", 3)
        self._validation_required = config.get("validation_required", True)
        self._auto_fix = config.get("auto_fix", True)
    
    async def initialize(self, config: Dict[str, Any]) -> bool:
        """
        Initialize the agent with configuration parameters.
        
        Args:
            config: Configuration parameters
            
        Returns:
            True if initialization was successful, False otherwise
        """
        try:
            # Update configuration
            self._config.update(config)
            
            # Update settings from new config
            self._max_iterations = self._config.get("max_iterations", self._max_iterations)
            self._validation_required = self._config.get("validation_required", self._validation_required)
            self._auto_fix = self._config.get("auto_fix", self._auto_fix)
            
            # Load schema from file if specified
            schema_file = self._config.get("schema_file")
            if schema_file and os.path.exists(schema_file):
                with open(schema_file, 'r') as f:
                    self._schema = json.load(f)
                    self._schema_mapper.load_schema(self._schema)
                    
                    # Also update the validator with the schema
                    validator_config = self._config.get("sql_validator_config", {})
                    validator_config["schema"] = self._schema
                    self._sql_validator = SQLValidator(validator_config)
            
            # Load mappings from file if specified
            mappings_file = self._config.get("mappings_file")
            if mappings_file and os.path.exists(mappings_file):
                with open(mappings_file, 'r') as f:
                    self._mappings = json.load(f)
                    self._schema_mapper.load_mappings(self._mappings)
            
            # Register with the event bus
            self._event_bus.register_agent(AgentType.SQL, self.process)
            
            self._initialized = True
            self._logger.info("SQL agent initialized successfully")
            return True
            
        except Exception as e:
            self._logger.error(f"Error initializing SQL agent: {str(e)}")
            return False
    
    async def process(self, message: Message) -> Message:
        """
        Process an incoming message and produce a response.
        
        Args:
            message: The incoming message to process
            
        Returns:
            A response message
        """
        self._logger.info(f"Processing message: {message.message_type}")
        
        # Extract message content
        content = message.content
        
        # Check the message type and dispatch to the appropriate handler
        if message.message_type == "generate_sql":
            query = content.get("query")
            query_id = content.get("query_id")
            query_context = content.get("query_context")
            enhanced_query = content.get("enhanced_query")
            context = content.get("context", [])
            options = content.get("options", {})
            
            if query:
                result = await self.generate_sql(query, query_id, query_context, enhanced_query, context, options)
                return Message(
                    sender=AgentType.SQL,
                    receiver=message.sender,
                    content=result,
                    message_type="sql_generated",
                    trace_id=message.trace_id
                )
        
        elif message.message_type == "validate_sql":
            sql = content.get("sql")
            schema_mapping = content.get("schema_mapping")
            
            if sql:
                result = self.validate_sql(sql, schema_mapping)
                return Message(
                    sender=AgentType.SQL,
                    receiver=message.sender,
                    content=result,
                    message_type="sql_validation",
                    trace_id=message.trace_id
                )
        
        elif message.message_type == "map_query":
            query = content.get("query")
            query_context = content.get("query_context")
            
            if query and query_context:
                result = self.map_query(query, query_context)
                return Message(
                    sender=AgentType.SQL,
                    receiver=message.sender,
                    content=result,
                    message_type="query_mapping",
                    trace_id=message.trace_id
                )
        
        # Default response for unsupported message types
        return Message(
            sender=AgentType.SQL,
            receiver=message.sender,
            content={"error": "Unsupported message type"},
            message_type="error",
            trace_id=message.trace_id
        )
    
    async def generate_sql(self, query: str, query_id: Optional[str] = None,
                         query_context: Optional[Dict[str, Any]] = None,
                         enhanced_query: Optional[str] = None, 
                         context: Optional[List[Dict[str, Any]]] = None,
                         options: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """
        Generate a SQL query from a natural language query.
        
        Args:
            query: The original user query
            query_id: Optional query ID for state tracking
            query_context: Optional query context from Query Enhancer
            enhanced_query: Optional enhanced query from Query Enhancer
            context: Optional context documents from RAG
            options: Optional generation options
            
        Returns:
            Dictionary with generated SQL and metadata
        """
        self._logger.info(f"Generating SQL for query: {query}")
        
        try:
            # Update status
            self.status = ExecutionStatus.IN_PROGRESS
            
            # Get options
            options = options or {}
            max_iterations = options.get("max_iterations", self._max_iterations)
            
            # Generate a query ID if not provided
            if not query_id:
                query_id = f"query_{hash(query) & 0xffffffff}"
            
            # Get query context from state if not provided
            if not query_context and query_id:
                query_state = self._state_manager.get_query_state(query_id)
                if query_state:
                    query_context = query_state.get_context("query_context")
            
            # If still no query context, create a minimal one
            if not query_context:
                query_context = {
                    "intent": "retrieval"
                }
            
            # Use enhanced query if provided, otherwise use original query
            effective_query = enhanced_query or query
            
            # Extract relevant context from RAG results
            extracted_context = self._extract_context_from_rag(context)
            
            # Map query entities to schema elements
            mapping_result = self.map_query(effective_query, query_context)
            schema_mapping = mapping_result["schema_mapping"]
            
            # Update schema mapping with context from RAG
            self._enhance_mapping_with_context(schema_mapping, extracted_context)
            
            # Generate initial SQL query
            generation_result = self._sql_generator.generate_sql(effective_query, query_context, schema_mapping)
            sql = generation_result["sql"]
            success = generation_result["success"]
            
            # Iteratively improve the SQL if needed
            iterations = 0
            validation_errors = []
            
            while iterations < max_iterations:
                # Validate the SQL
                if self._validation_required and sql:
                    validation_result = self._sql_validator.validate_sql(sql, schema_mapping)
                    
                    # If SQL is valid, we're done
                    if validation_result["is_valid"]:
                        break
                    
                    # Store validation errors
                    validation_errors = validation_result["errors"]
                    
                    # Try to fix the SQL
                    if self._auto_fix:
                        fix_result = self._sql_validator.suggest_fixes(sql, validation_result)
                        if fix_result["can_fix"]:
                            sql = fix_result["fixed_sql"]
                            self._logger.info(f"Auto-fixed SQL query in iteration {iterations + 1}")
                            continue
                
                # If no auto-fix or fix failed, try another generation approach
                if iterations < max_iterations - 1:
                    # Modify the approach for the next iteration
                    if "error" in generation_result:
                        # If there was an error in generation, log it and try again
                        self._logger.warning(f"SQL generation error in iteration {iterations}: {generation_result['error']}")
                    
                    # Regenerate with adjusted parameters
                    generation_result = self._sql_generator.generate_sql(
                        effective_query,
                        query_context,
                        schema_mapping
                    )
                    sql = generation_result["sql"]
                    success = generation_result["success"]
                
                iterations += 1
            
            # Store in query state
            self._update_query_state(query_id, query, effective_query, query_context, schema_mapping, sql, success)
            
            # Update status
            if success:
                self.status = ExecutionStatus.COMPLETED
            else:
                self.status = ExecutionStatus.FAILED
            
            # Return the generated SQL and metadata
            return {
                "query_id": query_id,
                "original_query": query,
                "effective_query": effective_query,
                "sql": sql,
                "schema_mapping": schema_mapping,
                "success": success,
                "iterations": iterations,
                "validation_errors": validation_errors,
                "query_type": query_context.get("intent", "retrieval")
            }
            
        except Exception as e:
            self._logger.error(f"Error generating SQL: {str(e)}")
            self.status = ExecutionStatus.FAILED
            return {
                "query_id": query_id,
                "original_query": query,
                "error": str(e),
                "success": False
            }
    
    def map_query(self, query: str, query_context: Dict[str, Any]) -> Dict[str, Any]:
        """
        Map query entities to database schema elements.
        
        Args:
            query: The query to map
            query_context: The query context with intent and entities
            
        Returns:
            Dictionary with mapping results
        """
        self._logger.debug(f"Mapping query: {query}")
        
        try:
            # Map query entities to schema elements
            schema_mapping = self._schema_mapper.map_query_entities(query_context)
            
            # Validate the mapping
            validation_result = self._schema_mapper.validate_entity_mappings(schema_mapping)
            
            # Return the mapping results
            return {
                "query": query,
                "schema_mapping": schema_mapping,
                "validation": validation_result,
                "tables": self._schema_mapper.get_mapped_tables(schema_mapping),
                "columns": self._schema_mapper.get_mapped_columns(schema_mapping)
            }
            
        except Exception as e:
            self._logger.error(f"Error mapping query: {str(e)}")
            return {
                "query": query,
                "error": str(e),
                "schema_mapping": {}
            }
    
    def validate_sql(self, sql: str, schema_mapping: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """
        Validate a SQL query for correctness and safety.
        
        Args:
            sql: The SQL query to validate
            schema_mapping: Optional schema mapping for additional validation
            
        Returns:
            Dictionary with validation results
        """
        self._logger.debug(f"Validating SQL: {sql}")
        
        try:
            # Validate the SQL
            validation_result = self._sql_validator.validate_sql(sql, schema_mapping)
            
            # If there are errors and auto-fix is enabled, try to fix the SQL
            if not validation_result["is_valid"] and self._auto_fix:
                fix_result = self._sql_validator.suggest_fixes(sql, validation_result)
                if fix_result["can_fix"]:
                    # Validate the fixed SQL
                    fixed_sql = fix_result["fixed_sql"]
                    fixed_validation = self._sql_validator.validate_sql(fixed_sql, schema_mapping)
                    
                    # If the fixed SQL is valid, return it
                    if fixed_validation["is_valid"]:
                        return {
                            "is_valid": True,
                            "sql": fixed_sql,
                            "original_sql": sql,
                            "fixes_applied": fix_result.get("fixes_applied", []),
                            "validation_method": fixed_validation["validation_method"]
                        }
                    
                    # Otherwise, return the original validation result with fix suggestions
                    validation_result["fix_suggestions"] = fix_result["suggestions"]
            
            # Return the validation result
            return validation_result
            
        except Exception as e:
            self._logger.error(f"Error validating SQL: {str(e)}")
            return {
                "is_valid": False,
                "error": str(e),
                "errors": [{
                    "type": "validation_error",
                    "message": str(e),
                    "severity": "error"
                }]
            }
    
    def _extract_context_from_rag(self, context: Optional[List[Dict[str, Any]]]) -> Dict[str, Any]:
        """
        Extract relevant information from RAG context.
        
        Args:
            context: RAG context documents
            
        Returns:
            Dictionary with extracted context
        """
        if not context:
            return {}
        
        extracted = {
            "tables": {},
            "columns": {},
            "relationships": [],
            "examples": []
        }
        
        for doc in context:
            content = doc.get("content", "")
            metadata = doc.get("metadata", {})
            doc_type = metadata.get("type")
            
            # Extract table information
            if doc_type == "table":
                table = metadata.get("table")
                if table:
                    extracted["tables"][table] = {
                        "description": metadata.get("description", ""),
                        "source": metadata.get("source", "")
                    }
            
            # Extract column information
            elif doc_type == "column":
                table = metadata.get("table")
                column = metadata.get("column")
                if table and column:
                    if table not in extracted["columns"]:
                        extracted["columns"][table] = {}
                    
                    extracted["columns"][table][column] = {
                        "description": metadata.get("description", ""),
                        "data_type": metadata.get("data_type", ""),
                        "business_terms": metadata.get("business_terms", [])
                    }
            
            # Extract relationship information
            elif doc_type == "relationship":
                source_table = metadata.get("source_table")
                source_column = metadata.get("source_column")
                target_table = metadata.get("target_table")
                target_column = metadata.get("target_column")
                
                if source_table and source_column and target_table and target_column:
                    extracted["relationships"].append({
                        "source_table": source_table,
                        "source_column": source_column,
                        "target_table": target_table,
                        "target_column": target_column,
                        "relationship_type": metadata.get("relationship_type", "")
                    })
            
            # Extract SQL examples
            elif doc_type == "example":
                # Try to extract SQL from the content
                sql_match = re.search(r'SQL:\s*(.*?)(?:\n\n|$)', content, re.DOTALL)
                if sql_match:
                    sql = sql_match.group(1).strip()
                    question = metadata.get("question", "")
                    
                    if sql and question:
                        extracted["examples"].append({
                            "question": question,
                            "sql": sql
                        })
        
        return extracted
    
    def _enhance_mapping_with_context(self, schema_mapping: Dict[str, Any], 
                                    context: Dict[str, Any]) -> None:
        """
        Enhance schema mapping with context from RAG.
        
        Args:
            schema_mapping: The schema mapping to enhance
            context: The extracted context from RAG
        """
        # Add tables from context if not already in mapping
        for table_name, table_info in context.get("tables", {}).items():
            # Check if this table is already in the mapping
            if not any(t.get("table") == table_name for t in schema_mapping.get("tables", [])):
                # Add to the mapping with a lower confidence
                schema_mapping.setdefault("tables", []).append({
                    "entity": table_name,
                    "table": table_name,
                    "match_type": "context",
                    "confidence": 0.7
                })
        
        # Add columns from context if not already in mapping
        for table_name, table_columns in context.get("columns", {}).items():
            for column_name, column_info in table_columns.items():
                # Check if this column is already in the mapping
                if not any(c.get("table") == table_name and c.get("column") == column_name
                          for c in schema_mapping.get("columns", [])):
                    # Add to the mapping with a lower confidence
                    schema_mapping.setdefault("columns", []).append({
                        "entity": column_name,
                        "table": table_name,
                        "column": column_name,
                        "match_type": "context",
                        "confidence": 0.7
                    })
        
        # Add relationships from context if not already in mapping
        for relationship in context.get("relationships", []):
            source_table = relationship.get("source_table")
            source_column = relationship.get("source_column")
            target_table = relationship.get("target_table")
            target_column = relationship.get("target_column")
            
            # Check if this relationship is already in the mapping
            if source_table and source_column and target_table and target_column:
                if not any(j.get("from_table") == source_table and j.get("from_column") == source_column and
                          j.get("to_table") == target_table and j.get("to_column") == target_column
                          for j in schema_mapping.get("joins", [])):
                    # Add to the mapping
                    schema_mapping.setdefault("joins", []).append({
                        "from_table": source_table,
                        "from_column": source_column,
                        "to_table": target_table,
                        "to_column": target_column,
                        "join_type": "INNER JOIN",
                        "match_type": "context"
                    })
    
    def _update_query_state(self, query_id: str, query: str, effective_query: str,
                          query_context: Dict[str, Any], schema_mapping: Dict[str, Any],
                          sql: str, success: bool) -> None:
        """
        Update the query state with SQL generation information.
        
        Args:
            query_id: The query ID
            query: The original query
            effective_query: The query used for SQL generation
            query_context: The query context
            schema_mapping: The schema mapping
            sql: The generated SQL
            success: Whether SQL generation was successful
        """
        # Get the query state
        query_state = self._state_manager.get_query_state(query_id)
        
        # If no existing state, create one
        if not query_state:
            self._state_manager.create_query_state(query_id, {
                "raw_query": query,
                "timestamp": asyncio.get_event_loop().time()
            })
            query_state = self._state_manager.get_query_state(query_id)
        
        # Update the state
        state_updates = {
            "effective_query": effective_query,
            "generated_sql": sql,
            "sql_generation_success": success,
            "schema_mapping": schema_mapping
        }
        
        # Update the state
        self._state_manager.update_query_state(query_id, state_updates)
    
    def get_capabilities(self) -> List[str]:
        """
        Return a list of capabilities this agent provides.
        
        Returns:
            List of capability strings
        """
        return [
            "sql_generation",
            "schema_mapping",
            "sql_validation",
            "query_analysis"
        ]
    
    def get_status(self) -> Dict[str, Any]:
        """
        Get the current status of this agent.
        
        Returns:
            A dictionary with status information
        """
        return {
            "agent_id": self.agent_id,
            "agent_type": self.agent_type,
            "status": self.status,
            "initialized": self._initialized,
            "schema_loaded": bool(self._schema),
            "mappings_loaded": bool(self._mappings)
        }
    
    async def shutdown(self) -> bool:
        """
        Perform cleanup when shutting down the agent.
        
        Returns:
            True if shutdown was successful, False otherwise
        """
        try:
            # Unregister from the event bus
            self._event_bus.unregister_agent(AgentType.SQL)
            
            return True
            
        except Exception as e:
            self._logger.error(f"Error shutting down SQL agent: {str(e)}")
            return False