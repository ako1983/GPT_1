"""
SQL Validator Module

This module validates SQL queries for syntax, semantics, and security.
It ensures that generated SQL is accurate and safe to execute.
"""

import logging
import re
from typing import Dict, List, Any, Optional, Set, Tuple, Union
import sqlparse
import json
import sqlite3
from google.cloud import bigquery
from google.cloud.exceptions import BadRequest
import sqlparse

class SQLValidator:
    """
    Validates SQL queries for correctness and safety.
    
    The SQLValidator:
    1. Checks SQL syntax for errors
    2. Validates table and column references against schema
    3. Identifies potential security issues like SQL injection
    4. Ensures proper join conditions
    5. Validates aggregation and grouping
    """
    
    def __init__(self, config: Dict[str, Any] = None):
        """
        Initialize a new SQL validator.
        
        Args:
            config: Configuration parameters
        """
        self._logger = logging.getLogger(__name__)
        self._config = config or {}
        
        # Validation settings
        self._dialect = self._config.get("dialect", "bigquery")
        self._schema = self._config.get("schema", {})
        self._validation_level = self._config.get("validation_level", "strict")
        self._max_query_length = self._config.get("max_query_length", 10000)
        
        # Initialize the validator based on the dialect
        self._initialize_validator()
    
    def _initialize_validator(self) -> None:
        """Initialize the appropriate validator based on the dialect."""
        if self._dialect == "bigquery":
            # Initialize BigQuery client if credentials are provided
            credentials_file = self._config.get("bigquery_credentials")
            project_id = self._config.get("bigquery_project")
            
            if credentials_file:
                import os
                os.environ["GOOGLE_APPLICATION_CREDENTIALS"] = credentials_file
            
            if project_id:
                self._client = bigquery.Client(project=project_id)
            else:
                # Initialize without explicit project, using credentials
                self._client = bigquery.Client()
        
        elif self._dialect == "sqlite":
            # For testing purposes, use in-memory SQLite database
            self._connection = sqlite3.connect(":memory:")
            self._cursor = self._connection.cursor()
            
            # Create tables from schema for validation
            self._create_sqlite_schema()
    
    def _create_sqlite_schema(self) -> None:
        """Create SQLite schema for validation based on the provided schema."""
        if not self._schema or "tables" not in self._schema:
            self._logger.warning("No schema provided for SQLite validation")
            return
        
        try:
            # Create tables based on schema
            for table_name, table_info in self._schema.get("tables", {}).items():
                columns = table_info.get("columns", {})
                
                # Generate CREATE TABLE statement
                column_defs = []
                for col_name, col_info in columns.items():
                    col_type = col_info.get("type", "TEXT")
                    col_def = f"{col_name} {self._map_type_to_sqlite(col_type)}"
                    column_defs.append(col_def)
                
                # Add primary key if specified
                if "primary_key" in table_info:
                    pk_cols = table_info["primary_key"]
                    if isinstance(pk_cols, list):
                        pk_clause = f"PRIMARY KEY ({', '.join(pk_cols)})"
                    else:
                        pk_clause = f"PRIMARY KEY ({pk_cols})"
                    column_defs.append(pk_clause)
                
                # Create the table
                create_stmt = f"CREATE TABLE IF NOT EXISTS {table_name} ({', '.join(column_defs)})"
                self._cursor.execute(create_stmt)
            
            # Create indexes and foreign keys if needed
            for relationship in self._schema.get("relationships", []):
                source_table = relationship.get("source_table")
                source_column = relationship.get("source_column")
                target_table = relationship.get("target_table")
                target_column = relationship.get("target_column")
                
                if source_table and source_column and target_table and target_column:
                    # Create an index on the source column
                    index_name = f"idx_{source_table}_{source_column}"
                    self._cursor.execute(f"CREATE INDEX IF NOT EXISTS {index_name} ON {source_table}({source_column})")
            
            self._connection.commit()
            self._logger.info("Created SQLite schema for validation")
            
        except Exception as e:
            self._logger.error(f"Error creating SQLite schema: {str(e)}")
    
    def _map_type_to_sqlite(self, bigquery_type: str) -> str:
        """
        Map BigQuery data types to SQLite data types.
        
        Args:
            bigquery_type: BigQuery data type
            
        Returns:
            Equivalent SQLite data type
        """
        type_map = {
            "INT64": "INTEGER",
            "FLOAT64": "REAL",
            "NUMERIC": "REAL",
            "BOOL": "INTEGER",
            "STRING": "TEXT",
            "BYTES": "BLOB",
            "DATE": "TEXT",
            "DATETIME": "TEXT",
            "TIMESTAMP": "TEXT",
            "TIME": "TEXT",
            "ARRAY": "TEXT",  # Simplified as TEXT for SQLite
            "STRUCT": "TEXT"   # Simplified as TEXT for SQLite
        }
        
        # Default to TEXT if type not found
        return type_map.get(bigquery_type.upper(), "TEXT")
    
    def validate_sql(self, sql: str, schema_mapping: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """
        Validate a SQL query for correctness and safety.
        
        Args:
            sql: The SQL query to validate
            schema_mapping: Optional schema mapping for additional validation
            
        Returns:
            Dictionary with validation results
        """
        self._logger.debug(f"Validating SQL: {sql}")
        
        # Initialize result
        result = {
            "is_valid": True,
            "errors": [],
            "warnings": [],
            "parse_tree": None,
            "referenced_tables": [],
            "referenced_columns": [],
            "validation_method": "syntax_only"
        }
        
        try:
            # Check query length
            if len(sql) > self._max_query_length:
                result["is_valid"] = False
                result["errors"].append({
                    "type": "query_too_long",
                    "message": f"Query exceeds maximum length of {self._max_query_length} characters",
                    "line": 0,
                    "severity": "error"
                })
                return result
            
            # Basic syntax validation
            syntax_result = self._validate_syntax(sql)
            result["is_valid"] = result["is_valid"] and syntax_result["is_valid"]
            result["errors"].extend(syntax_result["errors"])
            result["warnings"].extend(syntax_result["warnings"])
            
            # Parse the SQL query
            parsed = sqlparse.parse(sql)
            if parsed:
                result["parse_tree"] = str(parsed[0])
            
            # Extract referenced tables and columns
            tables, columns = self._extract_references(sql)
            result["referenced_tables"] = tables
            result["referenced_columns"] = columns
            
            # Schema validation if schema is available
            if self._schema and "tables" in self._schema:
                schema_result = self._validate_against_schema(sql, tables, columns)
                result["is_valid"] = result["is_valid"] and schema_result["is_valid"]
                result["errors"].extend(schema_result["errors"])
                result["warnings"].extend(schema_result["warnings"])
                result["validation_method"] = "schema"
            
            # Additional validation using the appropriate dialect validator
            if self._dialect == "bigquery" and hasattr(self, "_client"):
                dialect_result = self._validate_with_bigquery(sql)
                result["is_valid"] = result["is_valid"] and dialect_result["is_valid"]
                result["errors"].extend(dialect_result["errors"])
                result["warnings"].extend(dialect_result["warnings"])
                result["validation_method"] = "bigquery_api"
            
            elif self._dialect == "sqlite" and hasattr(self, "_connection"):
                dialect_result = self._validate_with_sqlite(sql)
                result["is_valid"] = result["is_valid"] and dialect_result["is_valid"]
                result["errors"].extend(dialect_result["errors"])
                result["warnings"].extend(dialect_result["warnings"])
                result["validation_method"] = "sqlite"
            
            # Security validation
            security_result = self._validate_security(sql)
            result["is_valid"] = result["is_valid"] and security_result["is_valid"]
            result["errors"].extend(security_result["errors"])
            result["warnings"].extend(security_result["warnings"])
            
            return result
            
        except Exception as e:
            self._logger.error(f"Error validating SQL: {str(e)}")
            result["is_valid"] = False
            result["errors"].append({
                "type": "validation_error",
                "message": f"Error during validation: {str(e)}",
                "line": 0,
                "severity": "error"
            })
            return result
    
    def _validate_syntax(self, sql: str) -> Dict[str, Any]:
        """
        Validate SQL syntax using sqlparse.
        
        Args:
            sql: The SQL query to validate
            
        Returns:
            Dictionary with syntax validation results
        """
        result = {
            "is_valid": True,
            "errors": [],
            "warnings": []
        }
        
        try:
            # Parse the SQL query
            parsed = sqlparse.parse(sql)
            
            if not parsed:
                result["is_valid"] = False
                result["errors"].append({
                    "type": "syntax_error",
                    "message": "Failed to parse SQL query",
                    "line": 0,
                    "severity": "error"
                })
                return result
            
            # Check for basic structural elements
            stmt = parsed[0]
            
            # Check if it's a SELECT query
            if stmt.get_type() != "SELECT":
                result["warnings"].append({
                    "type": "non_select_query",
                    "message": f"Query is a {stmt.get_type()} statement, expected SELECT",
                    "line": 0,
                    "severity": "warning"
                })
            
            # Check for required clauses in SELECT queries
            if stmt.get_type() == "SELECT":
                # Find the FROM clause
                from_seen = False
                for token in stmt.tokens:
                    if token.is_keyword and token.value.upper() == "FROM":
                        from_seen = True
                        break
                
                if not from_seen:
                    result["is_valid"] = False
                    result["errors"].append({
                        "type": "syntax_error",
                        "message": "SELECT query missing FROM clause",
                        "line": 0,
                        "severity": "error"
                    })
            
            # Basic parenthesis matching
            if sql.count('(') != sql.count(')'):
                result["is_valid"] = False
                result["errors"].append({
                    "type": "syntax_error",
                    "message": "Unmatched parentheses in query",
                    "line": 0,
                    "severity": "error"
                })
            
            # Check for unclosed quotes
            quote_chars = ["'", "\""]
            for quote_char in quote_chars:
                if sql.count(quote_char) % 2 != 0:
                    result["is_valid"] = False
                    result["errors"].append({
                        "type": "syntax_error",
                        "message": f"Unclosed {quote_char} quote in query",
                        "line": 0,
                        "severity": "error"
                    })
            
            return result
            
        except Exception as e:
            result["is_valid"] = False
            result["errors"].append({
                "type": "syntax_error",
                "message": f"Error parsing SQL: {str(e)}",
                "line": 0,
                "severity": "error"
            })
            return result
    
    def _extract_references(self, sql: str) -> Tuple[List[str], List[Dict[str, str]]]:
        """
        Extract table and column references from a SQL query.
        
        Args:
            sql: The SQL query
            
        Returns:
            Tuple of (table_list, column_list)
        """
        tables = []
        columns = []
        
        try:
            # Parse the SQL query
            parsed = sqlparse.parse(sql)
            
            if not parsed:
                return tables, columns
            
            stmt = parsed[0]
            
            # Extract table references
            from_seen = False
            current_table = None
            
            for token in stmt.flatten():
                # Track when we see the FROM clause
                if token.is_keyword and token.value.upper() == "FROM":
                    from_seen = True
                    continue
                
                # After FROM, the next identifier is likely a table
                if from_seen and token.ttype is None and token.is_identifier:
                    tables.append(token.value)
                    from_seen = False
                    current_table = token.value
                
                # Look for JOIN clauses
                if token.is_keyword and "JOIN" in token.value.upper():
                    from_seen = True
                
                # Extract column references
                if token.is_identifier and "." in token.value:
                    parts = token.value.split(".")
                    if len(parts) == 2:
                        table, column = parts
                        columns.append({"table": table, "column": column})
                
                # Extract bare column references if we know the current table
                elif token.is_identifier and current_table and token.value not in tables:
                    columns.append({"table": current_table, "column": token.value})
            
            # Remove duplicates while preserving order
            unique_tables = []
            for table in tables:
                if table not in unique_tables:
                    unique_tables.append(table)
            
            unique_columns = []
            column_strings = set()
            for column in columns:
                column_str = f"{column['table']}.{column['column']}"
                if column_str not in column_strings:
                    unique_columns.append(column)
                    column_strings.add(column_str)
            
            return unique_tables, unique_columns
            
        except Exception as e:
            self._logger.error(f"Error extracting references: {str(e)}")
            return tables, columns
    
    def _validate_against_schema(self, sql: str, tables: List[str], 
                               columns: List[Dict[str, str]]) -> Dict[str, Any]:
        """
        Validate SQL against the schema.
        
        Args:
            sql: The SQL query
            tables: List of referenced tables
            columns: List of referenced columns
            
        Returns:
            Dictionary with schema validation results
        """
        result = {
            "is_valid": True,
            "errors": [],
            "warnings": []
        }
        
        # Validate tables
        for table in tables:
            if table not in self._schema.get("tables", {}):
                result["is_valid"] = False
                result["errors"].append({
                    "type": "schema_error",
                    "message": f"Referenced table '{table}' not found in schema",
                    "line": 0,
                    "severity": "error"
                })
        
        # Validate columns
        for column in columns:
            table = column["table"]
            col = column["column"]
            
            if table in self._schema.get("tables", {}):
                if col not in self._schema["tables"][table].get("columns", {}):
                    result["is_valid"] = False
                    result["errors"].append({
                        "type": "schema_error",
                        "message": f"Referenced column '{col}' not found in table '{table}'",
                        "line": 0,
                        "severity": "error"
                    })
            
        # Validate joins if needed
        if len(tables) > 1:
            join_result = self._validate_joins(tables)
            result["is_valid"] = result["is_valid"] and join_result["is_valid"]
            result["errors"].extend(join_result["errors"])
            result["warnings"].extend(join_result["warnings"])
        
        return result
    
    def _validate_joins(self, tables: List[str]) -> Dict[str, Any]:
        """
        Validate that proper joins exist between tables.
        
        Args:
            tables: List of tables to validate joins for
            
        Returns:
            Dictionary with join validation results
        """
        result = {
            "is_valid": True,
            "errors": [],
            "warnings": []
        }
        
        # Skip if no relationships defined
        if "relationships" not in self._schema:
            result["warnings"].append({
                "type": "missing_relationships",
                "message": "No relationships defined in schema, cannot validate joins",
                "line": 0,
                "severity": "warning"
            })
            return result
        
        # Check if tables can be joined
        remaining_tables = set(tables[1:])  # Skip the first table
        joined_tables = {tables[0]}  # Start with the first table
        
        while remaining_tables and len(joined_tables) < len(tables):
            found_join = False
            
            for relationship in self._schema["relationships"]:
                source_table = relationship.get("source_table")
                target_table = relationship.get("target_table")
                
                # Check if this relationship connects a joined table with a remaining table
                if source_table in joined_tables and target_table in remaining_tables:
                    joined_tables.add(target_table)
                    remaining_tables.remove(target_table)
                    found_join = True
                    break
                elif target_table in joined_tables and source_table in remaining_tables:
                    joined_tables.add(source_table)
                    remaining_tables.remove(source_table)
                    found_join = True
                    break
            
            # If no join found, break the loop
            if not found_join:
                break
        
        # If we still have remaining tables, they can't be joined
        if remaining_tables:
            result["is_valid"] = False
            for table in remaining_tables:
                result["errors"].append({
                    "type": "join_error",
                    "message": f"No valid join path found to table '{table}'",
                    "line": 0,
                    "severity": "error"
                })
        
        return result
    
    def _validate_with_bigquery(self, sql: str) -> Dict[str, Any]:
        """
        Validate SQL using BigQuery's dry run feature.
        
        Args:
            sql: The SQL query to validate
            
        Returns:
            Dictionary with BigQuery validation results
        """
        result = {
            "is_valid": True,
            "errors": [],
            "warnings": []
        }
        
        try:
            # Create a query job config for dry run
            job_config = bigquery.QueryJobConfig(dry_run=True, use_query_cache=False)
            
            # Start the query job
            query_job = self._client.query(sql, job_config=job_config)
            
            # If we get here, the query is valid (dry run succeeded)
            result["warnings"].append({
                "type": "bigquery_validation",
                "message": f"Query would process approximately {query_job.total_bytes_processed} bytes",
                "line": 0,
                "severity": "info"
            })
            
        except BadRequest as e:
            # Bad request usually means a syntax or schema error
            result["is_valid"] = False
            
            # Parse the error message
            error_message = str(e)
            line_match = re.search(r'at \[(\d+):(\d+)\]', error_message)
            line = 0
            if line_match:
                line = int(line_match.group(1))
            
            result["errors"].append({
                "type": "bigquery_error",
                "message": error_message,
                "line": line,
                "severity": "error"
            })
            
        except Exception as e:
            # Other errors
            result["is_valid"] = False
            result["errors"].append({
                "type": "bigquery_error",
                "message": f"Error validating with BigQuery: {str(e)}",
                "line": 0,
                "severity": "error"
            })
        
        return result
    
    def _validate_with_sqlite(self, sql: str) -> Dict[str, Any]:
        """
        Validate SQL using SQLite.
        
        Args:
            sql: The SQL query to validate
            
        Returns:
            Dictionary with SQLite validation results
        """
        result = {
            "is_valid": True,
            "errors": [],
            "warnings": []
        }
        
        try:
            # Replace BigQuery-specific syntax with SQLite-compatible syntax
            sqlite_sql = self._adapt_sql_for_sqlite(sql)
            
            # Execute the query with SQLite's parser
            self._cursor.execute(f"EXPLAIN {sqlite_sql}")
            
            # If we get here, the query is valid (no syntax error)
            
        except sqlite3.OperationalError as e:
            # Operational error usually means a syntax or schema error
            result["is_valid"] = False
            result["errors"].append({
                "type": "sqlite_error",
                "message": str(e),
                "line": 0,
                "severity": "error"
            })
            
        except Exception as e:
            # Other errors
            result["is_valid"] = False
            result["errors"].append({
                "type": "sqlite_error",
                "message": f"Error validating with SQLite: {str(e)}",
                "line": 0,
                "severity": "error"
            })
        
        return result
    
    def _adapt_sql_for_sqlite(self, sql: str) -> str:
        """
        Adapt BigQuery SQL to SQLite syntax for validation.
        
        Args:
            sql: The BigQuery SQL query
            
        Returns:
            SQLite-compatible SQL query
        """
        # Parse the SQL query
        parsed = sqlparse.parse(sql)
        if not parsed:
            return sql
        
        # Get the statement
        stmt = parsed[0]
        
        # Convert to string and apply replacements
        sqlite_sql = str(stmt)
        
        # Replace BigQuery-specific functions with SQLite equivalents
        replacements = [
            (r'TIMESTAMP\([^)]+\)', 'DATETIME'),
            (r'ARRAY\([^)]+\)', 'JSON'),
            (r'STRUCT\([^)]+\)', 'JSON'),
            (r'DATE\([^)]+\)', 'DATE'),
            (r'DATETIME\([^)]+\)', 'DATETIME'),
            (r'UNNEST\([^)]+\)', 'JSON_EACH'),
            (r'INT64', 'INTEGER'),
            (r'FLOAT64', 'REAL'),
            (r'BOOL', 'INTEGER'),
            (r'STRING', 'TEXT')
        ]
        
        for pattern, replacement in replacements:
            sqlite_sql = re.sub(pattern, replacement, sqlite_sql, flags=re.IGNORECASE)
        
        return sqlite_sql
    
    def _validate_security(self, sql: str) -> Dict[str, Any]:
        """
        Validate SQL for security issues.
        
        Args:
            sql: The SQL query to validate
            
        Returns:
            Dictionary with security validation results
        """
        result = {
            "is_valid": True,
            "errors": [],
            "warnings": []
        }
        
        # Check for comments (could be used to hide malicious code)
        if "--" in sql or "/*" in sql:
            result["warnings"].append({
                "type": "security_warning",
                "message": "Query contains comments which could be used to hide malicious code",
                "line": 0,
                "severity": "warning"
            })
        
        # Check for multiple statements (could be used for injection)
        if ";" in sql[:-1]:  # Ignore trailing semicolon
            result["warnings"].append({
                "type": "security_warning",
                "message": "Query contains multiple statements which could be used for injection",
                "line": 0,
                "severity": "warning"
            })
        
        # Check for typical SQL injection patterns
        injection_patterns = [
            r'\bOR\s+1\s*=\s*1\b',
            r'\bOR\s+\'[^\']*\'\s*=\s*\'[^\']*\'\b',
            r'\bDROP\s+TABLE\b',
            r'\bDELETE\s+FROM\b',
            r'\bINSERT\s+INTO\b',
            r'\bUPDATE\s+.+\s+SET\b',
            r'\bALTER\s+TABLE\b',
            r'\bEXEC\b',
            r'\bXP_\w+\b'
        ]
        
        for pattern in injection_patterns:
            if re.search(pattern, sql, re.IGNORECASE):
                result["is_valid"] = False
                result["errors"].append({
                    "type": "security_error",
                    "message": f"Query contains potential SQL injection pattern: {pattern}",
                    "line": 0,
                    "severity": "error"
                })
        
        return result
    
    def suggest_fixes(self, sql: str, validation_result: Dict[str, Any]) -> Dict[str, Any]:
        """
        Suggest fixes for validation errors.
        
        Args:
            sql: The SQL query with errors
            validation_result: The validation result
            
        Returns:
            Dictionary with suggested fixes
        """
        suggestions = {
            "fixed_sql": None,
            "suggestions": [],
            "can_fix": False
        }
        
        # If the query is valid, no fixes needed
        if validation_result["is_valid"]:
            suggestions["can_fix"] = True
            suggestions["fixed_sql"] = sql
            return suggestions
        
        # Try to fix common errors
        fixed_sql = sql
        fixes_applied = []
        
        for error in validation_result["errors"]:
            error_type = error["type"]
            message = error["message"]
            
            # Fix schema errors (table/column not found)
            if error_type == "schema_error" and "not found in schema" in message:
                # Extract the problematic table or column
                if "table" in message:
                    match = re.search(r"table '([^']+)'", message)
                    if match:
                        table = match.group(1)
                        # Suggest similar table names
                        similar_tables = self._find_similar_names(table, list(self._schema.get("tables", {}).keys()))
                        if similar_tables:
                            suggestion = f"Table '{table}' not found. Did you mean: {', '.join(similar_tables)}?"
                            suggestions["suggestions"].append({
                                "error": message,
                                "suggestion": suggestion
                            })
                            
                            # Try to replace the table name
                            if len(similar_tables) == 1:
                                fixed_sql = self._replace_table_name(fixed_sql, table, similar_tables[0])
                                fixes_applied.append(f"Replaced table '{table}' with '{similar_tables[0]}'")
                
                elif "column" in message:
                    match = re.search(r"column '([^']+)' not found in table '([^']+)'", message)
                    if match:
                        column = match.group(1)
                        table = match.group(2)
                        # Suggest similar column names
                        if table in self._schema.get("tables", {}):
                            similar_columns = self._find_similar_names(column, list(self._schema["tables"][table].get("columns", {}).keys()))
                            if similar_columns:
                                suggestion = f"Column '{column}' not found in table '{table}'. Did you mean: {', '.join(similar_columns)}?"
                                suggestions["suggestions"].append({
                                    "error": message,
                                    "suggestion": suggestion
                                })
                                
                                # Try to replace the column name
                                if len(similar_columns) == 1:
                                    fixed_sql = self._replace_column_name(fixed_sql, table, column, similar_columns[0])
                                    fixes_applied.append(f"Replaced column '{column}' with '{similar_columns[0]}' in table '{table}'")
            
            # Fix syntax errors
            elif error_type == "syntax_error":
                if "missing FROM clause" in message:
                    suggestions["suggestions"].append({
                        "error": message,
                        "suggestion": "Add a FROM clause to your query. Example: FROM table_name"
                    })
                
                elif "Unmatched parentheses" in message:
                    # Try to balance parentheses
                    fixed_sql = self._balance_parentheses(fixed_sql)
                    fixes_applied.append("Balanced parentheses")
                
                elif "Unclosed" in message and "quote" in message:
                    # Try to fix unclosed quotes
                    fixed_sql = self._fix_unclosed_quotes(fixed_sql)
                    fixes_applied.append("Fixed unclosed quotes")
            
            # Fix join errors
            elif error_type == "join_error":
                match = re.search(r"No valid join path found to table '([^']+)'", message)
                if match:
                    table = match.group(1)
                    # Suggest possible join paths
                    join_paths = self._find_join_paths(table)
                    if join_paths:
                        suggestion = f"No direct join path found to table '{table}'. Possible join paths: {'; '.join(join_paths)}"
                        suggestions["suggestions"].append({
                            "error": message,
                            "suggestion": suggestion
                        })
        
        # Check if we applied any fixes
        if fixes_applied:
            suggestions["can_fix"] = True
            suggestions["fixed_sql"] = fixed_sql
            suggestions["fixes_applied"] = fixes_applied
        
        return suggestions
    
    def _find_similar_names(self, name: str, candidates: List[str], threshold: int = 70) -> List[str]:
        """
        Find similar names using Levenshtein distance.
        
        Args:
            name: The name to find similar matches for
            candidates: List of candidate names
            threshold: Similarity threshold (0-100)
            
        Returns:
            List of similar names
        """
        try:
            from fuzzywuzzy import fuzz
            
            similar = []
            for candidate in candidates:
                similarity = fuzz.ratio(name.lower(), candidate.lower())
                if similarity >= threshold:
                    similar.append((candidate, similarity))
            
            # Sort by similarity (highest first) and return names only
            similar.sort(key=lambda x: x[1], reverse=True)
            return [s[0] for s in similar[:3]]  # Return top 3
            
        except ImportError:
            # Fallback to simple string matching if fuzzywuzzy not available
            return [c for c in candidates if name.lower() in c.lower() or c.lower() in name.lower()]
    
    def _replace_table_name(self, sql: str, old_table: str, new_table: str) -> str:
        """
        Replace a table name in a SQL query.
        
        Args:
            sql: The SQL query
            old_table: The table name to replace
            new_table: The new table name
            
        Returns:
            Updated SQL query
        """
        # Use regex with word boundaries to replace only whole table names
        pattern = r'\b' + re.escape(old_table) + r'\b'
        return re.sub(pattern, new_table, sql)
    
    def _replace_column_name(self, sql: str, table: str, old_column: str, new_column: str) -> str:
        """
        Replace a column name in a SQL query.
        
        Args:
            sql: The SQL query
            table: The table containing the column
            old_column: The column name to replace
            new_column: The new column name
            
        Returns:
            Updated SQL query
        """
        # Replace table.column references
        pattern1 = re.escape(table) + r'\.' + re.escape(old_column)
        sql = re.sub(pattern1, f"{table}.{new_column}", sql)
        
        # Also try to replace bare column references
        pattern2 = r'\b' + re.escape(old_column) + r'\b'
        
        # Extract all table aliases
        aliases = {}
        alias_pattern = r'\b(' + re.escape(table) + r')\s+(?:AS\s+)?([a-zA-Z][a-zA-Z0-9_]*)\b'
        for match in re.finditer(alias_pattern, sql, re.IGNORECASE):
            aliases[match.group(2)] = match.group(1)
        
        # Replace column references with aliases
        for alias in aliases:
            pattern3 = re.escape(alias) + r'\.' + re.escape(old_column)
            sql = re.sub(pattern3, f"{alias}.{new_column}", sql)
        
        return sql
    
    def _balance_parentheses(self, sql: str) -> str:
        """
        Balance parentheses in a SQL query.
        
        Args:
            sql: The SQL query
            
        Returns:
            SQL query with balanced parentheses
        """
        # Count open and close parentheses
        open_count = sql.count('(')
        close_count = sql.count(')')
        
        # Add missing closing parentheses
        if open_count > close_count:
            sql = sql + ')' * (open_count - close_count)
        
        # Add missing opening parentheses (at the beginning)
        elif close_count > open_count:
            sql = '(' * (close_count - open_count) + sql
        
        return sql
    
    def _fix_unclosed_quotes(self, sql: str) -> str:
        """
        Fix unclosed quotes in a SQL query.
        
        Args:
            sql: The SQL query
            
        Returns:
            SQL query with fixed quotes
        """
        # Check and fix single quotes
        if sql.count("'") % 2 != 0:
            sql = sql + "'"
        
        # Check and fix double quotes
        if sql.count("\"") % 2 != 0:
            sql = sql + "\""
        
        return sql
    
    def _find_join_paths(self, target_table: str) -> List[str]:
        """
        Find possible join paths to a target table.
        
        Args:
            target_table: The table to find join paths for
            
        Returns:
            List of join path descriptions
        """
        join_paths = []
        
        if "relationships" not in self._schema:
            return join_paths
        
        # Build a graph of table relationships
        graph = {}
        for relationship in self._schema["relationships"]:
            source = relationship.get("source_table")
            target = relationship.get("target_table")
            source_col = relationship.get("source_column")
            target_col = relationship.get("target_column")
            
            if source and target and source_col and target_col:
                if source not in graph:
                    graph[source] = []
                if target not in graph:
                    graph[target] = []
                
                graph[source].append((target, f"{source}.{source_col} = {target}.{target_col}"))
                graph[target].append((source, f"{target}.{target_col} = {source}.{source_col}"))
        
        # Find all tables in the schema
        all_tables = list(self._schema.get("tables", {}).keys())
        
        # Find direct join paths
        for table in all_tables:
            if table in graph and target_table in graph:
                for neighbor, join_condition in graph[table]:
                    if neighbor == target_table:
                        join_paths.append(f"JOIN {target_table} ON {join_condition}")
        
        # Find two-step join paths if no direct paths
        if not join_paths:
            for table in all_tables:
                if table in graph:
                    for intermediate, join1 in graph[table]:
                        if intermediate in graph:
                            for final, join2 in graph[intermediate]:
                                if final == target_table:
                                    join_paths.append(
                                        f"JOIN {intermediate} ON {join1}, then JOIN {target_table} ON {join2}"
                                    )
        
        return join_paths