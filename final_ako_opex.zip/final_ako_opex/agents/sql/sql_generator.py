"""
SQL Generator Module

This module generates SQL queries based on user queries and mapped schema elements.
It handles the translation from natural language to SQL with a focus on accuracy.
"""

import logging
import re
from typing import Dict, List, Any, Optional, Set, Tuple
import json
import sqlparse

class SQLGenerator:
    """
    Generates SQL queries from natural language and schema mappings.
    
    The SQLGenerator:
    1. Translates user intents to SQL query structures
    2. Uses schema mappings to generate accurate column and table references
    3. Handles different query types (aggregation, comparison, retrieval)
    4. Generates joins between tables when needed
    5. Formats and optimizes the generated SQL
    """
    
    def __init__(self, config: Dict[str, Any] = None):
        """
        Initialize a new SQL generator.
        
        Args:
            config: Configuration parameters
        """
        self._logger = logging.getLogger(__name__)
        self._config = config or {}
        
        # SQL generation settings
        self._dialect = self._config.get("dialect", "bigquery")
        self._format_sql = self._config.get("format_sql", True)
        self._add_comments = self._config.get("add_comments", True)
        self._max_limit = self._config.get("max_limit", 1000)
        
        # Load templates if provided
        self._templates = self._config.get("templates", {})
        if not self._templates:
            self._load_default_templates()
    
    def _load_default_templates(self) -> None:
        """Load default SQL templates for different query types."""
        self._templates = {
            "aggregation": {
                "template": """
                    SELECT {select_clause}
                    FROM {from_clause}
                    {join_clause}
                    {where_clause}
                    {group_by_clause}
                    {order_by_clause}
                    {limit_clause}
                """,
                "placeholders": {
                    "select_clause": "SELECT_AGGREGATION",
                    "from_clause": "FROM_CLAUSE",
                    "join_clause": "JOIN_CLAUSE",
                    "where_clause": "WHERE_CLAUSE",
                    "group_by_clause": "GROUP_BY_CLAUSE",
                    "order_by_clause": "ORDER_BY_CLAUSE",
                    "limit_clause": "LIMIT_CLAUSE"
                }
            },
            "comparison": {
                "template": """
                    SELECT {select_clause}
                    FROM {from_clause}
                    {join_clause}
                    {where_clause}
                    {group_by_clause}
                    {order_by_clause}
                    {limit_clause}
                """,
                "placeholders": {
                    "select_clause": "SELECT_COMPARISON",
                    "from_clause": "FROM_CLAUSE",
                    "join_clause": "JOIN_CLAUSE",
                    "where_clause": "WHERE_CLAUSE",
                    "group_by_clause": "GROUP_BY_CLAUSE",
                    "order_by_clause": "ORDER_BY_CLAUSE",
                    "limit_clause": "LIMIT_CLAUSE"
                }
            },
            "trend_analysis": {
                "template": """
                    SELECT {select_clause}
                    FROM {from_clause}
                    {join_clause}
                    {where_clause}
                    {group_by_clause}
                    {order_by_clause}
                    {limit_clause}
                """,
                "placeholders": {
                    "select_clause": "SELECT_TREND",
                    "from_clause": "FROM_CLAUSE",
                    "join_clause": "JOIN_CLAUSE",
                    "where_clause": "WHERE_CLAUSE",
                    "group_by_clause": "GROUP_BY_CLAUSE",
                    "order_by_clause": "ORDER_BY_TREND",
                    "limit_clause": "LIMIT_CLAUSE"
                }
            },
            "retrieval": {
                "template": """
                    SELECT {select_clause}
                    FROM {from_clause}
                    {join_clause}
                    {where_clause}
                    {order_by_clause}
                    {limit_clause}
                """,
                "placeholders": {
                    "select_clause": "SELECT_RETRIEVAL",
                    "from_clause": "FROM_CLAUSE",
                    "join_clause": "JOIN_CLAUSE",
                    "where_clause": "WHERE_CLAUSE",
                    "order_by_clause": "ORDER_BY_CLAUSE",
                    "limit_clause": "LIMIT_CLAUSE"
                }
            }
        }
    
    def generate_sql(self, query: str, query_context: Dict[str, Any], 
                    schema_mapping: Dict[str, Any]) -> Dict[str, Any]:
        """
        Generate a SQL query based on the user query and schema mapping.
        
        Args:
            query: The original user query
            query_context: The query context with intent and entities
            schema_mapping: The schema mapping result
            
        Returns:
            Dictionary with generated SQL and metadata
        """
        self._logger.debug(f"Generating SQL for query: {query}")
        
        try:
            # Determine the query type/intent
            intent = query_context.get("intent", "retrieval")
            
            # Select the appropriate template
            template_info = self._templates.get(intent, self._templates["retrieval"])
            template = template_info["template"]
            placeholders = template_info["placeholders"]
            
            # Generate each clause
            select_clause = self._generate_select_clause(query_context, schema_mapping, intent)
            from_clause = self._generate_from_clause(schema_mapping)
            join_clause = self._generate_join_clause(schema_mapping)
            where_clause = self._generate_where_clause(query_context, schema_mapping)
            group_by_clause = self._generate_group_by_clause(query_context, schema_mapping, intent)
            order_by_clause = self._generate_order_by_clause(query_context, schema_mapping, intent)
            limit_clause = self._generate_limit_clause()
            
            # Fill the template with generated clauses
            sql = template.format(
                select_clause=select_clause,
                from_clause=from_clause,
                join_clause=join_clause,
                where_clause=where_clause,
                group_by_clause=group_by_clause,
                order_by_clause=order_by_clause,
                limit_clause=limit_clause
            )
            
            # Format the SQL if enabled
            if self._format_sql:
                sql = self._format_sql_query(sql)
            
            # Add header comment if enabled
            if self._add_comments:
                sql = self._add_header_comment(sql, query)
            
            # Create the result dictionary
            result = {
                "sql": sql,
                "query_type": intent,
                "tables": self._get_tables_from_mapping(schema_mapping),
                "columns": self._get_columns_from_mapping(schema_mapping),
                "conditions": self._get_conditions_from_mapping(schema_mapping),
                "success": True
            }
            
            return result
            
        except Exception as e:
            self._logger.error(f"Error generating SQL: {str(e)}")
            return {
                "sql": "",
                "error": str(e),
                "success": False
            }
    
    def _generate_select_clause(self, query_context: Dict[str, Any], 
                              schema_mapping: Dict[str, Any], intent: str) -> str:
        """
        Generate the SELECT clause of the SQL query.
        
        Args:
            query_context: The query context
            schema_mapping: The schema mapping result
            intent: The query intent
            
        Returns:
            The SELECT clause string
        """
        select_items = []
        
        # Get the mapped columns
        columns = schema_mapping.get("columns", [])
        
        # For aggregation queries
        if intent == "aggregation":
            for column in columns:
                table = column.get("table")
                col = column.get("column")
                aggregation = column.get("aggregation", "SUM")  # Default to SUM for aggregation intent
                
                if table and col:
                    select_items.append(f"{aggregation}({table}.{col}) AS {col}_{aggregation.lower()}")
        
        # For comparison queries
        elif intent == "comparison":
            # Add columns for comparison
            for column in columns:
                table = column.get("table")
                col = column.get("column")
                
                if table and col:
                    select_items.append(f"{table}.{col}")
            
            # Add comparison basis if present
            comparison = query_context.get("comparison")
            if comparison and "basis" in comparison:
                # The comparison basis might need special handling
                # For now, just add a comment
                select_items.append(f"/* Comparison with {comparison['basis']} */")
        
        # For trend analysis queries
        elif intent == "trend_analysis":
            # Add time-related columns first
            time_columns = []
            for condition in schema_mapping.get("conditions", []):
                table = condition.get("table")
                for cond in condition.get("conditions", []):
                    column = cond.get("column")
                    if table and column and any(time_term in column.lower() for time_term in 
                                              ["date", "time", "year", "quarter", "month", "day"]):
                        time_columns.append(f"{table}.{column}")
            
            # Add time columns to select
            select_items.extend(time_columns)
            
            # Add metric columns
            for column in columns:
                table = column.get("table")
                col = column.get("column")
                aggregation = column.get("aggregation")
                
                if table and col:
                    if aggregation:
                        select_items.append(f"{aggregation}({table}.{col}) AS {col}_{aggregation.lower()}")
                    else:
                        select_items.append(f"{table}.{col}")
        
        # For retrieval queries (default)
        else:
            # If no specific columns are mapped, use *
            if not columns:
                # Use the first table from mapping or a placeholder
                tables = self._get_tables_from_mapping(schema_mapping)
                if tables:
                    select_items.append(f"{tables[0]}.*")
                else:
                    select_items.append("*")
            else:
                # Add each mapped column
                for column in columns:
                    table = column.get("table")
                    col = column.get("column")
                    aggregation = column.get("aggregation")
                    
                    if table and col:
                        if aggregation:
                            select_items.append(f"{aggregation}({table}.{col}) AS {col}_{aggregation.lower()}")
                        else:
                            select_items.append(f"{table}.{col}")
        
        # If no select items were added, use * as a fallback
        if not select_items:
            tables = self._get_tables_from_mapping(schema_mapping)
            if tables:
                select_items.append(f"{tables[0]}.*")
            else:
                select_items.append("*")
        
        return "SELECT " + ",\n       ".join(select_items)
    
    def _generate_from_clause(self, schema_mapping: Dict[str, Any]) -> str:
        """
        Generate the FROM clause of the SQL query.
        
        Args:
            schema_mapping: The schema mapping result
            
        Returns:
            The FROM clause string
        """
        # Get tables from mapping
        tables = self._get_tables_from_mapping(schema_mapping)
        
        if not tables:
            # Use a placeholder if no tables are mapped
            return "FROM /* Table name needed */"
        
        # Use the first table as the main table
        return f"FROM {tables[0]}"
    
    def _generate_join_clause(self, schema_mapping: Dict[str, Any]) -> str:
        """
        Generate the JOIN clause of the SQL query.
        
        Args:
            schema_mapping: The schema mapping result
            
        Returns:
            The JOIN clause string
        """
        joins = schema_mapping.get("joins", [])
        
        if not joins:
            return ""
        
        join_clauses = []
        
        for join in joins:
            # Check if this is a placeholder join
            if join.get("is_placeholder"):
                join_clauses.append(f"{join.get('join_type', '/* Join type needed */')} {join.get('to_table')}")
                continue
            
            # Regular join
            join_type = join.get("join_type", "INNER JOIN")
            from_table = join.get("from_table")
            from_column = join.get("from_column")
            to_table = join.get("to_table")
            to_column = join.get("to_column")
            
            if from_table and from_column and to_table and to_column:
                join_clauses.append(f"{join_type} {to_table} ON {from_table}.{from_column} = {to_table}.{to_column}")
        
        return "\n".join(join_clauses)
    
    def _generate_where_clause(self, query_context: Dict[str, Any], 
                             schema_mapping: Dict[str, Any]) -> str:
        """
        Generate the WHERE clause of the SQL query.
        
        Args:
            query_context: The query context
            schema_mapping: The schema mapping result
            
        Returns:
            The WHERE clause string
        """
        conditions = []
        
        # Process mapped conditions
        for condition_mapping in schema_mapping.get("conditions", []):
            table = condition_mapping.get("table")
            
            for condition in condition_mapping.get("conditions", []):
                column = condition.get("column")
                operator = condition.get("operator", "=")
                value = condition.get("value")
                is_placeholder = condition.get("is_placeholder", False)
                
                if table and column and value:
                    # Handle different value types
                    if isinstance(value, str) and not value.isdigit() and not is_placeholder:
                        # String value, add quotes
                        conditions.append(f"{table}.{column} {operator} '{value}'")
                    elif is_placeholder:
                        # Placeholder value, use as is
                        conditions.append(f"{table}.{column} {operator} {value}")
                    else:
                        # Numeric or other value, use without quotes
                        conditions.append(f"{table}.{column} {operator} {value}")
        
        # If no conditions, return empty string
        if not conditions:
            return ""
        
        return "WHERE " + "\n   AND ".join(conditions)
    
    def _generate_group_by_clause(self, query_context: Dict[str, Any], 
                                schema_mapping: Dict[str, Any], intent: str) -> str:
        """
        Generate the GROUP BY clause of the SQL query.
        
        Args:
            query_context: The query context
            schema_mapping: The schema mapping result
            intent: The query intent
            
        Returns:
            The GROUP BY clause string
        """
        # Only add GROUP BY for aggregation or trend analysis
        if intent not in ["aggregation", "trend_analysis"]:
            return ""
        
        group_by_columns = []
        
        # Add non-aggregated columns to GROUP BY
        for column in schema_mapping.get("columns", []):
            table = column.get("table")
            col = column.get("column")
            aggregation = column.get("aggregation")
            
            # Only add non-aggregated columns to GROUP BY
            if table and col and not aggregation:
                group_by_columns.append(f"{table}.{col}")
        
        # For trend analysis, add time-related columns
        if intent == "trend_analysis":
            for condition in schema_mapping.get("conditions", []):
                table = condition.get("table")
                for cond in condition.get("conditions", []):
                    column = cond.get("column")
                    if table and column and any(time_term in column.lower() for time_term in 
                                              ["date", "time", "year", "quarter", "month", "day"]):
                        group_by_str = f"{table}.{column}"
                        if group_by_str not in group_by_columns:
                            group_by_columns.append(group_by_str)
        
        # If no GROUP BY columns, return empty string
        if not group_by_columns:
            return ""
        
        return "GROUP BY " + ",\n         ".join(group_by_columns)
    
    def _generate_order_by_clause(self, query_context: Dict[str, Any], 
                                schema_mapping: Dict[str, Any], intent: str) -> str:
        """
        Generate the ORDER BY clause of the SQL query.
        
        Args:
            query_context: The query context
            schema_mapping: The schema mapping result
            intent: The query intent
            
        Returns:
            The ORDER BY clause string
        """
        order_by_columns = []
        
        # For trend analysis, order by time columns
        if intent == "trend_analysis":
            for condition in schema_mapping.get("conditions", []):
                table = condition.get("table")
                for cond in condition.get("conditions", []):
                    column = cond.get("column")
                    if table and column and any(time_term in column.lower() for time_term in 
                                              ["date", "time", "year", "quarter", "month", "day"]):
                        order_by_columns.append(f"{table}.{column} ASC")
        
        # For aggregation, order by aggregated columns (descending)
        elif intent == "aggregation":
            for column in schema_mapping.get("columns", []):
                table = column.get("table")
                col = column.get("column")
                aggregation = column.get("aggregation")
                
                if table and col and aggregation:
                    order_by_columns.append(f"{col}_{aggregation.lower()} DESC")
        
        # If no ORDER BY columns, return empty string
        if not order_by_columns:
            return ""
        
        return "ORDER BY " + ",\n         ".join(order_by_columns)
    
    def _generate_limit_clause(self) -> str:
        """
        Generate the LIMIT clause of the SQL query.
        
        Returns:
            The LIMIT clause string
        """
        return f"LIMIT {self._max_limit}"
    
    def _format_sql_query(self, sql: str) -> str:
        """
        Format a SQL query for readability.
        
        Args:
            sql: The SQL query to format
            
        Returns:
            The formatted SQL query
        """
        try:
            # Use sqlparse for formatting
            formatted = sqlparse.format(
                sql,
                reindent=True,
                keyword_case='upper',
                indent_width=4
            )
            
            return formatted.strip()
        except Exception as e:
            self._logger.warning(f"Error formatting SQL: {str(e)}")
            return sql.strip()
    
    def _add_header_comment(self, sql: str, query: str) -> str:
        """
        Add a header comment to the SQL query.
        
        Args:
            sql: The SQL query
            query: The original user query
            
        Returns:
            SQL query with header comment
        """
        header = f"-- Generated SQL for query: {query}\n"
        header += f"-- Generated at: {self._get_timestamp()}\n"
        header += f"-- SQL dialect: {self._dialect}\n"
        
        return header + "\n" + sql
    
    def _get_timestamp(self) -> str:
        """
        Get the current timestamp.
        
        Returns:
            Timestamp string
        """
        from datetime import datetime
        return datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    
    def _get_tables_from_mapping(self, schema_mapping: Dict[str, Any]) -> List[str]:
        """
        Get a list of tables from the schema mapping.
        
        Args:
            schema_mapping: The schema mapping result
            
        Returns:
            List of table names
        """
        tables = set()
        
        # Add tables from table mappings
        for table_mapping in schema_mapping.get("tables", []):
            if "table" in table_mapping:
                tables.add(table_mapping["table"])
        
        # Add tables from column mappings
        for column_mapping in schema_mapping.get("columns", []):
            if "table" in column_mapping:
                tables.add(column_mapping["table"])
        
        # Add tables from condition mappings
        for condition_mapping in schema_mapping.get("conditions", []):
            if "table" in condition_mapping:
                tables.add(condition_mapping["table"])
        
        # Remove None values
        return [t for t in tables if t]
    
    def _get_columns_from_mapping(self, schema_mapping: Dict[str, Any]) -> List[Dict[str, Any]]:
        """
        Get a list of columns from the schema mapping.
        
        Args:
            schema_mapping: The schema mapping result
            
        Returns:
            List of column information dictionaries
        """
        columns = []
        
        # Add columns from column mappings
        for column_mapping in schema_mapping.get("columns", []):
            if "table" in column_mapping and "column" in column_mapping:
                columns.append({
                    "table": column_mapping["table"],
                    "column": column_mapping["column"],
                    "aggregation": column_mapping.get("aggregation")
                })
        
        return columns
    
    def _get_conditions_from_mapping(self, schema_mapping: Dict[str, Any]) -> List[Dict[str, Any]]:
        """
        Get a list of conditions from the schema mapping.
        
        Args:
            schema_mapping: The schema mapping result
            
        Returns:
            List of condition information dictionaries
        """
        conditions = []
        
        # Add conditions from condition mappings
        for condition_mapping in schema_mapping.get("conditions", []):
            if "table" in condition_mapping and "conditions" in condition_mapping:
                for condition in condition_mapping["conditions"]:
                    if "column" in condition and "operator" in condition and "value" in condition:
                        conditions.append({
                            "table": condition_mapping["table"],
                            "column": condition["column"],
                            "operator": condition["operator"],
                            "value": condition["value"],
                            "is_placeholder": condition.get("is_placeholder", False)
                        })
        
        return conditions