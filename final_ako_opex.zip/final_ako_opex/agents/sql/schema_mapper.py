"""
Schema Mapper Module

This module maps user query entities to database schema elements,
ensuring accurate translation of business terms to SQL entities.
"""

import logging
import re
from typing import Dict, List, Any, Optional, Set, Tuple
from fuzzywuzzy import fuzz, process

class SchemaMapper:
    """
    Maps query entities to database schema elements.
    
    The SchemaMapper:
    1. Maps business terms to database tables and columns
    2. Resolves ambiguous entity references
    3. Validates entity mappings against the database schema
    4. Provides context for SQL generation
    5. Handles entity resolution failures gracefully
    """
    
    def __init__(self, config: Dict[str, Any] = None):
        """
        Initialize a new schema mapper.
        
        Args:
            config: Configuration parameters
        """
        self._logger = logging.getLogger(__name__)
        self._config = config or {}
        
        # Schema information
        self._tables = {}
        self._columns = {}
        self._relationships = []
        
        # Business term mappings
        self._term_to_table = {}
        self._term_to_column = {}
        
        # Initialize matching thresholds
        self._exact_match_threshold = self._config.get("exact_match_threshold", 100)
        self._high_match_threshold = self._config.get("high_match_threshold", 90)
        self._medium_match_threshold = self._config.get("medium_match_threshold", 75)
        self._low_match_threshold = self._config.get("low_match_threshold", 60)
        
        # Load mappings if provided in config
        if "mappings" in self._config:
            self.load_mappings(self._config["mappings"])
    
    def load_schema(self, schema: Dict[str, Any]) -> None:
        """
        Load database schema information.
        
        Args:
            schema: Database schema information
        """
        # Load tables
        self._tables = schema.get("tables", {})
        
        # Load columns
        self._columns = {}
        for table_name, table_info in self._tables.items():
            if "columns" in table_info:
                self._columns[table_name] = table_info["columns"]
        
        # Load relationships
        self._relationships = schema.get("relationships", [])
        
        self._logger.info(f"Loaded schema with {len(self._tables)} tables and {len(self._relationships)} relationships")
    
    def load_mappings(self, mappings: Dict[str, Any]) -> None:
        """
        Load business term mappings.
        
        Args:
            mappings: Business term mappings
        """
        # Load term-to-table mappings
        self._term_to_table = mappings.get("term_to_table", {})
        
        # Load term-to-column mappings
        self._term_to_column = mappings.get("term_to_column", {})
        
        self._logger.info(f"Loaded {len(self._term_to_table)} table mappings and {len(self._term_to_column)} column mappings")
    
    def map_query_entities(self, query_context: Dict[str, Any]) -> Dict[str, Any]:
        """
        Map entities from a query context to database schema elements.
        
        Args:
            query_context: The query context with entities to map
            
        Returns:
            Dictionary with mapped schema elements
        """
        self._logger.debug(f"Mapping query entities: {query_context}")
        
        # Initialize the mapping result
        mapping = {
            "tables": [],
            "columns": [],
            "conditions": [],
            "joins": [],
            "unmapped_entities": [],
            "confidence": 1.0
        }
        
        # Map business units to tables
        business_units = query_context.get("business_units", [])
        for bu in business_units:
            table_mapping = self._map_business_unit(bu)
            if table_mapping:
                mapping["tables"].append(table_mapping)
            else:
                mapping["unmapped_entities"].append({
                    "entity": bu,
                    "type": "business_unit",
                    "reason": "No matching table found"
                })
        
        # Map metrics to columns
        metrics = query_context.get("metrics", [])
        for metric in metrics:
            column_mapping = self._map_metric(metric)
            if column_mapping:
                mapping["columns"].append(column_mapping)
            else:
                mapping["unmapped_entities"].append({
                    "entity": metric,
                    "type": "metric",
                    "reason": "No matching column found"
                })
        
        # Map time periods to conditions
        time_periods = query_context.get("time_period", [])
        for time_period in time_periods:
            condition_mapping = self._map_time_period(time_period)
            if condition_mapping:
                mapping["conditions"].append(condition_mapping)
            else:
                mapping["unmapped_entities"].append({
                    "entity": time_period,
                    "type": "time_period",
                    "reason": "Could not map to a time condition"
                })
        
        # Add necessary joins based on mapped tables
        mapped_tables = [t["table"] for t in mapping["tables"]]
        if len(mapped_tables) > 1:
            joins = self._determine_joins(mapped_tables)
            mapping["joins"].extend(joins)
        
        # Calculate overall confidence based on unmapped entities
        if mapping["unmapped_entities"]:
            # Reduce confidence based on number of unmapped entities
            unmapped_ratio = len(mapping["unmapped_entities"]) / (
                len(business_units) + len(metrics) + len(time_periods)
            )
            mapping["confidence"] = max(0.0, 1.0 - unmapped_ratio)
        
        return mapping
    
    def _map_business_unit(self, business_unit: str) -> Optional[Dict[str, Any]]:
        """
        Map a business unit to a database table.
        
        Args:
            business_unit: The business unit to map
            
        Returns:
            Dictionary with mapped table information or None if not mapped
        """
        # Try exact match in term-to-table mappings
        if business_unit in self._term_to_table:
            table_name = self._term_to_table[business_unit]
            if table_name in self._tables:
                return {
                    "entity": business_unit,
                    "table": table_name,
                    "match_type": "exact",
                    "confidence": 1.0
                }
        
        # Try fuzzy matching with term-to-table mappings
        term_matches = self._fuzzy_match(business_unit, list(self._term_to_table.keys()))
        if term_matches and term_matches[0][1] >= self._high_match_threshold:
            matched_term = term_matches[0][0]
            table_name = self._term_to_table[matched_term]
            if table_name in self._tables:
                return {
                    "entity": business_unit,
                    "table": table_name,
                    "match_type": "term_fuzzy",
                    "matched_term": matched_term,
                    "confidence": term_matches[0][1] / 100.0
                }
        
        # Try direct fuzzy matching with table names
        table_matches = self._fuzzy_match(business_unit, list(self._tables.keys()))
        if table_matches and table_matches[0][1] >= self._medium_match_threshold:
            table_name = table_matches[0][0]
            return {
                "entity": business_unit,
                "table": table_name,
                "match_type": "table_fuzzy",
                "confidence": table_matches[0][1] / 100.0
            }
        
        # Try matching with table descriptions
        for table_name, table_info in self._tables.items():
            description = table_info.get("description", "")
            if description and business_unit.lower() in description.lower():
                return {
                    "entity": business_unit,
                    "table": table_name,
                    "match_type": "description_match",
                    "confidence": 0.7
                }
        
        # No match found
        return None
    
    def _map_metric(self, metric: str) -> Optional[Dict[str, Any]]:
        """
        Map a metric to a database column.
        
        Args:
            metric: The metric to map
            
        Returns:
            Dictionary with mapped column information or None if not mapped
        """
        # Try exact match in term-to-column mappings
        if metric in self._term_to_column:
            column_info = self._term_to_column[metric]
            table_name = column_info.get("table")
            column_name = column_info.get("column")
            
            if table_name in self._tables and column_name in self._columns.get(table_name, {}):
                return {
                    "entity": metric,
                    "table": table_name,
                    "column": column_name,
                    "match_type": "exact",
                    "confidence": 1.0
                }
        
        # Try fuzzy matching with term-to-column mappings
        term_matches = self._fuzzy_match(metric, list(self._term_to_column.keys()))
        if term_matches and term_matches[0][1] >= self._high_match_threshold:
            matched_term = term_matches[0][0]
            column_info = self._term_to_column[matched_term]
            table_name = column_info.get("table")
            column_name = column_info.get("column")
            
            if table_name in self._tables and column_name in self._columns.get(table_name, {}):
                return {
                    "entity": metric,
                    "table": table_name,
                    "column": column_name,
                    "match_type": "term_fuzzy",
                    "matched_term": matched_term,
                    "confidence": term_matches[0][1] / 100.0
                }
        
        # Try direct fuzzy matching with column names across all tables
        for table_name, columns in self._columns.items():
            column_matches = self._fuzzy_match(metric, list(columns.keys()))
            if column_matches and column_matches[0][1] >= self._medium_match_threshold:
                column_name = column_matches[0][0]
                return {
                    "entity": metric,
                    "table": table_name,
                    "column": column_name,
                    "match_type": "column_fuzzy",
                    "confidence": column_matches[0][1] / 100.0
                }
        
        # Try matching with column descriptions
        for table_name, columns in self._columns.items():
            for column_name, column_info in columns.items():
                description = column_info.get("description", "")
                if description and metric.lower() in description.lower():
                    return {
                        "entity": metric,
                        "table": table_name,
                        "column": column_name,
                        "match_type": "description_match",
                        "confidence": 0.7
                    }
        
        # Check for aggregate metrics that might need to be computed
        aggregation_terms = {
            "total": "SUM",
            "sum": "SUM",
            "average": "AVG",
            "avg": "AVG",
            "mean": "AVG",
            "count": "COUNT",
            "minimum": "MIN",
            "min": "MIN",
            "maximum": "MAX",
            "max": "MAX"
        }
        
        # Check if the metric starts with an aggregation term
        for agg_term, agg_func in aggregation_terms.items():
            if metric.lower().startswith(agg_term.lower() + " "):
                # Extract the metric without the aggregation term
                remaining_metric = metric[len(agg_term) + 1:].strip()
                # Try to map the remaining metric
                column_mapping = self._map_metric(remaining_metric)
                if column_mapping:
                    column_mapping["aggregation"] = agg_func
                    column_mapping["entity"] = metric
                    return column_mapping
        
        # No match found
        return None
    
    def _map_time_period(self, time_period: str) -> Optional[Dict[str, Any]]:
        """
        Map a time period to a SQL condition.
        
        Args:
            time_period: The time period to map
            
        Returns:
            Dictionary with mapped condition information or None if not mapped
        """
        # Initialize common time-related column names to look for
        time_columns = {
            "date": ["date", "time", "timestamp", "created_at", "updated_at", "transaction_date"],
            "year": ["year", "fiscal_year", "yr"],
            "quarter": ["quarter", "fiscal_quarter", "qtr", "q"],
            "month": ["month", "fiscal_month", "mon", "mnth"]
        }
        
        # Try to identify the time period format
        quarter_match = re.match(r'Q([1-4])_(\d{4})', time_period)
        if quarter_match:
            quarter = quarter_match.group(1)
            year = quarter_match.group(2)
            
            # Look for quarter column in tables
            for table_name, columns in self._columns.items():
                quarter_column = None
                year_column = None
                
                # Find quarter and year columns
                for col_name in columns.keys():
                    col_lower = col_name.lower()
                    if not quarter_column and any(qtr_term in col_lower for qtr_term in time_columns["quarter"]):
                        quarter_column = col_name
                    if not year_column and any(yr_term in col_lower for yr_term in time_columns["year"]):
                        year_column = col_name
                
                if quarter_column and year_column:
                    return {
                        "entity": time_period,
                        "table": table_name,
                        "conditions": [
                            {
                                "column": quarter_column,
                                "operator": "=",
                                "value": quarter
                            },
                            {
                                "column": year_column,
                                "operator": "=",
                                "value": year
                            }
                        ],
                        "match_type": "quarter_year",
                        "confidence": 0.9
                    }
                
                # Check for combined quarter_year column
                for col_name in columns.keys():
                    col_lower = col_name.lower()
                    if "quarter" in col_lower and "year" in col_lower:
                        return {
                            "entity": time_period,
                            "table": table_name,
                            "conditions": [
                                {
                                    "column": col_name,
                                    "operator": "=",
                                    "value": f"Q{quarter}_{year}"
                                }
                            ],
                            "match_type": "quarter_year_combined",
                            "confidence": 0.95
                        }
        
        # Check for YYYY-MM format
        month_match = re.match(r'(\d{4})-(\d{2})', time_period)
        if month_match:
            year = month_match.group(1)
            month = month_match.group(2)
            
            # Look for month and year columns
            for table_name, columns in self._columns.items():
                month_column = None
                year_column = None
                
                # Find month and year columns
                for col_name in columns.keys():
                    col_lower = col_name.lower()
                    if not month_column and any(mon_term in col_lower for mon_term in time_columns["month"]):
                        month_column = col_name
                    if not year_column and any(yr_term in col_lower for yr_term in time_columns["year"]):
                        year_column = col_name
                
                if month_column and year_column:
                    return {
                        "entity": time_period,
                        "table": table_name,
                        "conditions": [
                            {
                                "column": month_column,
                                "operator": "=",
                                "value": month
                            },
                            {
                                "column": year_column,
                                "operator": "=",
                                "value": year
                            }
                        ],
                        "match_type": "month_year",
                        "confidence": 0.9
                    }
        
        # Check for fiscal year format (FY_YYYY)
        fy_match = re.match(r'FY_(\d{4})', time_period)
        if fy_match:
            year = fy_match.group(1)
            
            # Look for fiscal year column
            for table_name, columns in self._columns.items():
                for col_name in columns.keys():
                    col_lower = col_name.lower()
                    if "fiscal" in col_lower and "year" in col_lower:
                        return {
                            "entity": time_period,
                            "table": table_name,
                            "conditions": [
                                {
                                    "column": col_name,
                                    "operator": "=",
                                    "value": year
                                }
                            ],
                            "match_type": "fiscal_year",
                            "confidence": 0.95
                        }
        
        # Check for date range format (YYYY-MM-DD)
        date_match = re.match(r'(\d{4})-(\d{2})-(\d{2})', time_period)
        if date_match:
            date_str = time_period
            
            # Look for date column
            for table_name, columns in self._columns.items():
                for col_name in columns.keys():
                    col_lower = col_name.lower()
                    if any(date_term in col_lower for date_term in time_columns["date"]):
                        return {
                            "entity": time_period,
                            "table": table_name,
                            "conditions": [
                                {
                                    "column": col_name,
                                    "operator": "=",
                                    "value": date_str
                                }
                            ],
                            "match_type": "date",
                            "confidence": 0.95
                        }
        
        # Check for relative time periods
        relative_match = re.match(r'(current|previous|last|next)_(quarter|month|year)', time_period, re.IGNORECASE)
        if relative_match:
            relative_type = relative_match.group(1).lower()
            period_type = relative_match.group(2).lower()
            
            # Map to appropriate time columns
            time_column_types = time_columns.get(period_type, [period_type])
            
            for table_name, columns in self._columns.items():
                for col_name in columns.keys():
                    col_lower = col_name.lower()
                    if any(time_term in col_lower for time_term in time_column_types):
                        operator = "="
                        if relative_type == "current":
                            placeholder = f"CURRENT_{period_type.upper()}"
                        elif relative_type in ["previous", "last"]:
                            placeholder = f"PREVIOUS_{period_type.upper()}"
                        else:  # next
                            placeholder = f"NEXT_{period_type.upper()}"
                        
                        return {
                            "entity": time_period,
                            "table": table_name,
                            "conditions": [
                                {
                                    "column": col_name,
                                    "operator": operator,
                                    "value": placeholder,
                                    "is_placeholder": True
                                }
                            ],
                            "match_type": "relative_time",
                            "confidence": 0.8
                        }
        
        # No match found
        return None
    
    def _determine_joins(self, tables: List[str]) -> List[Dict[str, Any]]:
        """
        Determine necessary joins between tables.
        
        Args:
            tables: List of tables that need to be joined
            
        Returns:
            List of join information dictionaries
        """
        joins = []
        remaining_tables = set(tables[1:])  # Skip the first table (primary)
        joined_tables = {tables[0]}  # Start with the first table
        
        # Keep trying to join tables until all are joined or no more joins possible
        while remaining_tables and len(joined_tables) < len(tables):
            found_join = False
            
            # Try to find a relationship between a joined table and a remaining table
            for relationship in self._relationships:
                source_table = relationship.get("source_table")
                target_table = relationship.get("target_table")
                
                # Check if this relationship connects a joined table with a remaining table
                if source_table in joined_tables and target_table in remaining_tables:
                    joins.append({
                        "from_table": source_table,
                        "from_column": relationship.get("source_column"),
                        "to_table": target_table,
                        "to_column": relationship.get("target_column"),
                        "join_type": "INNER JOIN"
                    })
                    joined_tables.add(target_table)
                    remaining_tables.remove(target_table)
                    found_join = True
                    break
                elif target_table in joined_tables and source_table in remaining_tables:
                    joins.append({
                        "from_table": target_table,
                        "from_column": relationship.get("target_column"),
                        "to_table": source_table,
                        "to_column": relationship.get("source_column"),
                        "join_type": "INNER JOIN"
                    })
                    joined_tables.add(source_table)
                    remaining_tables.remove(source_table)
                    found_join = True
                    break
            
            # If no direct relationship found, try to find transitive relationships
            if not found_join and remaining_tables:
                for table in remaining_tables:
                    # Just add a generic join with a comment for the SQL generator to resolve
                    joins.append({
                        "to_table": table,
                        "join_type": "/* Need to determine appropriate join path */",
                        "is_placeholder": True
                    })
                break  # Let SQL generator handle complex join paths
        
        return joins
    
    def _fuzzy_match(self, query: str, choices: List[str], 
                   threshold: Optional[int] = None) -> List[Tuple[str, int]]:
        """
        Perform fuzzy matching between a query and a list of choices.
        
        Args:
            query: The string to match
            choices: List of choices to match against
            threshold: Optional minimum score threshold
            
        Returns:
            List of (choice, score) tuples sorted by score descending
        """
        if not query or not choices:
            return []
        
        # Set default threshold if not provided
        if threshold is None:
            threshold = self._low_match_threshold
        
        # Clean strings for better matching
        clean_query = query.lower().strip()
        clean_choices = [choice.lower().strip() for choice in choices]
        
        # Get top 3 matches with scores
        matches = process.extract(clean_query, clean_choices, scorer=fuzz.token_sort_ratio, limit=3)
        
        # Filter by threshold and map back to original choices
        result = []
        for match, score in matches:
            if score >= threshold:
                # Find the original choice
                idx = clean_choices.index(match)
                result.append((choices[idx], score))
        
        return result
    
    def get_mapped_tables(self, mapping: Dict[str, Any]) -> List[str]:
        """
        Get a list of mapped tables from a mapping result.
        
        Args:
            mapping: The mapping result
            
        Returns:
            List of mapped table names
        """
        tables = set()
        
        # Add tables from table mappings
        for table_mapping in mapping.get("tables", []):
            tables.add(table_mapping.get("table"))
        
        # Add tables from column mappings
        for column_mapping in mapping.get("columns", []):
            tables.add(column_mapping.get("table"))
        
        # Add tables from condition mappings
        for condition_mapping in mapping.get("conditions", []):
            tables.add(condition_mapping.get("table"))
        
        # Remove None values
        return [t for t in tables if t]
    
    def get_mapped_columns(self, mapping: Dict[str, Any]) -> List[Dict[str, Any]]:
        """
        Get a list of mapped columns from a mapping result.
        
        Args:
            mapping: The mapping result
            
        Returns:
            List of mapped column information dictionaries
        """
        columns = []
        
        # Add columns from column mappings
        for column_mapping in mapping.get("columns", []):
            if "table" in column_mapping and "column" in column_mapping:
                columns.append({
                    "table": column_mapping["table"],
                    "column": column_mapping["column"],
                    "aggregation": column_mapping.get("aggregation")
                })
        
        # Add columns from condition mappings
        for condition_mapping in mapping.get("conditions", []):
            for condition in condition_mapping.get("conditions", []):
                if "column" in condition:
                    columns.append({
                        "table": condition_mapping.get("table"),
                        "column": condition["column"]
                    })
        
        return columns
    
    def get_table_columns(self, table_name: str) -> List[str]:
        """
        Get the columns for a specific table.
        
        Args:
            table_name: The table name
            
        Returns:
            List of column names
        """
        if table_name in self._columns:
            return list(self._columns[table_name].keys())
        return []
    
    def validate_entity_mappings(self, mapping: Dict[str, Any]) -> Dict[str, Any]:
        """
        Validate entity mappings against the database schema.
        
        Args:
            mapping: The mapping result to validate
            
        Returns:
            Dictionary with validation results
        """
        validation = {
            "valid": True,
            "errors": [],
            "warnings": []
        }
        
        # Validate tables
        for table_mapping in mapping.get("tables", []):
            table = table_mapping.get("table")
            if table not in self._tables:
                validation["valid"] = False
                validation["errors"].append({
                    "type": "invalid_table",
                    "entity": table_mapping.get("entity"),
                    "table": table,
                    "message": f"Table '{table}' does not exist in the schema"
                })
        
        # Validate columns
        for column_mapping in mapping.get("columns", []):
            table = column_mapping.get("table")
            column = column_mapping.get("column")
            
            if table not in self._tables:
                validation["valid"] = False
                validation["errors"].append({
                    "type": "invalid_table",
                    "entity": column_mapping.get("entity"),
                    "table": table,
                    "message": f"Table '{table}' does not exist in the schema"
                })
            elif column not in self._columns.get(table, {}):
                validation["valid"] = False
                validation["errors"].append({
                    "type": "invalid_column",
                    "entity": column_mapping.get("entity"),
                    "table": table,
                    "column": column,
                    "message": f"Column '{column}' does not exist in table '{table}'"
                })
        
        # Validate conditions
        for condition_mapping in mapping.get("conditions", []):
            table = condition_mapping.get("table")
            
            if table not in self._tables:
                validation["valid"] = False
                validation["errors"].append({
                    "type": "invalid_table",
                    "entity": condition_mapping.get("entity"),
                    "table": table,
                    "message": f"Table '{table}' does not exist in the schema"
                })
            else:
                for condition in condition_mapping.get("conditions", []):
                    column = condition.get("column")
                    if column and column not in self._columns.get(table, {}):
                        validation["valid"] = False
                        validation["errors"].append({
                            "type": "invalid_column",
                            "entity": condition_mapping.get("entity"),
                            "table": table,
                            "column": column,
                            "message": f"Column '{column}' does not exist in table '{table}'"
                        })
        
        # Validate joins
        for join in mapping.get("joins", []):
            from_table = join.get("from_table")
            to_table = join.get("to_table")
            from_column = join.get("from_column")
            to_column = join.get("to_column")
            
            # Skip placeholder joins
            if join.get("is_placeholder"):
                validation["warnings"].append({
                    "type": "placeholder_join",
                    "message": f"Join between tables needs to be resolved"
                })
                continue
            
            if from_table and from_table not in self._tables:
                validation["valid"] = False
                validation["errors"].append({
                    "type": "invalid_table",
                    "table": from_table,
                    "message": f"Join source table '{from_table}' does not exist in the schema"
                })
            
            if to_table and to_table not in self._tables:
                validation["valid"] = False
                validation["errors"].append({
                    "type": "invalid_table",
                    "table": to_table,
                    "message": f"Join target table '{to_table}' does not exist in the schema"
                })
            
            if from_table and from_column and from_column not in self._columns.get(from_table, {}):
                validation["valid"] = False
                validation["errors"].append({
                    "type": "invalid_column",
                    "table": from_table,
                    "column": from_column,
                    "message": f"Join source column '{from_column}' does not exist in table '{from_table}'"
                })
            
            if to_table and to_column and to_column not in self._columns.get(to_table, {}):
                validation["valid"] = False
                validation["errors"].append({
                    "type": "invalid_column",
                    "table": to_table,
                    "column": to_column,
                    "message": f"Join target column '{to_column}' does not exist in table '{to_table}'"
                })
        
        return validation