"""
RAG Agent Package

This package implements the RAG (Retrieval-Augmented Generation) Agent,
responsible for retrieving and augmenting relevant context for SQL generation.

Components:
- Retriever: Implements various retrieval strategies (vector, keyword, hybrid)
- Reranker: Improves retrieval quality by reordering documents based on relevance
- DocumentChunker: Provides utilities for breaking documents into manageable chunks
- RAGAgent: Main agent implementation that orchestrates context retrieval and processing
"""

from .retriever import BaseRetriever, VectorRetriever, KeywordRetriever, HybridRetriever
from .reranker import Reranker, CrossEncoderReranker, LLMReranker
from .document_chunker import DocumentChunker
from .rag_agent import RAGAgent