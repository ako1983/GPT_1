"""
RAG Agent Module

This module implements the RAG (Retrieval-Augmented Generation) Agent,
responsible for retrieving relevant context and augmenting queries with
additional information for accurate SQL generation.
"""

import os
import json
import logging
import asyncio
from typing import Dict, List, Any, Optional, Tuple, Union

from ...core.interfaces.agent_interface import Agent, AgentType, ExecutionStatus, Message
from ...core.communication.event_bus import get_event_bus
from ...core.state.state_manager import get_state_manager, QueryState
from ...core.memory.vector_store import create_vector_store, VectorStore, Document
from .retriever import BaseRetriever, VectorRetriever, KeywordRetriever, HybridRetriever
from .reranker import Reranker, CrossEncoderReranker, LLMReranker
from .document_chunker import DocumentChunker


class RAGAgent(Agent):
    """
    RAG Agent for retrieving and augmenting context for SQL generation.
    
    The RAGAgent:
    1. Retrieves relevant context based on user queries
    2. Reranks and filters results to ensure quality
    3. Augments the query with pertinent information
    4. Provides comprehensive context for SQL generation
    5. Handles both vector and keyword-based retrieval
    """
    
    def __init__(self, agent_id: str, config: Dict[str, Any]):
        """
        Initialize a new RAG agent.
        
        Args:
            agent_id: Unique identifier for this agent
            config: Configuration parameters for this agent
        """
        super().__init__(agent_id, AgentType.RAG)
        self._logger = logging.getLogger(__name__)
        self._config = config
        self._vector_store = None
        self._initialized = False
        self._event_bus = get_event_bus()
        self._state_manager = get_state_manager()
        
        # Component instances
        self._retrievers: Dict[str, BaseRetriever] = {}
        self._reranker: Optional[Reranker] = None
        
        # Document processing settings
        self._chunk_size = config.get("chunk_size", 512)
        self._chunk_overlap = config.get("chunk_overlap", 100)
        self._document_chunker = DocumentChunker(
            chunk_size=self._chunk_size,
            chunk_overlap=self._chunk_overlap
        )
        
        # Collections
        self._metadata_collection = config.get("metadata_collection", "metadata")
        self._examples_collection = config.get("examples_collection", "examples")
        self._documentation_collection = config.get("documentation_collection", "docs")
        
        # Default retrieval parameters
        self._top_k = config.get("top_k", 5)
        self._score_threshold = config.get("score_threshold", 0.5)
    
    async def initialize(self, config: Dict[str, Any]) -> bool:
        """
        Initialize the agent with configuration parameters.
        
        Args:
            config: Configuration parameters
            
        Returns:
            True if initialization was successful, False otherwise
        """
        try:
            # Update configuration
            self._config.update(config)
            
            # Initialize vector store
            vector_store_type = self._config.get("vector_store_type", "memory")
            vector_store_path = self._config.get("vector_store_path")
            embedding_function = self._config.get("embedding_function")
            
            self._vector_store = create_vector_store(
                vector_store_type,
                embedding_fn=embedding_function
            )
            
            # Load existing vector store if available
            if vector_store_path and os.path.exists(vector_store_path) and hasattr(self._vector_store, "load"):
                self._vector_store = self._vector_store.load(vector_store_path, embedding_function)
            
            # Initialize retrievers
            await self._initialize_retrievers()
            
            # Initialize reranker
            await self._initialize_reranker()
            
            # Register with the event bus
            self._event_bus.register_agent(AgentType.RAG, self.process)
            
            self._initialized = True
            self._logger.info("RAG agent initialized successfully")
            
            # Load documents if specified in config
            if self._config.get("load_documents_on_startup", False):
                await self._load_documents()
            
            return True
            
        except Exception as e:
            self._logger.error(f"Error initializing RAG agent: {str(e)}")
            return False
    
    async def _initialize_retrievers(self) -> None:
        """
        Initialize the retrieval components based on configuration.
        """
        # Vector retriever (primary)
        if self._vector_store:
            self._retrievers["vector"] = VectorRetriever(
                vector_store=self._vector_store,
                collection_name=self._metadata_collection,
                top_k=self._top_k,
                embedding_function=self._config.get("embedding_function")
            )
            self._logger.info("Initialized vector retriever")
        
        # Keyword retriever
        if "document_store" in self._config:
            self._retrievers["keyword"] = KeywordRetriever(
                document_store=self._config["document_store"]
            )
            self._logger.info("Initialized keyword retriever")
        
        # Hybrid retriever (if both vector and keyword are available)
        if "vector" in self._retrievers and "keyword" in self._retrievers:
            self._retrievers["hybrid"] = HybridRetriever(
                retrievers=[self._retrievers["vector"], self._retrievers["keyword"]],
                weights=self._config.get("retriever_weights", [0.7, 0.3])
            )
            self._logger.info("Initialized hybrid retriever")
    
    async def _initialize_reranker(self) -> None:
        """
        Initialize the reranking component based on configuration.
        """
        reranker_type = self._config.get("reranker_type", "default")
        
        if reranker_type == "cross_encoder":
            model_name = self._config.get("cross_encoder_model")
            self._reranker = CrossEncoderReranker(
                model_name_or_function=model_name,
                top_k=self._config.get("reranker_top_k", self._top_k),
                score_threshold=self._config.get("reranker_score_threshold", self._score_threshold)
            )
            self._logger.info(f"Initialized cross-encoder reranker with model: {model_name}")
            
        elif reranker_type == "llm":
            llm_function = self._config.get("llm_function")
            if callable(llm_function):
                self._reranker = LLMReranker(
                    llm_function=llm_function,
                    top_k=self._config.get("reranker_top_k", self._top_k),
                    score_threshold=self._config.get("reranker_score_threshold", self._score_threshold)
                )
                self._logger.info("Initialized LLM reranker")
            else:
                self._logger.warning("LLM function not provided, using default reranker")
                self._reranker = CrossEncoderReranker()
    
    async def _load_documents(self) -> None:
        """
        Load documents from configured sources.
        """
        document_sources = self._config.get("document_sources", [])
        
        for source in document_sources:
            source_type = source.get("type")
            source_path = source.get("path")
            collection_name = source.get("collection", self._documentation_collection)
            
            if not source_type or not source_path:
                continue
                
            try:
                if source_type == "file" and os.path.exists(source_path):
                    await self._load_document_file(source_path, collection_name, source)
                    
                elif source_type == "directory" and os.path.isdir(source_path):
                    await self._load_document_directory(source_path, collection_name, source)
                    
                elif source_type == "examples" and os.path.exists(source_path):
                    await self._load_examples(source_path, source.get("collection", self._examples_collection))
                    
            except Exception as e:
                self._logger.error(f"Error loading documents from {source_path}: {str(e)}")
    
    async def _load_document_file(self, file_path: str, collection_name: str, options: Dict[str, Any]) -> None:
        """
        Load a single document file.
        
        Args:
            file_path: Path to the document file
            collection_name: Collection to store the document in
            options: Additional options for loading
        """
        if not self._vector_store:
            self._logger.warning("Vector store not available for document loading")
            return
            
        try:
            # Use the DocumentChunker to process the file
            chunking_strategy = options.get("strategy", "text")
            encoding = options.get("encoding", "utf-8")
            
            # Chunk the file using DocumentChunker
            chunks = self._document_chunker.chunk_file(
                file_path=file_path,
                encoding=encoding,
                strategy=chunking_strategy
            )
            
            if not chunks:
                self._logger.warning(f"No chunks generated from {file_path}")
                return
                
            # Add custom metadata if provided
            if "metadata" in options:
                for chunk in chunks:
                    chunk["metadata"].update(options["metadata"])
            
            # Add document type
            for chunk in chunks:
                chunk["metadata"]["type"] = options.get("type", "document")
            
            # Add chunks to vector store
            texts = [chunk["text"] for chunk in chunks]
            metadatas = [chunk["metadata"] for chunk in chunks]
            
            self._vector_store.add_texts(
                texts=texts,
                metadatas=metadatas,
                collection_name=collection_name
            )
            
            self._logger.info(f"Added {len(chunks)} chunks from {file_path} to collection {collection_name}")
            
        except Exception as e:
            self._logger.error(f"Error loading document file {file_path}: {str(e)}")
    
    async def _load_document_directory(self, dir_path: str, collection_name: str, options: Dict[str, Any]) -> None:
        """
        Load all documents from a directory.
        
        Args:
            dir_path: Path to the directory
            collection_name: Collection to store documents in
            options: Additional options for loading
        """
        if not os.path.isdir(dir_path):
            self._logger.warning(f"Directory {dir_path} does not exist")
            return
            
        # Get file extensions to include
        extensions = options.get("extensions", [".txt", ".md", ".csv", ".json"])
        
        for root, _, files in os.walk(dir_path):
            for file in files:
                if any(file.endswith(ext) for ext in extensions):
                    file_path = os.path.join(root, file)
                    # Create per-file options
                    file_options = options.copy()
                    if "metadata" not in file_options:
                        file_options["metadata"] = {}
                    file_options["metadata"]["directory"] = os.path.relpath(root, dir_path)
                    
                    await self._load_document_file(file_path, collection_name, file_options)
    
    async def _load_examples(self, examples_path: str, collection_name: str) -> None:
        """
        Load SQL examples from a file.
        
        Args:
            examples_path: Path to the examples file
            collection_name: Collection to store examples in
        """
        if not self._vector_store:
            self._logger.warning("Vector store not available for examples loading")
            return
            
        try:
            # Read the examples file
            with open(examples_path, 'r', encoding='utf-8') as f:
                if examples_path.endswith('.json'):
                    examples = json.load(f)
                else:
                    self._logger.warning(f"Unsupported examples file format: {examples_path}")
                    return
            
            # Process each example
            for i, example in enumerate(examples):
                question = example.get("question", "")
                sql = example.get("sql", "")
                context = example.get("context", "")
                
                if not question or not sql:
                    continue
                
                # Combine the example components
                text = f"Question: {question}\n\nSQL: {sql}"
                if context:
                    text += f"\n\nContext: {context}"
                
                # Create metadata
                metadata = {
                    "source": examples_path,
                    "type": "example",
                    "example_id": i,
                    "question": question
                }
                
                # Add to vector store
                self._vector_store.add_texts(
                    texts=[text],
                    metadatas=[metadata],
                    collection_name=collection_name
                )
            
            self._logger.info(f"Added {len(examples)} examples to collection {collection_name}")
            
        except Exception as e:
            self._logger.error(f"Error loading examples from {examples_path}: {str(e)}")
    
    def _chunk_document(self, text: str, options: Dict[str, Any]) -> List[str]:
        """
        Split a document into chunks for processing.
        
        Args:
            text: The document text to chunk
            options: Chunking options
            
        Returns:
            List of text chunks
        """
        chunk_size = options.get("chunk_size", self._chunk_size)
        chunk_overlap = options.get("chunk_overlap", self._chunk_overlap)
        chunking_strategy = options.get("strategy", "text")
        
        # Use the DocumentChunker for more advanced chunking
        if chunking_strategy == "paragraph":
            return self._document_chunker._chunk_by_paragraph(text)
        elif chunking_strategy == "semantic":
            return self._document_chunker._chunk_semantic(text)
        else:  # Default to "text"
            return self._document_chunker.chunk_text(text, chunk_size, chunk_overlap)
    
    async def process(self, message: Message) -> Message:
        """
        Process an incoming message and produce a response.
        
        Args:
            message: The incoming message to process
            
        Returns:
            A response message
        """
        self._logger.info(f"Processing message: {message.message_type}")
        
        # Extract message content
        content = message.content
        
        # Check the message type and dispatch to the appropriate handler
        if message.message_type == "retrieve":
            query = content.get("query")
            query_id = content.get("query_id")
            retriever_type = content.get("retriever", "hybrid") if "hybrid" in self._retrievers else "vector"
            
            if query:
                result = await self.retrieve_context(query, query_id, retriever_type, content)
                return Message(
                    sender=AgentType.RAG,
                    receiver=message.sender,
                    content=result,
                    message_type="retrieve_result",
                    trace_id=message.trace_id
                )
        
        elif message.message_type == "augment":
            query = content.get("query")
            query_id = content.get("query_id")
            context = content.get("context", [])
            
            if query:
                result = await self.augment_query(query, query_id, context)
                return Message(
                    sender=AgentType.RAG,
                    receiver=message.sender,
                    content=result,
                    message_type="augment_result",
                    trace_id=message.trace_id
                )
        
        elif message.message_type == "add_document":
            document = content.get("document")
            collection = content.get("collection", self._documentation_collection)
            
            if document:
                result = await self.add_document(document, collection)
                return Message(
                    sender=AgentType.RAG,
                    receiver=message.sender,
                    content=result,
                    message_type="add_document_result",
                    trace_id=message.trace_id
                )
        
        # Default response for unsupported message types
        return Message(
            sender=AgentType.RAG,
            receiver=message.sender,
            content={"error": "Unsupported message type"},
            message_type="error",
            trace_id=message.trace_id
        )
    
    async def retrieve_context(self, query: str, query_id: Optional[str] = None, 
                              retriever_type: str = "hybrid", options: Dict[str, Any] = None) -> Dict[str, Any]:
        """
        Retrieve relevant context for a query.
        
        Args:
            query: The query to retrieve context for
            query_id: Optional query ID for state tracking
            retriever_type: Type of retriever to use (vector, keyword, hybrid)
            options: Additional retrieval options
            
        Returns:
            Dictionary with retrieved context
        """
        self._logger.info(f"Retrieving context for query: {query}")
        
        try:
            # Update status
            self.status = ExecutionStatus.IN_PROGRESS
            
            # Use the specified retriever, or fall back to vector retriever
            if retriever_type not in self._retrievers:
                self._logger.warning(f"Retriever type {retriever_type} not available, using vector retriever")
                retriever_type = "vector" if "vector" in self._retrievers else list(self._retrievers.keys())[0]
            
            retriever = self._retrievers[retriever_type]
            
            # Extract retrieval parameters
            if options is None:
                options = {}
                
            top_k = options.get("top_k", self._top_k)
            filter_dict = options.get("filter")
            collections = options.get("collections", [self._metadata_collection, self._examples_collection])
            
            # Retrieve from each collection and combine results
            all_results = []
            
            for collection in collections:
                try:
                    results = await retriever.retrieve(
                        query=query,
                        top_k=top_k,
                        collection_name=collection,
                        filter=filter_dict
                    )
                    
                    # Add collection information to each result
                    for result in results:
                        result["collection"] = collection
                    
                    all_results.extend(results)
                    
                except Exception as e:
                    self._logger.warning(f"Error retrieving from collection {collection}: {str(e)}")
            
            # Rerank results if a reranker is available
            if self._reranker and all_results:
                all_results = await self._reranker.rerank(
                    query=query,
                    documents=all_results,
                    top_k=top_k
                )
            
            # Update the query state if a query ID is provided
            if query_id:
                query_state = self._state_manager.get_query_state(query_id)
                if query_state:
                    self._state_manager.update_query_context(query_id, {
                        "retrieved_context": all_results
                    })
            
            # Update status
            self.status = ExecutionStatus.COMPLETED
            
            return {
                "query": query,
                "context": all_results,
                "retriever": retriever_type,
                "reranked": bool(self._reranker)
            }
            
        except Exception as e:
            self._logger.error(f"Error retrieving context: {str(e)}")
            self.status = ExecutionStatus.FAILED
            return {"error": str(e)}
    
    async def augment_query(self, query: str, query_id: Optional[str] = None, 
                           context: Optional[List[Dict[str, Any]]] = None) -> Dict[str, Any]:
        """
        Augment a query with additional context.
        
        Args:
            query: The query to augment
            query_id: Optional query ID for state tracking
            context: Optional context to use for augmentation
            
        Returns:
            Dictionary with the augmented query
        """
        self._logger.info(f"Augmenting query: {query}")
        
        try:
            # Update status
            self.status = ExecutionStatus.IN_PROGRESS
            
            # If no context is provided and we have a query ID, try to get it from the state
            if not context and query_id:
                query_state = self._state_manager.get_query_state(query_id)
                if query_state:
                    context = query_state.get_context("retrieved_context", [])
            
            # If we still don't have context, retrieve it
            if not context:
                retrieval_result = await self.retrieve_context(query, query_id)
                context = retrieval_result.get("context", [])
            
            # Extract relevant information from the context
            augmented_info = self._extract_relevant_info(query, context)
            
            # Combine the query and augmented information
            augmented_query = self._format_augmented_query(query, augmented_info)
            
            # Update the query state if a query ID is provided
            if query_id:
                self._state_manager.update_query_context(query_id, {
                    "augmented_query": augmented_query,
                    "augmented_info": augmented_info
                })
            
            # Update status
            self.status = ExecutionStatus.COMPLETED
            
            return {
                "original_query": query,
                "augmented_query": augmented_query,
                "augmented_info": augmented_info
            }
            
        except Exception as e:
            self._logger.error(f"Error augmenting query: {str(e)}")
            self.status = ExecutionStatus.FAILED
            return {"error": str(e)}
    
    def _extract_relevant_info(self, query: str, context: List[Dict[str, Any]]) -> Dict[str, Any]:
        """
        Extract relevant information from context documents.
        
        Args:
            query: The original query
            context: The context documents
            
        Returns:
            Dictionary of relevant information
        """
        # Extract table and column information
        tables = {}
        columns = {}
        relationships = []
        examples = []
        
        for doc in context:
            metadata = doc.get("metadata", {})
            doc_type = metadata.get("type")
            
            if doc_type == "table":
                table_name = metadata.get("table")
                if table_name:
                    tables[table_name] = {
                        "description": metadata.get("description", ""),
                        "source": metadata.get("source", "")
                    }
            
            elif doc_type == "column":
                table_name = metadata.get("table")
                column_name = metadata.get("column")
                if table_name and column_name:
                    if table_name not in columns:
                        columns[table_name] = {}
                    
                    columns[table_name][column_name] = {
                        "description": metadata.get("description", ""),
                        "data_type": metadata.get("data_type", ""),
                        "business_terms": metadata.get("business_terms", [])
                    }
            
            elif doc_type == "relationship":
                source_table = metadata.get("source_table")
                source_column = metadata.get("source_column")
                target_table = metadata.get("target_table")
                target_column = metadata.get("target_column")
                
                if source_table and source_column and target_table and target_column:
                    relationships.append({
                        "source_table": source_table,
                        "source_column": source_column,
                        "target_table": target_table,
                        "target_column": target_column,
                        "relationship_type": metadata.get("relationship_type", "")
                    })
            
            elif doc_type == "example":
                content = doc.get("content", "")
                if content:
                    examples.append({
                        "question": metadata.get("question", ""),
                        "content": content
                    })
        
        # Return the extracted information
        return {
            "tables": tables,
            "columns": columns,
            "relationships": relationships,
            "examples": examples[:2]  # Limit to a few examples
        }
    
    def _format_augmented_query(self, query: str, info: Dict[str, Any]) -> str:
        """
        Format the augmented query.
        
        Args:
            query: The original query
            info: The extracted information
            
        Returns:
            The augmented query
        """
        # Build the augmented query
        augmented_query = f"Original question: {query}\n\n"
        
        # Add table information
        if info["tables"]:
            augmented_query += "Relevant tables:\n"
            for table_name, table_info in info["tables"].items():
                augmented_query += f"- {table_name}: {table_info.get('description', '')}\n"
            augmented_query += "\n"
        
        # Add column information
        if info["columns"]:
            augmented_query += "Relevant columns:\n"
            for table_name, table_columns in info["columns"].items():
                for column_name, column_info in table_columns.items():
                    business_terms = ", ".join(column_info.get("business_terms", []))
                    business_term_text = f" (Business terms: {business_terms})" if business_terms else ""
                    augmented_query += f"- {table_name}.{column_name} ({column_info.get('data_type', '')}){business_term_text}: {column_info.get('description', '')}\n"
            augmented_query += "\n"
        
        # Add relationship information
        if info["relationships"]:
            augmented_query += "Table relationships:\n"
            for rel in info["relationships"]:
                augmented_query += f"- {rel['source_table']}.{rel['source_column']} -> {rel['target_table']}.{rel['target_column']} ({rel.get('relationship_type', '')})\n"
            augmented_query += "\n"
        
        # Add examples if available
        if info["examples"]:
            augmented_query += "Relevant examples:\n"
            for example in info["examples"]:
                augmented_query += f"- Question: {example.get('question', '')}\n  {example.get('content', '')}\n\n"
        
        return augmented_query
    
    async def add_document(self, document: Dict[str, Any], collection_name: str) -> Dict[str, Any]:
        """
        Add a document to the vector store.
        
        Args:
            document: The document to add
            collection_name: The collection to add the document to
            
        Returns:
            Status dictionary
        """
        if not self._vector_store:
            return {"error": "Vector store not available"}
        
        try:
            # Extract document fields
            text = document.get("text")
            metadata = document.get("metadata", {})
            
            if not text:
                return {"error": "Document text is required"}
            
            # Add to vector store
            result = self._vector_store.add_texts(
                texts=[text],
                metadatas=[metadata],
                collection_name=collection_name
            )
            
            return {
                "status": "success",
                "document_id": result[0] if result else None,
                "collection": collection_name
            }
            
        except Exception as e:
            self._logger.error(f"Error adding document: {str(e)}")
            return {"error": str(e)}
    
    def get_capabilities(self) -> List[str]:
        """
        Return a list of capabilities this agent provides.
        
        Returns:
            List of capability strings
        """
        return [
            "context_retrieval",
            "query_augmentation",
            "document_indexing",
            "example_based_retrieval"
        ]
    
    def get_status(self) -> Dict[str, Any]:
        """
        Get the current status of this agent.
        
        Returns:
            A dictionary with status information
        """
        return {
            "agent_id": self.agent_id,
            "agent_type": self.agent_type,
            "status": self.status,
            "retrievers": list(self._retrievers.keys()),
            "reranker": type(self._reranker).__name__ if self._reranker else None,
            "initialized": self._initialized
        }
    
    async def shutdown(self) -> bool:
        """
        Perform cleanup when shutting down the agent.
        
        Returns:
            True if shutdown was successful, False otherwise
        """
        try:
            # Save vector store if configured
            vector_store_path = self._config.get("vector_store_path")
            if vector_store_path and self._vector_store and hasattr(self._vector_store, "save"):
                self._vector_store.save(vector_store_path)
            
            # Unregister from the event bus
            self._event_bus.unregister_agent(AgentType.RAG)
            
            return True
            
        except Exception as e:
            self._logger.error(f"Error shutting down RAG agent: {str(e)}")
            return False