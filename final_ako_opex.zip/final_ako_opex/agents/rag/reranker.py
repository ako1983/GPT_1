"""
Reranker Module

This module implements a reranker that improves retrieval quality
by reordering documents based on relevance to the query.
"""

import logging
from typing import Dict, List, Any, Optional, Union, Tuple, Callable
import numpy as np


class Reranker:
    """
    Base class for rerankers that improve retrieval quality.
    
    This abstract base class defines the interface that all
    reranker implementations must follow.
    """
    
    def __init__(self):
        """Initialize a new reranker."""
        self._logger = logging.getLogger(__name__)
    
    async def rerank(self, query: str, documents: List[Dict[str, Any]], **kwargs) -> List[Dict[str, Any]]:
        """
        Rerank documents based on relevance to the query.
        
        Args:
            query: The original query
            documents: The documents to rerank
            **kwargs: Additional reranking parameters
            
        Returns:
            Reranked list of documents
        """
        raise NotImplementedError("Subclasses must implement rerank")


class CrossEncoderReranker(Reranker):
    """
    Reranker that uses a cross-encoder model for accurate relevance scoring.
    
    The CrossEncoderReranker:
    1. Uses a cross-encoder model to compute relevance scores
    2. Provides more accurate scoring than retrieval models
    3. Enables better filtering of irrelevant results
    """
    
    def __init__(self, model_name_or_function: Union[str, Callable] = None, 
                top_k: int = None, score_threshold: float = None):
        """
        Initialize a new cross-encoder reranker.
        
        Args:
            model_name_or_function: Cross-encoder model name or scoring function
            top_k: Maximum number of results to return
            score_threshold: Minimum score threshold for inclusion
        """
        super().__init__()
        self.model_name_or_function = model_name_or_function
        self.top_k = top_k
        self.score_threshold = score_threshold
        self._model = None
        
        # Initialize the model if using a pre-defined model name
        if isinstance(model_name_or_function, str):
            try:
                # Import here to avoid requiring sentence-transformers for all users
                from sentence_transformers.cross_encoder import CrossEncoder
                self._model = CrossEncoder(model_name_or_function)
                self._logger.info(f"Initialized cross-encoder model: {model_name_or_function}")
            except ImportError:
                self._logger.warning("sentence-transformers not installed. Using simpler scoring.")
                self._model = None
    
    async def rerank(self, query: str, documents: List[Dict[str, Any]], **kwargs) -> List[Dict[str, Any]]:
        """
        Rerank documents using a cross-encoder model.
        
        Args:
            query: The original query
            documents: The documents to rerank
            **kwargs: Additional reranking parameters
                - top_k: Optional override for maximum results
                - score_threshold: Optional override for score threshold
            
        Returns:
            Reranked list of documents
        """
        if not documents:
            return []
        
        # Extract parameters
        top_k = kwargs.get("top_k", self.top_k)
        score_threshold = kwargs.get("score_threshold", self.score_threshold)
        
        self._logger.debug(f"Reranking {len(documents)} documents for query: {query}")
        
        try:
            # Prepare document-query pairs
            pairs = []
            for document in documents:
                content = document.get("content", "")
                pairs.append((query, content))
            
            # Compute relevance scores
            if callable(self.model_name_or_function):
                # Use provided scoring function
                scores = [self.model_name_or_function(q, d) for q, d in pairs]
            elif self._model:
                # Use loaded cross-encoder model
                scores = self._model.predict(pairs)
            else:
                # Fallback to simpler scoring
                scores = self._simple_bm25_scoring(query, documents)
            
            # Add scores to documents
            for i, document in enumerate(documents):
                document["relevance_score"] = float(scores[i])
            
            # Filter by score threshold if provided
            if score_threshold is not None:
                documents = [doc for doc in documents if doc["relevance_score"] >= score_threshold]
            
            # Sort by score (descending)
            documents.sort(key=lambda x: x["relevance_score"], reverse=True)
            
            # Limit to top_k if provided
            if top_k is not None:
                documents = documents[:top_k]
            
            self._logger.debug(f"Reranked to {len(documents)} documents")
            return documents
            
        except Exception as e:
            self._logger.error(f"Error reranking documents: {str(e)}")
            return documents  # Return original documents on error
    
    def _simple_bm25_scoring(self, query: str, documents: List[Dict[str, Any]]) -> List[float]:
        """
        Simple BM25-inspired scoring function as fallback.
        
        Args:
            query: The query
            documents: The documents to score
            
        Returns:
            List of relevance scores
        """
        # Tokenize query
        query_terms = query.lower().split()
        
        # Compute document frequencies
        doc_freqs = {}
        for term in set(query_terms):
            doc_freqs[term] = sum(1 for doc in documents if term in doc.get("content", "").lower())
        
        # Compute scores
        scores = []
        for document in documents:
            content = document.get("content", "").lower()
            score = 0.0
            
            for term in query_terms:
                # Term frequency in document
                tf = content.count(term)
                
                if tf > 0 and term in doc_freqs and doc_freqs[term] > 0:
                    # Document frequency
                    df = doc_freqs[term]
                    
                    # IDF component (simplified)
                    idf = np.log((len(documents) + 1) / (df + 0.5))
                    
                    # BM25-inspired score (simplified)
                    k1 = 1.2
                    b = 0.75
                    avgdl = sum(len(doc.get("content", "")) for doc in documents) / len(documents)
                    dl = len(content)
                    
                    score += idf * (tf * (k1 + 1)) / (tf + k1 * (1 - b + b * dl / avgdl))
            
            scores.append(score)
        
        # Normalize scores to [0, 1]
        if scores:
            max_score = max(scores)
            if max_score > 0:
                scores = [s / max_score for s in scores]
        
        return scores


class LLMReranker(Reranker):
    """
    Reranker that uses a language model to score documents.
    
    The LLMReranker:
    1. Uses an LLM to evaluate document relevance to the query
    2. Can consider semantic meaning and nuance
    3. Potentially more accurate but slower than other methods
    """
    
    def __init__(self, llm_function: Callable, top_k: int = None, 
                score_threshold: float = None, max_tokens: int = 8192):
        """
        Initialize a new LLM reranker.
        
        Args:
            llm_function: Function to call the LLM for scoring
            top_k: Maximum number of results to return
            score_threshold: Minimum score threshold for inclusion
            max_tokens: Maximum tokens to process at once
        """
        super().__init__()
        self.llm_function = llm_function
        self.top_k = top_k
        self.score_threshold = score_threshold
        self.max_tokens = max_tokens
    
    async def rerank(self, query: str, documents: List[Dict[str, Any]], **kwargs) -> List[Dict[str, Any]]:
        """
        Rerank documents using an LLM.
        
        Args:
            query: The original query
            documents: The documents to rerank
            **kwargs: Additional reranking parameters
                - top_k: Optional override for maximum results
                - score_threshold: Optional override for score threshold
                - system_prompt: Custom system prompt for the LLM
            
        Returns:
            Reranked list of documents
        """
        if not documents:
            return []
        
        # Extract parameters
        top_k = kwargs.get("top_k", self.top_k)
        score_threshold = kwargs.get("score_threshold", self.score_threshold)
        system_prompt = kwargs.get("system_prompt", self._get_default_system_prompt())
        
        self._logger.debug(f"Reranking {len(documents)} documents with LLM for query: {query}")
        
        try:
            # Prepare the documents for scoring
            prepared_docs = []
            for i, doc in enumerate(documents):
                prepared_docs.append({
                    "id": i,
                    "content": doc.get("content", ""),
                    "metadata": doc.get("metadata", {})
                })
            
            # Batch documents to avoid exceeding token limits
            batches = self._batch_documents(prepared_docs)
            
            # Process each batch
            all_scores = []
            
            for batch in batches:
                # Create the prompt
                prompt = self._create_scoring_prompt(query, batch, system_prompt)
                
                # Call the LLM
                result = await self.llm_function(prompt)
                
                # Parse the scores
                batch_scores = self._parse_scores(result, batch)
                all_scores.extend(batch_scores)
            
            # Add scores to original documents
            for score_entry in all_scores:
                doc_id = score_entry["id"]
                if 0 <= doc_id < len(documents):
                    documents[doc_id]["relevance_score"] = score_entry["score"]
            
            # Filter by score threshold if provided
            if score_threshold is not None:
                documents = [doc for doc in documents if doc.get("relevance_score", 0) >= score_threshold]
            
            # Sort by score (descending)
            documents.sort(key=lambda x: x.get("relevance_score", 0), reverse=True)
            
            # Limit to top_k if provided
            if top_k is not None:
                documents = documents[:top_k]
            
            self._logger.debug(f"Reranked to {len(documents)} documents with LLM")
            return documents
            
        except Exception as e:
            self._logger.error(f"Error reranking documents with LLM: {str(e)}")
            return documents  # Return original documents on error
    
    def _get_default_system_prompt(self) -> str:
        """
        Get the default system prompt for LLM reranking.
        
        Returns:
            Default system prompt
        """
        return """
        You are an expert document ranker. Your task is to evaluate how relevant each document is to the query.
        Provide a relevance score between 0 and 1 for each document, where 1 means highly relevant and 0 means not relevant at all.
        Consider these factors when scoring:
        1. How directly the document addresses the query
        2. The amount of relevant information in the document
        3. The specificity and precision of the information
        
        Only output the scores in a JSON format like this:
        {
            "scores": [
                {"id": 0, "score": 0.95, "reason": "Brief explanation"},
                {"id": 1, "score": 0.4, "reason": "Brief explanation"}
            ]
        }
        """
    
    def _create_scoring_prompt(self, query: str, documents: List[Dict[str, Any]], system_prompt: str) -> str:
        """
        Create a prompt for the LLM to score documents.
        
        Args:
            query: The original query
            documents: The documents to score
            system_prompt: The system prompt
            
        Returns:
            Complete prompt for the LLM
        """
        # Format documents
        doc_texts = []
        for i, doc in enumerate(documents):
            doc_text = f"Document {doc['id']}:\n{doc['content']}"
            doc_texts.append(doc_text)
        
        # Create user prompt
        user_prompt = f"""
        Query: {query}
        
        Please score the following documents based on their relevance to the query:
        
        {"\n\n".join(doc_texts)}
        
        Remember to provide scores between 0 and 1, where 1 means highly relevant and 0 means not relevant at all.
        Only output the scores in the JSON format described.
        """
        
        return {
            "system": system_prompt,
            "user": user_prompt
        }
    
    def _parse_scores(self, llm_response: str, documents: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """
        Parse the LLM's response to extract scores.
        
        Args:
            llm_response: The LLM's response
            documents: The documents that were scored
            
        Returns:
            List of document scores
        """
        import json
        import re
        
        # Try to extract a JSON object
        json_match = re.search(r'\{.*\}', llm_response, re.DOTALL)
        
        if json_match:
            try:
                # Parse the JSON
                result = json.loads(json_match.group(0))
                
                if "scores" in result and isinstance(result["scores"], list):
                    return result["scores"]
            except json.JSONDecodeError:
                self._logger.warning("Failed to parse LLM response as JSON")
        
        # Fallback: try to extract scores directly
        scores = []
        for doc in documents:
            doc_id = doc["id"]
            score_match = re.search(rf'Document {doc_id}.*?score.*?(\d+\.\d+)', llm_response, re.DOTALL)
            
            if score_match:
                try:
                    score = float(score_match.group(1))
                    scores.append({"id": doc_id, "score": score})
                except ValueError:
                    # Default score
                    scores.append({"id": doc_id, "score": 0.5})
            else:
                # Default score
                scores.append({"id": doc_id, "score": 0.5})
        
        return scores
    
    def _batch_documents(self, documents: List[Dict[str, Any]]) -> List[List[Dict[str, Any]]]:
        """
        Batch documents to avoid exceeding token limits.
        
        Args:
            documents: The documents to batch
            
        Returns:
            List of document batches
        """
        # Simple heuristic: estimate tokens as 4 characters per token
        batches = []
        current_batch = []
        current_token_estimate = 0
        
        for doc in documents:
            # Rough token estimate
            doc_token_estimate = len(str(doc)) // 4
            
            # Check if adding this document would exceed the limit
            if current_token_estimate + doc_token_estimate > self.max_tokens and current_batch:
                batches.append(current_batch)
                current_batch = [doc]
                current_token_estimate = doc_token_estimate
            else:
                current_batch.append(doc)
                current_token_estimate += doc_token_estimate
        
        # Add the last batch if not empty
        if current_batch:
            batches.append(current_batch)
        
        return batches