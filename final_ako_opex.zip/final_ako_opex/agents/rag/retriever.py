"""
Retriever Module

This module implements the retrieval components for the RAG system,
responsible for finding relevant context based on user queries.
"""

import logging
from typing import Dict, List, Any, Optional, Union, Tuple

from ...core.memory.vector_store import VectorStore, Document


class BaseRetriever:
    """
    Base class for retrievers that fetch relevant context.
    
    This abstract base class defines the interface that all
    retriever implementations must follow.
    """
    
    def __init__(self):
        """Initialize a new retriever."""
        self._logger = logging.getLogger(__name__)
    
    async def retrieve(self, query: str, **kwargs) -> List[Dict[str, Any]]:
        """
        Retrieve relevant documents for a query.
        
        Args:
            query: The query to retrieve documents for
            **kwargs: Additional retrieval parameters
            
        Returns:
            List of retrieved documents
        """
        raise NotImplementedError("Subclasses must implement retrieve")


class VectorRetriever(BaseRetriever):
    """
    Retriever that uses vector similarity search.
    
    The VectorRetriever:
    1. Uses semantic similarity to find relevant documents
    2. Supports filtering by metadata
    3. Provides confidence scores for retrieved documents
    """
    
    def __init__(self, vector_store: VectorStore, collection_name: str = "default", 
                top_k: int = 5, embedding_function: Optional[callable] = None):
        """
        Initialize a new vector retriever.
        
        Args:
            vector_store: Vector store to retrieve from
            collection_name: Name of the collection to search
            top_k: Maximum number of results to return
            embedding_function: Optional function to compute embeddings
        """
        super().__init__()
        self.vector_store = vector_store
        self.collection_name = collection_name
        self.top_k = top_k
        self.embedding_function = embedding_function
    
    async def retrieve(self, query: str, **kwargs) -> List[Dict[str, Any]]:
        """
        Retrieve relevant documents using vector similarity.
        
        Args:
            query: The query to retrieve documents for
            **kwargs: Additional retrieval parameters
                - filter: Optional filter to apply to the search
                - top_k: Optional override for the number of results
                - collection_name: Optional override for the collection name
            
        Returns:
            List of retrieved documents with metadata and relevance scores
        """
        # Extract parameters
        filter_dict = kwargs.get("filter")
        top_k = kwargs.get("top_k", self.top_k)
        collection_name = kwargs.get("collection_name", self.collection_name)
        
        self._logger.debug(f"Retrieving documents for query: {query}")
        
        try:
            # Perform similarity search
            results = self.vector_store.similarity_search(
                query=query,
                k=top_k,
                collection_name=collection_name,
                filter=filter_dict
            )
            
            # Format the results
            formatted_results = []
            for i, doc in enumerate(results):
                formatted_doc = {
                    "content": doc.get("text", ""),
                    "metadata": doc.get("metadata", {}),
                    "relevance_score": 1.0 - (i / len(results)),  # Simple score based on rank
                    "source": "vector_store"
                }
                
                formatted_results.append(formatted_doc)
            
            self._logger.debug(f"Retrieved {len(formatted_results)} documents")
            return formatted_results
            
        except Exception as e:
            self._logger.error(f"Error retrieving documents: {str(e)}")
            return []


class KeywordRetriever(BaseRetriever):
    """
    Retriever that uses keyword matching.
    
    The KeywordRetriever:
    1. Uses exact or fuzzy keyword matching to find documents
    2. Can be more precise for specific term searches
    3. Complements semantic search for hybrid retrieval
    """
    
    def __init__(self, document_store: Dict[str, List[Dict[str, Any]]]):
        """
        Initialize a new keyword retriever.
        
        Args:
            document_store: Dictionary mapping collections to lists of documents
        """
        super().__init__()
        self.document_store = document_store
    
    async def retrieve(self, query: str, **kwargs) -> List[Dict[str, Any]]:
        """
        Retrieve relevant documents using keyword matching.
        
        Args:
            query: The query to retrieve documents for
            **kwargs: Additional retrieval parameters
                - collection: Optional collection to search
                - fuzzy: Whether to use fuzzy matching
                - top_k: Maximum number of results to return
            
        Returns:
            List of retrieved documents with metadata and relevance scores
        """
        # Extract parameters
        collection = kwargs.get("collection")
        fuzzy = kwargs.get("fuzzy", False)
        top_k = kwargs.get("top_k", 5)
        
        self._logger.debug(f"Retrieving documents for query: {query}")
        
        try:
            # Determine which collection(s) to search
            if collection and collection in self.document_store:
                collections = [collection]
            else:
                collections = list(self.document_store.keys())
            
            # Extract keywords from the query
            keywords = self._extract_keywords(query)
            
            # Search each collection
            all_results = []
            
            for collection_name in collections:
                documents = self.document_store.get(collection_name, [])
                
                for document in documents:
                    score = self._calculate_relevance(document, keywords, fuzzy)
                    
                    if score > 0:
                        result = {
                            "content": document.get("content", ""),
                            "metadata": document.get("metadata", {}),
                            "relevance_score": score,
                            "source": "keyword_search"
                        }
                        
                        all_results.append((result, score))
            
            # Sort by relevance score and take the top_k
            all_results.sort(key=lambda x: x[1], reverse=True)
            top_results = [result for result, _ in all_results[:top_k]]
            
            self._logger.debug(f"Retrieved {len(top_results)} documents")
            return top_results
            
        except Exception as e:
            self._logger.error(f"Error retrieving documents: {str(e)}")
            return []
    
    def _extract_keywords(self, query: str) -> List[str]:
        """
        Extract keywords from a query.
        
        Args:
            query: The query to extract keywords from
            
        Returns:
            List of keywords
        """
        # Simple implementation - split by spaces and filter out common words
        common_words = {"a", "an", "the", "and", "or", "but", "in", "on", "at", "to", "for", "with", "by", "of"}
        return [word.lower() for word in query.split() if word.lower() not in common_words]
    
    def _calculate_relevance(self, document: Dict[str, Any], keywords: List[str], fuzzy: bool) -> float:
        """
        Calculate the relevance of a document to a set of keywords.
        
        Args:
            document: The document to score
            keywords: List of keywords to match
            fuzzy: Whether to use fuzzy matching
            
        Returns:
            Relevance score between 0 and 1
        """
        # Get the document content
        content = document.get("content", "").lower()
        
        if not content or not keywords:
            return 0.0
        
        # Count matches
        matches = 0
        
        for keyword in keywords:
            if fuzzy:
                # Fuzzy matching (contains)
                if keyword in content:
                    matches += 1
            else:
                # Exact matching (word boundary)
                import re
                if re.search(r'\b' + re.escape(keyword) + r'\b', content):
                    matches += 1
        
        # Calculate score as the proportion of matched keywords
        return matches / len(keywords) if keywords else 0.0


class HybridRetriever(BaseRetriever):
    """
    Retriever that combines multiple retrieval methods.
    
    The HybridRetriever:
    1. Combines results from different retrievers
    2. Can perform both semantic and keyword search
    3. Re-ranks results based on combined relevance
    """
    
    def __init__(self, retrievers: List[BaseRetriever], weights: Optional[List[float]] = None):
        """
        Initialize a new hybrid retriever.
        
        Args:
            retrievers: List of retrievers to combine
            weights: Optional weights for each retriever
        """
        super().__init__()
        self.retrievers = retrievers
        
        # Default to equal weights if not provided
        if weights is None:
            self.weights = [1.0] * len(retrievers)
        else:
            if len(weights) != len(retrievers):
                raise ValueError("Number of weights must match number of retrievers")
            self.weights = weights
    
    async def retrieve(self, query: str, **kwargs) -> List[Dict[str, Any]]:
        """
        Retrieve documents using multiple retrievers.
        
        Args:
            query: The query to retrieve documents for
            **kwargs: Additional retrieval parameters
                - top_k: Maximum number of results to return
                - dedup: Whether to remove duplicate results
            
        Returns:
            List of retrieved documents with metadata and relevance scores
        """
        # Extract parameters
        top_k = kwargs.get("top_k", 5)
        dedup = kwargs.get("dedup", True)
        
        self._logger.debug(f"Retrieving documents with hybrid approach for query: {query}")
        
        try:
            # Gather results from all retrievers
            all_results = []
            
            for i, retriever in enumerate(self.retrievers):
                weight = self.weights[i]
                
                # Pass along all kwargs to the individual retrievers
                results = await retriever.retrieve(query, **kwargs)
                
                # Apply weight to the relevance scores
                for result in results:
                    result["relevance_score"] *= weight
                    result["retriever_index"] = i
                
                all_results.extend(results)
            
            # Deduplicate if requested
            if dedup:
                all_results = self._deduplicate_results(all_results)
            
            # Sort by relevance score and take the top_k
            all_results.sort(key=lambda x: x["relevance_score"], reverse=True)
            top_results = all_results[:top_k]
            
            self._logger.debug(f"Retrieved {len(top_results)} documents with hybrid approach")
            return top_results
            
        except Exception as e:
            self._logger.error(f"Error retrieving documents with hybrid approach: {str(e)}")
            return []
    
    def _deduplicate_results(self, results: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """
        Remove duplicate results based on content.
        
        Args:
            results: List of retrieval results
            
        Returns:
            Deduplicated list of results
        """
        unique_results = {}
        
        for result in results:
            # Use content as the deduplication key
            content = result.get("content", "")
            
            # Keep the result with the highest score
            if content not in unique_results or result["relevance_score"] > unique_results[content]["relevance_score"]:
                unique_results[content] = result
        
        return list(unique_results.values())