# RAG Agent Module

## Overview

The RAG (Retrieval-Augmented Generation) Agent module provides comprehensive context retrieval and query augmentation capabilities for the OPEX_BOT system. It is responsible for finding relevant information from various sources and enriching user queries with pertinent context to improve SQL generation accuracy.

## Components

The RAG Agent module consists of the following key components:

### 1. RAGAgent

The main agent implementation that orchestrates the retrieval and augmentation process. It handles messages from other agents, manages the retrieval components, and processes document sources.

### 2. Retriever Components

- **BaseRetriever**: Abstract base class that defines the interface for all retrievers
- **VectorRetriever**: Implements semantic similarity search using vector embeddings
- **KeywordRetriever**: Implements keyword-based matching for precise term lookups
- **HybridRetriever**: Combines multiple retrieval approaches for improved results

### 3. Reranker Components

- **Reranker**: Abstract base class that defines the interface for all rerankers
- **CrossEncoderReranker**: Uses cross-encoder models for more accurate relevance scoring
- **LLMReranker**: Leverages language models for nuanced result reranking

### 4. DocumentChunker

Utility for breaking documents into manageable chunks with various strategies:
- Text-based chunking
- Paragraph-based chunking
- Semantic-based chunking

## Key Features

- **Multi-strategy Retrieval**: Combines vector search, keyword matching, and hybrid approaches
- **Advanced Reranking**: Improves retrieval quality through sophisticated reranking
- **Intelligent Chunking**: Preserves document structure and context during processing
- **Query Augmentation**: Enhances queries with relevant context for improved SQL generation
- **Document Management**: Loads and indexes documents from various sources
- **Example-based Learning**: Incorporates SQL examples for improved retrieval

## Usage

### Initialization

```python
from final_ako_opex.agents.rag import RAGAgent

# Initialize with configuration
rag_agent = RAGAgent(agent_id="rag_agent_1", config={
    "vector_store_type": "memory",
    "chunk_size": 512,
    "chunk_overlap": 100,
    "top_k": 5
})

# Initialize the agent
await rag_agent.initialize({})
```

### Retrieving Context

```python
# Direct method call
result = await rag_agent.retrieve_context(
    query="What was the total OPEX budget for Q1 2023?",
    retriever_type="hybrid"
)

# Via event system
from final_ako_opex.core.interfaces.agent_interface import Message, AgentType

message = Message(
    sender=AgentType.QUERY_ENHANCER,
    receiver=AgentType.RAG,
    content={"query": "What was the total OPEX budget for Q1 2023?"},
    message_type="retrieve",
    trace_id="query-123"
)

response = await rag_agent.process(message)
```

### Augmenting Queries

```python
# Direct method call
result = await rag_agent.augment_query(
    query="What was the total OPEX budget for Q1 2023?"
)

# Via event system
message = Message(
    sender=AgentType.QUERY_ENHANCER,
    receiver=AgentType.RAG,
    content={"query": "What was the total OPEX budget for Q1 2023?"},
    message_type="augment",
    trace_id="query-123"
)

response = await rag_agent.process(message)
```

### Adding Documents

```python
document = {
    "text": "The Q1 2023 OPEX budget was $10.5M, which represents a 5% increase from Q4 2022.",
    "metadata": {
        "source": "quarterly_report_q1_2023.pdf",
        "category": "financial_report",
        "date": "2023-04-15"
    }
}

result = await rag_agent.add_document(document, "financial_docs")
```

## Configuration

The RAG Agent is configured using a JSON configuration file. See [RAG Agent Configuration Guide](../../docs/rag_agent_configuration.md) for detailed configuration options.

## Integration with Other Agents

The RAG Agent integrates with:

- **Metadata Agent**: Uses metadata for informed retrieval
- **Query Enhancer Agent**: Provides augmented queries for improved understanding
- **SQL Agent**: Delivers relevant context for accurate SQL generation

## Best Practices

1. **Chunking Strategy Selection**:
   - Use `text` for general content
   - Use `paragraph` for preserving paragraph boundaries
   - Use `semantic` for maintaining section structure

2. **Retrieval Approach**:
   - Use `vector` for semantic similarity
   - Use `keyword` for exact term matching
   - Use `hybrid` for balanced results

3. **Performance Optimization**:
   - Adjust chunk size and overlap based on content type
   - Configure reranking parameters for result quality
   - Enable caching for frequent queries

## Example Workflow

1. User asks: "What was the CTO department's Q1 budget?"
2. Query Enhancer sends query to RAG Agent
3. RAG Agent retrieves relevant context from metadata and documentation
4. RAG Agent augments the query with table/column information and examples
5. Augmented query is sent to SQL Agent
6. SQL Agent generates accurate SQL based on the enhanced context

## Testing

Run the tests for the RAG module:

```bash
python -m unittest discover -s final_ako_opex/tests/rag
```

Or run a specific test:

```bash
python -m unittest final_ako_opex/tests/rag/test_document_chunker.py
```

## Further Reading

- [RAG Agent Configuration Guide](../../docs/rag_agent_configuration.md)
- [RAG Agent API Documentation](../../docs/rag_agent_api.md)
- [OPEX_BOT System Architecture](../../docs/architecture.md)