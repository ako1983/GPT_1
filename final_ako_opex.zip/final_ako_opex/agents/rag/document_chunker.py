"""
Document Chunker Module

This module provides utilities for chunking documents into manageable pieces
for efficient processing and retrieval.
"""

import re
import logging
from typing import List, Dict, Any, Optional, Callable, Union


class DocumentChunker:
    """
    Utility for chunking documents into smaller segments.
    
    The DocumentChunker:
    1. Breaks documents into manageable chunks
    2. Supports different chunking strategies
    3. Preserves document structure when possible
    4. Handles overlapping to avoid breaking context
    """
    
    def __init__(self, chunk_size: int = 512, chunk_overlap: int = 100):
        """
        Initialize a new document chunker.
        
        Args:
            chunk_size: Target size for each chunk
            chunk_overlap: Amount of overlap between chunks
        """
        self.chunk_size = chunk_size
        self.chunk_overlap = chunk_overlap
        self._logger = logging.getLogger(__name__)
    
    def chunk_text(self, text: str, chunk_size: Optional[int] = None, 
                 chunk_overlap: Optional[int] = None) -> List[str]:
        """
        Split text into chunks of approximately equal size.
        
        Args:
            text: The text to chunk
            chunk_size: Optional override for chunk size
            chunk_overlap: Optional override for chunk overlap
            
        Returns:
            List of text chunks
        """
        # Use provided parameters or instance defaults
        chunk_size = chunk_size or self.chunk_size
        chunk_overlap = chunk_overlap or self.chunk_overlap
        
        # If text is smaller than chunk size, return as is
        if len(text) <= chunk_size:
            return [text]
        
        chunks = []
        start = 0
        
        while start < len(text):
            # Get the chunk
            end = min(start + chunk_size, len(text))
            chunk = text[start:end]
            
            # Adjust chunk to end at paragraph or sentence boundary when possible
            if end < len(text):
                # Try to find paragraph break
                para_break = chunk.rfind("\n\n")
                if para_break != -1 and para_break > chunk_size // 2:
                    end = start + para_break + 2
                    chunk = text[start:end]
                else:
                    # Try to find sentence break
                    sentence_breaks = [chunk.rfind(". "), chunk.rfind("! "), chunk.rfind("? ")]
                    sentence_break = max(sentence_breaks)
                    if sentence_break != -1 and sentence_break > chunk_size // 2:
                        end = start + sentence_break + 2
                        chunk = text[start:end]
            
            chunks.append(chunk)
            
            # Move to next chunk with overlap
            start = end - chunk_overlap
        
        return chunks
    
    def chunk_document(self, document: Union[str, Dict[str, Any]], 
                     strategy: str = "text") -> List[Dict[str, Any]]:
        """
        Chunk a document using the specified strategy.
        
        Args:
            document: The document to chunk (text or dict with "text" field)
            strategy: Chunking strategy to use (text, paragraph, semantic)
            
        Returns:
            List of document chunks
        """
        # Extract text and metadata
        if isinstance(document, str):
            text = document
            metadata = {}
        else:
            text = document.get("text", "")
            metadata = document.get("metadata", {}).copy()
        
        if not text:
            return []
        
        # Choose chunking strategy
        if strategy == "paragraph":
            chunk_texts = self._chunk_by_paragraph(text)
        elif strategy == "semantic":
            chunk_texts = self._chunk_semantic(text)
        else:  # Default to "text"
            chunk_texts = self.chunk_text(text)
        
        # Create document chunks with metadata
        chunks = []
        for i, chunk_text in enumerate(chunk_texts):
            chunk_metadata = metadata.copy()
            chunk_metadata["chunk_index"] = i
            chunk_metadata["chunk_count"] = len(chunk_texts)
            
            chunks.append({
                "text": chunk_text,
                "metadata": chunk_metadata
            })
        
        return chunks
    
    def _chunk_by_paragraph(self, text: str) -> List[str]:
        """
        Split text into chunks based on paragraph boundaries.
        
        Args:
            text: The text to chunk
            
        Returns:
            List of text chunks
        """
        # Split by paragraphs (double newline)
        paragraphs = re.split(r'\n\s*\n', text)
        
        # Filter out empty paragraphs
        paragraphs = [p.strip() for p in paragraphs if p.strip()]
        
        if not paragraphs:
            return [text] if text.strip() else []
        
        # Combine paragraphs to reach target chunk size
        chunks = []
        current_chunk = ""
        
        for paragraph in paragraphs:
            # If adding this paragraph would exceed chunk size and we already have content,
            # finish the current chunk and start a new one
            if len(current_chunk) + len(paragraph) > self.chunk_size and current_chunk:
                chunks.append(current_chunk)
                current_chunk = paragraph
            else:
                # Add a separator if we already have content
                if current_chunk:
                    current_chunk += "\n\n"
                current_chunk += paragraph
        
        # Add the final chunk if it has content
        if current_chunk:
            chunks.append(current_chunk)
        
        return chunks
    
    def _chunk_semantic(self, text: str) -> List[str]:
        """
        Split text into chunks trying to preserve semantic meaning.
        
        Args:
            text: The text to chunk
            
        Returns:
            List of text chunks
        """
        # This is a simplified implementation that tries to keep
        # sections and subsections together when possible
        
        # Try to identify section headers
        section_pattern = r'(?:\n|^)(#+\s+.*|\d+(?:\.\d+)*\s+.*|\w+\s*\d+(?:\.\d+)*\s+.*)\n'
        sections = re.split(section_pattern, text)
        
        # If no sections found, fall back to paragraph chunking
        if len(sections) <= 2:
            return self._chunk_by_paragraph(text)
        
        # Process the sections
        processed_sections = []
        
        # Handle first item which might be pre-header content
        if sections[0].strip():
            processed_sections.append(sections[0])
        
        # Process header-content pairs
        for i in range(1, len(sections), 2):
            if i + 1 < len(sections):
                # Combine header with its content
                processed_sections.append(f"{sections[i]}\n{sections[i+1]}")
            else:
                # Handle last header if it has no content
                processed_sections.append(sections[i])
        
        # Now chunk each section, trying to keep them intact if possible
        chunks = []
        current_chunk = ""
        
        for section in processed_sections:
            # If the section itself is larger than chunk size, chunk it separately
            if len(section) > self.chunk_size:
                # Finish current chunk if not empty
                if current_chunk:
                    chunks.append(current_chunk)
                    current_chunk = ""
                
                # Chunk the large section
                section_chunks = self.chunk_text(section)
                chunks.extend(section_chunks)
            else:
                # If adding this section would exceed chunk size and we already have content,
                # finish the current chunk and start a new one
                if len(current_chunk) + len(section) > self.chunk_size and current_chunk:
                    chunks.append(current_chunk)
                    current_chunk = section
                else:
                    # Add a separator if we already have content
                    if current_chunk:
                        current_chunk += "\n\n"
                    current_chunk += section
        
        # Add the final chunk if it has content
        if current_chunk:
            chunks.append(current_chunk)
        
        return chunks
    
    def chunk_json(self, json_data: Dict[str, Any], text_key: str = "text",
                  metadata_keys: Optional[List[str]] = None) -> List[Dict[str, Any]]:
        """
        Chunk JSON document by its text field while preserving metadata.
        
        Args:
            json_data: The JSON document to chunk
            text_key: Key for the text field
            metadata_keys: Keys to include as metadata
            
        Returns:
            List of chunked documents
        """
        # Extract text and metadata
        text = json_data.get(text_key, "")
        
        if not text:
            return []
        
        # Build metadata
        metadata = {}
        if metadata_keys:
            for key in metadata_keys:
                if key in json_data and key != text_key:
                    metadata[key] = json_data[key]
        else:
            # If no keys specified, include all non-text keys
            for key, value in json_data.items():
                if key != text_key:
                    metadata[key] = value
        
        # Create a document and chunk it
        document = {
            "text": text,
            "metadata": metadata
        }
        
        return self.chunk_document(document)
    
    def chunk_file(self, file_path: str, encoding: str = 'utf-8',
                  strategy: str = "text") -> List[Dict[str, Any]]:
        """
        Read and chunk a file.
        
        Args:
            file_path: Path to the file
            encoding: File encoding
            strategy: Chunking strategy
            
        Returns:
            List of document chunks
        """
        try:
            # Read the file
            with open(file_path, 'r', encoding=encoding) as f:
                text = f.read()
            
            # Create metadata
            metadata = {
                "source": file_path,
                "filename": file_path.split("/")[-1]
            }
            
            # Create document and chunk it
            document = {
                "text": text,
                "metadata": metadata
            }
            
            return self.chunk_document(document, strategy)
            
        except Exception as e:
            self._logger.error(f"Error chunking file {file_path}: {str(e)}")
            return []