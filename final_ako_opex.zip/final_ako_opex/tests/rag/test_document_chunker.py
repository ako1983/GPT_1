"""
Test Document Chunker

This module contains tests for the DocumentChunker functionality.
"""

import os
import sys
import unittest
import json
from typing import List, Dict, Any

# Add the project root to the path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '../..')))

from final_ako_opex.agents.rag.document_chunker import DocumentChunker


class TestDocumentChunker(unittest.TestCase):
    """Test cases for DocumentChunker functionality."""
    
    def setUp(self):
        """Set up test fixtures."""
        self.chunker = DocumentChunker(chunk_size=100, chunk_overlap=20)
        
        # Create a test directory and file if needed
        self.test_dir = os.path.join(os.path.dirname(__file__), 'test_data')
        os.makedirs(self.test_dir, exist_ok=True)
        
        # Test text with paragraphs
        self.test_text = """
        This is the first paragraph of the test document.
        It contains multiple sentences to ensure proper chunking.
        
        This is the second paragraph which also has multiple sentences.
        We want to make sure paragraph boundaries are respected when possible.
        
        The third paragraph contains some financial terms like revenue, expense,
        and budget to simulate actual content.
        
        Finally, the fourth paragraph concludes the test document with some
        additional text to ensure we have enough content for multiple chunks.
        """
        
        # Write test file
        self.test_file = os.path.join(self.test_dir, 'test_document.txt')
        with open(self.test_file, 'w', encoding='utf-8') as f:
            f.write(self.test_text)
        
        # Test JSON document
        self.test_json = {
            "title": "Financial Report",
            "author": "Test User",
            "date": "2023-01-01",
            "text": self.test_text,
            "category": "test"
        }
    
    def test_chunk_text_basic(self):
        """Test basic text chunking functionality."""
        chunks = self.chunker.chunk_text(self.test_text)
        
        # Check that we have multiple chunks
        self.assertTrue(len(chunks) > 1, "Should create multiple chunks for this text")
        
        # Check that chunk sizes are reasonable
        for chunk in chunks:
            self.assertTrue(len(chunk) <= self.chunker.chunk_size, 
                          f"Chunk size {len(chunk)} exceeds max size {self.chunker.chunk_size}")
        
        # Check that all content is preserved
        combined = ""
        for chunk in chunks:
            combined += chunk
        
        # Compare ignoring whitespace differences
        original_content = ''.join(self.test_text.split())
        chunked_content = ''.join(combined.split())
        self.assertEqual(original_content, chunked_content, 
                        "Combined chunks should contain all original content")
    
    def test_chunk_by_paragraph(self):
        """Test paragraph-based chunking."""
        chunks = self.chunker._chunk_by_paragraph(self.test_text)
        
        # There should be at least 4 paragraphs
        self.assertTrue(len(chunks) > 0, "Should create chunks based on paragraphs")
        
        # Check that paragraph boundaries are preserved
        for chunk in chunks:
            # Each chunk should be a complete paragraph or group of paragraphs
            self.assertTrue(chunk.strip().startswith("This") or chunk.strip().startswith("The") or 
                          chunk.strip().startswith("Finally"),
                          f"Chunk doesn't start with expected paragraph beginning: {chunk[:20]}")
    
    def test_chunk_document(self):
        """Test document chunking with metadata preservation."""
        document = {
            "text": self.test_text,
            "metadata": {
                "source": "test",
                "author": "Test User"
            }
        }
        
        chunks = self.chunker.chunk_document(document)
        
        # Check that we have chunks
        self.assertTrue(len(chunks) > 0, "Should create document chunks")
        
        # Check that metadata is preserved and augmented
        for i, chunk in enumerate(chunks):
            self.assertEqual(chunk["metadata"]["source"], "test", "Source metadata should be preserved")
            self.assertEqual(chunk["metadata"]["author"], "Test User", "Author metadata should be preserved")
            self.assertEqual(chunk["metadata"]["chunk_index"], i, "Chunk index should be added")
            self.assertEqual(chunk["metadata"]["chunk_count"], len(chunks), "Chunk count should be added")
    
    def test_chunk_json(self):
        """Test JSON document chunking."""
        chunks = self.chunker.chunk_json(self.test_json)
        
        # Check that we have chunks
        self.assertTrue(len(chunks) > 0, "Should create JSON document chunks")
        
        # Check that metadata is preserved
        for chunk in chunks:
            self.assertEqual(chunk["metadata"]["title"], "Financial Report", "Title should be preserved")
            self.assertEqual(chunk["metadata"]["author"], "Test User", "Author should be preserved")
            self.assertEqual(chunk["metadata"]["date"], "2023-01-01", "Date should be preserved")
            self.assertEqual(chunk["metadata"]["category"], "test", "Category should be preserved")
    
    def test_chunk_file(self):
        """Test file chunking."""
        chunks = self.chunker.chunk_file(self.test_file)
        
        # Check that we have chunks
        self.assertTrue(len(chunks) > 0, "Should create file chunks")
        
        # Check that file metadata is added
        for chunk in chunks:
            self.assertEqual(chunk["metadata"]["filename"], "test_document.txt", "Filename should be added")
            self.assertTrue("source" in chunk["metadata"], "Source path should be added")
    
    def test_different_chunking_strategies(self):
        """Test different chunking strategies."""
        # Get chunks with different strategies
        text_chunks = self.chunker.chunk_document(self.test_text, strategy="text")
        para_chunks = self.chunker.chunk_document(self.test_text, strategy="paragraph")
        semantic_chunks = self.chunker.chunk_document(self.test_text, strategy="semantic")
        
        # All strategies should produce chunks
        self.assertTrue(len(text_chunks) > 0, "Text strategy should create chunks")
        self.assertTrue(len(para_chunks) > 0, "Paragraph strategy should create chunks")
        self.assertTrue(len(semantic_chunks) > 0, "Semantic strategy should create chunks")
        
        # Strategies might produce different numbers of chunks
        # This is not a strict requirement, but generally paragraph chunking
        # should be more sensitive to document structure
        # Just logging for informational purposes
        print(f"Text strategy: {len(text_chunks)} chunks")
        print(f"Paragraph strategy: {len(para_chunks)} chunks")
        print(f"Semantic strategy: {len(semantic_chunks)} chunks")
    
    def test_chunk_overlap(self):
        """Test that chunks have proper overlap."""
        # Create a simple test text
        simple_text = "ABCDEFGHIJKLMNOPQRSTUVWXYZ" * 10  # 260 characters
        
        # Chunk with 50 char chunks and 10 char overlap
        chunker = DocumentChunker(chunk_size=50, chunk_overlap=10)
        chunks = chunker.chunk_text(simple_text)
        
        # Check overlap between chunks
        for i in range(len(chunks) - 1):
            current_chunk_end = chunks[i][-10:]
            next_chunk_start = chunks[i+1][:10]
            
            self.assertEqual(current_chunk_end, next_chunk_start, 
                           f"Chunks should overlap by {chunker.chunk_overlap} characters")
    
    def tearDown(self):
        """Clean up test fixtures."""
        # Remove test file
        if os.path.exists(self.test_file):
            os.remove(self.test_file)
        
        # Try to remove test directory (will only work if empty)
        try:
            os.rmdir(self.test_dir)
        except:
            pass


if __name__ == "__main__":
    unittest.main()