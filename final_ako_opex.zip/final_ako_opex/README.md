# OPEX_BOT Multi-Agent Text-to-SQL System

This repository contains a modular, multi-agent system for text-to-SQL translation with a focus on financial data. The system is designed to prioritize accuracy above all other considerations.

## Core Architecture

The system is built around a set of specialized agents that work together to process natural language queries and generate accurate SQL:

1. **Metadata Agent**: Analyzes database schema and builds comprehensive metadata repository
2. **Query Enhancer Agent**: Analyzes and enhances user queries, requesting clarification when needed
3. **RAG Agent**: Retrieves relevant context from the metadata store to assist SQL generation
4. **SQL Agent**: Generates accurate SQL queries based on enhanced user queries and context
5. **SQL Helper Agent**: Validates and improves generated SQL for correctness and performance
6. **Response Agent**: Formats and presents the final results to the user

## Key Features

- Event-driven agent communication
- Comprehensive state management
- Conversation history tracking
- Vector-based metadata retrieval
- User feedback collection for continuous improvement
- Structured logging for debugging and analytics

## Core Components

### Interfaces

- **Agent Interface**: Defines the standard contract for all agents
- **Message Format**: Standardized message format for inter-agent communication

### Communication

- **Event Bus**: Central event-driven communication system for agents
- **Publish-Subscribe Pattern**: Allows agents to subscribe to specific event types

### State Management

- **State Manager**: Tracks the state of each query as it progresses
- **Query Context**: Maintains comprehensive context for each query

### Memory

- **Conversation Store**: Maintains conversation history for context
- **Vector Store**: Stores and retrieves embeddings for semantic search
- **Feedback Store**: Collects and organizes user feedback for learning

### Logging

- **Structured Logging**: Outputs machine-readable logs for analytics
- **Query Logging**: Specialized logging for query processing

## Implementation Notes

This implementation prioritizes:

1. **Accuracy**: Multiple validation checks, careful schema analysis, confidence scoring
2. **Modularity**: Clean separation of concerns between agents
3. **Extensibility**: Easy to add new agents or replace existing ones
4. **Learning**: Built-in feedback collection and learning mechanisms
5. **Transparency**: Comprehensive logging and state tracking

## Getting Started

This repository is currently in the initial implementation phase. More documentation will be added as the implementation progresses.